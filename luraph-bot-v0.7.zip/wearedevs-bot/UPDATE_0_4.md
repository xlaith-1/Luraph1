# 0.4 — first tested Luraph v14.8 string-inventory support

## What now works

The default constants worker automatically attempts a bounded periodic-payload
fallback when the existing application parser fails. It independently identifies
an eight-byte repeating mask, resolves low-bit ambiguities using compact-number
runs, infers a tagged constant-pool schema, and recovers encrypted strings.
Captured bootstrap XOR operands constrain string-cipher selection. An additional
sample of up to 64 strings must pass a printable-text threshold before output.

This is **heuristic flat string recovery**, not verified full deserialization.
It does not run the bootstrap VM or decoded application, use native Lua, contact
external services, or use a reference dump/hash/filename lookup to generate output.
Inputs, inferred fields, search operations and time remain bounded. Unsupported
or ambiguous inputs may still fail. Binary and extra candidates are preserved.

## Supplied FTAP pair: measured results

Input: https://raw.githubusercontent.com/BlizTBr/scripts/refs/heads/main/FTAP.lua

The examined input's header claims Luraph v14.8. Input SHA-256:
`61511119a1f72fb8e6c1b938742607555d9a9f0acb5230ed9492b1ab80c545a4`.
The URL is mutable; the stored input hash identifies the tested copy.

- **3,478 / 3,478 unique reference strings matched.**
- **3,480 unique strings emitted.** The two additional strings are
  `Floppa Died!` and `</b></font>`; their absence from the reference is not
  used as a reason to delete them from the independent capture.
- Production worker finished in approximately 16 seconds in this workspace.
- The cipher inferred from this input is multiplier 53, increment 209, mask 120.
  These values are investigation results, not constants embedded in generation.
- A renamed copy with an added comment also passed the reference comparison.
- The worker returns `luraph-constants.lua` with an explicit flat-inventory header
  and `return { strings = { ... } }`, not invented prototype buckets.

**Not recovered by this fallback:** prototype grouping, numbers, booleans,
closure relationships, or original source. Matching the reference string set
is not proof of complete recovery. Only this supplied v14.8 pair has been tested;
this release does not claim support for every v14.8 file. v14.9 and v15.0 are
not certified by these tests.

## Regression validation

16 tests passed, with no skips:
- All previous v0.3 tests and old input/reference comparisons.
- FTAP's complete reference string set plus the two documented extras.
- Flat rendering without fabricated prototypes.
- Inference deadline and uniform-data rejection.

Run from the project root:

```sh
LURAPH_CONSTANT_FIXTURES=/path/to/uploads \
LURAPH_LARGE_FIXTURES=/path/to/uploads \
LURAPH_148_INPUT=/path/to/FTAP.lua \
node --test tests/luraph-constants.test.mjs tests/luraph-v03.test.mjs tests/luraph-148.test.mjs
```

The earlier Fetched comparison remains partial: 5,463/5,464 reference strings
and 2,826 additional candidates. Its passing regression is not completeness.

The workspace had a v0.2 capture-module copy alongside the v0.3 release archive;
the v0.3 module was restored from that archive before adding this path. The
combined code was retested rather than silently dropping the v0.3 improvements.

## Deployment

The worker, renderer, explicit Bubblewrap mounts, and bot attachment caption
have been updated. Existing 8 MiB input limits and owner-only controls remain.
This release was worker-tested directly. No running Discord process was found,
and the live bot was not restarted in this turn. Install the release and restart
on the hosting system to use it in Discord; do not bypass OS isolation.
