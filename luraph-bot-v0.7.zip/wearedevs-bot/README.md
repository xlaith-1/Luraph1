# Luraph deobfuscation Discord bot — v0.7

A prefix-command Discord bot for **best-effort Luraph recovery**. It returns useful captured data, not a promise of original-source reconstruction or universal Luraph support.

## Commands and access

Attach **one `.lua`, `.luau`, or `.txt` file to the same Discord message** as:

```text
?luraph
?v15
```

- `?luraph` — Luraph constant dumping (v0.6.1 route): grouped constants where supported, or a flat string inventory for the reviewed periodic-payload family. Bounded data capture, no application execution; partial coverage. Also imports numbered string dumps.
- `?v15` — Luraph **v15 devirtualization** (v0.7 route): the protected script is run instrumented inside a fake Roblox environment in the networkless OS sandbox, and the observed behaviour plus a lifted application candidate are returned. Partial; not certified complete or equivalent.

Other commands: `?help`, `?status`, `?ping`. This deployment uses prefix commands, not slash commands. `.luau` files are accepted by `?v15`; for `?luraph` rename a `.luau` copy to `.lua` or `.txt`.

**Only Discord user `1442928403601690657` is authorized.** Everyone else is silently ignored, including administrators, server owners, and help/status requests. The fixed owner ID is in `bot/config.py`; guild/channel settings do not override it.

- Input limit: **8 MiB (8,388,608 bytes)**, inclusive.
- Default job timeout: **900 seconds (15 minutes)**; configurable up to 1,800 seconds.
- Results are public in the channel, not ephemeral.
- Discord's own upload limits also apply.

## 1. Install on a Linux host

Requirements:

- **Python 3.11+**, including `venv` and pip.
- **Node.js 20+** and npm. Node must be available inside the worker's `/usr/bin` or `/bin` PATH; an nvm-only installation under your home directory is not sufficient.
- **Bubblewrap** (`bwrap`) and a host that permits its user/mount namespaces.
- The `?v15` route additionally needs the pinned Luau runtime binaries in `engines/luraph-v15/runtime/` (`luau`, `luau-ast`, `luau-compile`). They ship with the release; rebuild them only with `python3 scripts/build_v15_runtime.py`, which needs git, cmake, and a C++ compiler.
- A persistent host if you want the bot to remain online.

On Debian/Ubuntu, install the basic system dependencies:

```bash
sudo apt-get update
sudo apt-get install -y python3 python3-venv bubblewrap ca-certificates
```

Install Node.js 20+ and npm using a trusted distro/vendor package source if they are not already installed. Check versions and isolation support:

```bash
python3 --version
node --version
command -v bwrap
bwrap --unshare-all --ro-bind / / -- /usr/bin/true
```

The last command should exit successfully. Namespace restrictions on some containers or hosting services can prevent Bubblewrap from working. Configure a compatible host; **do not disable the worker sandbox**. This archive targets a Linux host and does not include the obsolete Docker/Compose deployment recipes. Java, .NET, LuaJIT, and the old multi-engine build steps are not required for the current constant-capture route.

From the extracted `wearedevs-bot` directory:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
npm ci --ignore-scripts
cp .env.example .env
chmod 600 .env
```

The virtual environment, Node dependencies, uploads, and credentials are intentionally not bundled.

## 2. Configure Discord

Edit `.env` **locally** and replace the placeholder `DISCORD_TOKEN` with your bot token. Never paste it into chat, commit it, or include it in a ZIP. Rotate any previously exposed token in the Discord Developer Portal.

In the Discord Developer Portal:

1. Open your application → **Bot** and enable **Message Content Intent**.
2. Invite the bot to your server using the `bot` OAuth scope.
3. Grant **View Channel**, **Send Messages**, **Attach Files**, and **Read Message History**. Grant **Send Messages in Threads** if needed.

Useful settings in `.env`:

```dotenv
DISCORD_TOKEN=replace_with_your_bot_token
ENABLE_PREFIX_COMMANDS=1
MAX_INPUT_BYTES=8388608
WORKER_TIMEOUT_SECONDS=900
MAX_CONCURRENT_JOBS=2
USER_COOLDOWN_SECONDS=30
```

Optional `ALLOWED_GUILD_IDS` and `ALLOWED_CHANNEL_IDS` are comma-separated restrictions; blank values mean all servers/channels where the bot is installed, **still subject to the fixed owner-only restriction**. `PURGE_SLASH_COMMANDS=1` removes this application's old slash-command registrations; it does not register new commands. See `.env.example` for polling and gateway-watchdog options.

## 3. Verify the installation and run

```bash
.venv/bin/python -c "from bot.engines import engine_unavailable_reason; print(engine_unavailable_reason('luraph') or 'Worker installation ready')"
.venv/bin/python -m bot.supervisor
```

Run these commands from the extracted project directory. The bot automatically reads `.env` there. Wait for the **Discord connected** log, then send `?ping` or `?luraph` with an attachment from the authorized account.

The installation check verifies dependencies and the release manifest; it is not an end-to-end namespace or dumping test. Test a supported file to confirm the complete workflow.

The supervisor restarts failed Discord clients, but it **cannot keep a stopped host or closed workspace alive**. Use your host's service manager for persistent deployment. To restart a foreground session, press Ctrl+C, wait for it to exit, and run the same supervisor command again. Avoid starting duplicate bot instances.

## What the output means

The usual output is `luraph-constants.lua`, a readable Lua data table containing captured constants and prototype relationships where available. It is **not reconstructed application source**.

For grouped captures, the caption is:

```text
Successfully dumped <number> constants across <number> prototypes. Partial capture; not reconstructed source.
```

These counts measure emitted typed entries, not complete source coverage. Flat string inventories explicitly say prototype grouping was not recovered. Numbered string-dump imports are labeled as imports, not newly deobfuscated scripts.

Version 0.6.1 can isolate some reviewed terminal Luraph loaders preceded by independent Roblox code. Such outputs explicitly state that the preceding code was excluded, not executed. Shared dependencies or ambiguous layouts can still cause rejection.

The capture route uses bounded AST data evaluation and stops at a reviewed VM boundary. It does not execute the decoded application or upload source to a third-party decompiler. It rejects unsupported inputs instead of returning the original script as supposedly readable code. Genuine output already written may be returned after an error or timeout.

**Known limitations:** scalar recovery and exact prototype grouping are not fully verified; some samples retain extra or missing strings; numeric-only/no-string inputs remain unsupported. This bot is Luraph-focused. The separately analyzed Bias sample does not mean Bias support was added to the bot.

## The v15 route (?v15)

This route ships the devirtualizer the project owners supplied. It executes the protected input **instrumented, inside the fake Roblox/executor environment, inside the networkless Bubblewrap sandbox** — never on the host and never with network access. Inputs that do not pass the Luraph v15 detection and VM-structure checks are rejected; there is no generic script-execution fallback.

Outputs (one or both are attached):

- `luraph-v15.application.lua` — devirtualized application candidate. Local names are inferred from use. Validated to be valid Luau that is not the original input and not a VM-only listing.
- `luraph-v15.trace.lua` — the observed-behaviour trace (what the instrumented run actually did against the fake environment).

Both are **partial**: branches the trace never took are missing, anti-tamper traps may be disabled by the pipeline, and nothing certifies equivalence with the original. The bot labels every v15 result "Not verified complete or equivalent." A timeout or error can still return a validated checkpoint that was already written.

See [UPDATE_0_6.md](UPDATE_0_6.md), [UPDATE_0_6_1.md](UPDATE_0_6_1.md), and [UPDATE_0_7.md](UPDATE_0_7.md) for measured results and limitations.

## Troubleshooting

| Message or symptom | What to check |
| --- | --- |
| `bwrap is not installed` | Install `bubblewrap` on the machine actually running the bot, verify `command -v bwrap`, then restart. |
| Namespace/isolation error | Check the host's user-namespace policy. Some container hosts block nested isolation. Do not bypass the sandbox. |
| Installation does not match release manifest | Re-extract the complete archive. Do not mix worker/modules from older releases. |
| `DISCORD_TOKEN is missing` | Create `.env` in the project root with the real token, or securely provide the environment variable. |
| Bot ignores messages | Check the fixed owner ID, Message Content Intent, prefix setting, channel permissions, and guild/channel restrictions. |
| No validated constant dump | The input variant is unsupported or incomplete, or parsing/capture failed. A version banner alone does not establish support. |
| Timeout | Increase `WORKER_TIMEOUT_SECONDS` up to 1800 if appropriate. This does not make unsupported layouts supported. |

## Tests and packaging

```bash
npm test
.venv/bin/python -m unittest discover -s tests -p 'test_*.py'
```

Private-fixture and environment-dependent tests may skip. Historical test totals in older notes are not a claim that every test will run on a fresh installation. Worker test success does not certify universal recovery.

To create another source ZIP without credentials or dependencies:

```bash
python3 scripts/package_bot.py ../luraph-bot-v0.7.zip
```

`luraph-release-manifest.json` records hashes of critical runtime files. Maintainers must run `python3 scripts/build_luraph_manifest.py` after intentional runtime-code edits, then retest. Users should not regenerate the manifest merely to hide an incomplete installation.

## Included files

- `?luraph` constant dumper: `worker/luraph-constants-cli.mjs`, `worker/luraph-string-dump.mjs`, and `tools/luraph/`. Output is `luraph-constants.lua`.
- `?v15` devirtualizer: `worker/luraph-v15-cli.py`, `engines/luraph-v15/`, and the pinned `engines/luraph-v15/runtime/{luau,luau-ast,luau-compile}` binaries. Outputs are `luraph-v15.application.lua` and/or `luraph-v15.trace.lua`.
- `bot/`: Discord client, supervisor, owner gate, resource limits, isolated worker launcher. Both commands are registered in `bot/engines.py`.
- `tests/`: tests and synthetic fixtures; private uploaded samples are excluded.
- `scripts/`: integrity-manifest, safe packaging, and runtime-build helpers.
- `.env.example`: placeholder configuration only.
- `docs/`, release notes, and licenses: validation history and project documentation. Historical notes may describe retired routes; this README documents the current deployment.

No working Discord token is included. Extracting this archive does not restart or configure an existing bot automatically.
