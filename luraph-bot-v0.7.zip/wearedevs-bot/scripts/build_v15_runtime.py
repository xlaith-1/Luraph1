"""Build and install the pinned Luau runtime the Luraph-v15 route needs.

The devirtualizer runs protected code inside a real Luau VM (a build of
luau-lang/luau 0.739 with the vector metatable left writable) plus the
luau-ast and luau-compile CLIs for structure checks. None of this is
downloaded at request time: this script builds the binaries once, on a
machine with a toolchain, and the bot only ever uses the local copies.

    python scripts/build_v15_runtime.py [--tag 0.739] [--src DIR] [--portable]

Requirements: git, cmake >= 3.16, a C++17 compiler, and (optionally) Ninja.
After building, re-run `python scripts/build_luraph_manifest.py` and test the
`?v15` route on the bundled sample before enabling it.
"""
import argparse
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ENGINE = ROOT / 'engines' / 'luraph-v15'
RUNTIME = ENGINE / 'runtime'
REPO = 'https://github.com/luau-lang/luau.git'
TARGETS = ['Luau.Repl.CLI', 'Luau.Ast.CLI', 'Luau.Compile.CLI']
NAMES = {'Luau.Repl.CLI': 'luau', 'Luau.Ast.CLI': 'luau-ast', 'Luau.Compile.CLI': 'luau-compile'}


def run(cmd, cwd=None):
    print('[*] ' + ' '.join(cmd), file=sys.stderr)
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument('--tag', default='0.739')
    ap.add_argument('--src', help='existing Luau checkout to reuse')
    ap.add_argument('--portable', action='store_true', help='gcc: no -march=native')
    args = ap.parse_args()
    for tool in ('git', 'cmake'):
        if not shutil.which(tool):
            sys.exit('[!] %s not found' % tool)
    tmp = None
    src = Path(args.src).resolve() if args.src else None
    if not src:
        tmp = tempfile.mkdtemp(prefix='luau-build-')
        src = Path(tmp) / 'luau'
        run(['git', 'clone', '-q', '--depth', '1', '--branch', args.tag, REPO, str(src)])
    sys.path.insert(0, str(ENGINE))
    import build_luau
    build_luau.patch(src)
    build = src / 'build-v15'
    cfg = ['cmake', '-S', str(src), '-B', str(build), '-DCMAKE_BUILD_TYPE=Release',
           '-DLUAU_BUILD_TESTS=OFF', '-DLUAU_BUILD_WEB=OFF']
    if shutil.which('ninja'):
        cfg += ['-G', 'Ninja']
    if not shutil.which('cl') and shutil.which('g++'):
        opt = '-O3 -flto' + ('' if args.portable else ' -march=native')
        cfg += ['-DCMAKE_C_COMPILER=gcc', '-DCMAKE_CXX_COMPILER=g++',
                '-DCMAKE_C_FLAGS_RELEASE=%s -DNDEBUG' % opt,
                '-DCMAKE_CXX_FLAGS_RELEASE=%s -DNDEBUG' % opt,
                '-DCMAKE_EXE_LINKER_FLAGS=-static ' + opt]
    run(cfg)
    run(['cmake', '--build', str(build), '--config', 'Release', '--parallel'] +
        ['--target'] + TARGETS)
    RUNTIME.mkdir(exist_ok=True)
    for target in TARGETS:
        name = NAMES[target] + ('.exe' if sys.platform == 'win32' else '')
        for cand in (build / 'Release' / name, build / name):
            if cand.is_file():
                shutil.copy2(cand, RUNTIME / NAMES[target])
                break
        else:
            sys.exit('[!] built binary not found for ' + target)
    license_txt = src / 'LICENSE.txt'
    if license_txt.is_file():
        shutil.copy2(license_txt, ENGINE / 'LUAU_LICENSE.txt')
    for name in NAMES.values():
        if sys.platform != 'win32' and shutil.which('strip'):
            subprocess.run(['strip', str(RUNTIME / name)], check=False)
    print('[+] wrote ' + str(RUNTIME) + '; re-run scripts/build_luraph_manifest.py')
    if tmp:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    main()
