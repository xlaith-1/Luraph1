"""Package source/runtime files, never credentials, uploads, caches or research data."""
from pathlib import Path
import zipfile
import sys
ROOT=Path(__file__).resolve().parent.parent
if len(sys.argv)>2: raise SystemExit('Usage: python scripts/package_bot.py [destination.zip]')
DEST=Path(sys.argv[1]).resolve() if len(sys.argv)==2 else ROOT.parent/'luraph-bot-v0.7.zip'
SKIP={'.git','node_modules','__pycache__','.venv','obj','bin','.cache','.npm'}
TOP={'bot','worker','engines','tools','tests','scripts','docs'}
FILES={'DUMPER.md','LICENSE','SECURITY.md','luraph-release-manifest.json','v15-release-manifest.json','README.md','SETUP.md','TEST_RESULTS.md','CLEANUP.md','.env.example','.gitignore','requirements.txt','package.json','package-lock.json'}
with zipfile.ZipFile(DEST,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path in sorted(ROOT.rglob('*')):
        relative=path.relative_to(ROOT)
        if path.resolve()==DEST:continue
        if any(part in SKIP for part in relative.parts) or path.is_symlink() or not path.is_file():continue
        if relative.parts[0] not in TOP and str(relative) not in FILES and not (len(relative.parts)==1 and relative.name.startswith('UPDATE_') and relative.suffix=='.md'):continue
        if path.name.startswith('.env') and path.name!='.env.example':continue
        if path.suffix in {'.log','.pyc','.pdb','.user'}:continue
        if relative.parts[0]=='tools' and len(relative.parts)>1 and relative.parts[1]!='luraph':continue
        z.write(path,'wearedevs-bot/'+str(relative))
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert not any('/uploads/' in n or n.endswith('/.env') or '/node_modules/' in n for n in z.namelist())
print(f'{DEST}: {DEST.stat().st_size:,} bytes')
