"""Run after an intentional code update; never regenerate automatically at startup."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent.parent
files=['worker/luraph-constants-cli.mjs','worker/luraph-string-dump.mjs','bot/engines.py','bot/engine_limits.py']
files += ['tools/luraph/'+n for n in ['constant-capture.mjs','static-data-eval.mjs','dispatch147.mjs','payload-analysis.mjs','periodic-pool.mjs','serialized-pool.mjs','detect-input.mjs','normalize_for_analysis.py','unpack_container.py','unpack_lzma.py','vendor/luaparse.cjs']]
(root/'luraph-release-manifest.json').write_text(json.dumps({'schema':1,'release':'0.6.1','files':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}},indent=2)+'\n')

# The optional dynamic route has a separate manifest, so the original constant
# route does not depend on its runtime binaries being installed.
v15=['worker/luraph-v15-cli.py','bot/engines.py','bot/engine_limits.py']
v15 += [str(p.relative_to(root)) for p in sorted((root/'engines/luraph-v15').rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc']
(root/'v15-release-manifest.json').write_text(json.dumps({'schema':1,'release':'0.7','files':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in v15}},indent=2)+'\n')
