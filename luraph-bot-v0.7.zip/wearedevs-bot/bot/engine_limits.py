"""Trusted resource-limited launcher for the bubblewrap namespace, not uploads."""
import os
import resource
import sys

if __name__ == '__main__':
    seconds = int(sys.argv[1])
    if not 1 <= seconds <= 1800 or len(sys.argv) < 4:
        raise SystemExit('Invalid worker invocation')
    resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    resource.setrlimit(resource.RLIMIT_CPU, (seconds, seconds + 2))
    resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024**2, 16 * 1024**2))
    resource.setrlimit(resource.RLIMIT_NOFILE, (128, 128))
    resource.setrlimit(resource.RLIMIT_NPROC, (128, 128))
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    os.execv(sys.argv[2], sys.argv[2:])
