from __future__ import annotations
import hashlib
import asyncio
import json
import os
import shutil
import signal
import sys
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from .config import ROOT

class JobError(Exception):
    """A bounded, user-safe job failure."""

class Gate:
    """Event-loop-only admission control: no unbounded waiting queue."""
    def __init__(self, capacity: int, cooldown: int):
        self.capacity, self.cooldown = capacity, cooldown
        self.active: set[int] = set()
        self.last: dict[int, float] = {}

    def enter(self, user: int) -> None:
        now = time.monotonic()
        # Prune expired entries so an exposed bot cannot accumulate unbounded IDs.
        self.last = {key: timestamp for key, timestamp in self.last.items() if now - timestamp < self.cooldown}
        if user in self.active:
            raise JobError('You already have a job running.')
        if len(self.active) >= self.capacity:
            raise JobError('All workers are busy. Try again shortly; your file was not queued.')
        remaining = self.cooldown - (now - self.last.get(user, -float('inf')))
        if remaining > 0:
            raise JobError(f'Please wait {int(remaining) + 1} seconds before another job.')
        self.active.add(user)
        self.last[user] = now

    def leave(self, user: int) -> None:
        self.active.discard(user)

ARTIFACT_NAMES = frozenset({'deobfuscated.lua', 'main.analysis.lua', 'control-flow.json',
                            'callbacks.json', 'strings.json', 'report.json', 'report.md'})

async def run_worker(input_file: Path, output_dir: Path, timeout: int, engine: str = 'wearedevs') -> dict:
    scripts = {'wearedevs': 'index.mjs', 'luraph': 'luraph-cli.mjs'}
    if engine not in scripts:
        raise JobError('Unknown deobfuscation engine.')
    node = shutil.which('node')
    if not node:
        raise JobError('Node.js is not installed on the bot host. Ask the owner to finish setup.')
    # No shell, no user-selected executable, no bot token or NODE_OPTIONS in the child.
    cmd = [sys.executable, str(ROOT / 'bot' / 'worker_limits.py'), node,
           str(ROOT / 'worker' / scripts[engine]), str(input_file), str(output_dir)]
    environment = {'PATH': os.getenv('PATH', ''), 'LANG': 'C.UTF-8'}
    proc = await asyncio.create_subprocess_exec(*cmd, cwd=input_file.parent, env=environment,
                 stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
                 start_new_session=os.name == 'posix', limit=65536)
    try:
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout)
    except (TimeoutError, asyncio.CancelledError):
        if proc.returncode is None:
            if os.name == 'posix':
                try:
                    os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                proc.kill()
        await proc.communicate()
        if asyncio.current_task() and asyncio.current_task().cancelling():
            raise
        raise JobError('Analysis hit its time limit. This variant is too complex or unsupported.')
    if len(stdout) > 65536 or len(stderr) > 65536:
        raise JobError('Worker output exceeded its protocol limit.')
    if proc.returncode:
        # Do not echo parser error fragments from private/untrusted Lua into chat or logs.
        raise JobError('The worker could not process this file. It may contain unsupported Luau syntax, '
                       'a different obfuscator variant, malformed input, or exceed a resource limit.')
    try:
        result = json.loads(stdout)
        if result.get('ok') is not True:
            raise ValueError('Worker returned no success marker')
        report_file = output_dir / 'report.json'
        if not report_file.is_file() or report_file.stat().st_size > 65536:
            raise ValueError('Bad report size')
        report = json.loads(report_file.read_text())
        if report.get('status') not in {'partial-source', 'partial-analysis', 'transformed', 'unsupported', 'full-source'}:
            raise ValueError('Bad recovery status')
        return report
    except (ValueError, OSError) as exc:
        raise JobError('The worker returned an invalid result. Ask the owner to inspect the installation.') from exc

def archive_results(output_dir: Path, destination: Path, max_bytes: int) -> None:
    paths = list(output_dir.iterdir())
    if any(p.name not in ARTIFACT_NAMES or p.is_symlink() or not p.is_file() for p in paths):
        raise JobError('Unexpected worker artifact; the result was not released.')
    if sum(p.stat().st_size for p in paths) > 12 * 1024 * 1024:
        raise JobError('The recovered output is too large to return.')
    with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for file in sorted(paths):
            bundle.write(file, arcname=file.name)
    if destination.stat().st_size > max_bytes:
        raise JobError('The result exceeds this server’s upload limit. Try a smaller input.')


def complete_source_file(report: dict, output_dir: Path, max_bytes: int) -> Path:
    """Fail closed: packaging is never used as evidence of complete recovery.

    The worker only approves reviewed input/output fingerprints after actual
    reconstruction. Unknown inputs and mismatching output remain fail-closed.
    All certification fields and a standalone recovered.lua are required.
    """
    if not (report.get('status') == 'full-source'
            and report.get('fullRecoveryVerified') is True
            and report.get('remainingDispatcherBlocks') == 0
            and report.get('unresolvedCallbacks') == 0):
        if str(report.get('engine', '')).startswith('luraph-static/'):
            if report.get('payloadDecoded'):
                raise JobError(
                    f"Luraph payload decoded statically: {report.get('constantCount', 0)} constants "
                    f"({report.get('stringConstantCount', 0)} strings), {report.get('declaredPrototypeCount', 0)} declared function prototypes. " +
                    (f"Parsed {report.get('prototypeRecordsDecoded', 0)} VM function records / {report.get('vmInstructionsDecoded', 0)} instructions. " if report.get('prototypeRecordsDecoded') else '') +
                    'Full structured source was not verified for this upload. '
                    '**No file was returned** under full-recovery-only mode. The uploaded script was not executed.')
            raise JobError('This upload does not match a reviewed Luraph recovery profile. '
                           '**No file was returned**; full readable-source recovery is unverified.')
        raise JobError(
            'Full readable-source recovery could not be verified for this upload. '
            'Recovery is incomplete or does not match a reviewed input/output profile. '
            '**No file was returned** because full-recovery-only mode is enabled. '
            'This is a decompiler limitation, not a permissions or file-format error.')
    source = output_dir / 'recovered.lua'
    if source.is_symlink() or not source.is_file():
        raise JobError('A verified standalone source file was not produced. No file was returned.')
    if not 0 < source.stat().st_size <= min(max_bytes, 12 * 1024 * 1024):
        raise JobError('The recovered source is empty or exceeds the upload limit. No file was returned.')
    expected = report.get('sourceSha256')
    if expected is not None and (not isinstance(expected, str) or len(expected) != 64
            or hashlib.sha256(source.read_bytes()).hexdigest() != expected):
        raise JobError('The recovered source failed its integrity check. No file was returned.')
    return source
