"""Discord interface for the static-analysis worker."""
