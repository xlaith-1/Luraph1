from __future__ import annotations
import os
from dataclasses import dataclass
from pathlib import Path

# Single-user access: no admin, role, guild-owner, or environment bypass.
AUTHORIZED_USER_ID = 1442928403601690657

ROOT = Path(__file__).resolve().parent.parent

def number(name: str, default: int, minimum: int, maximum: int) -> int:
    value = int(os.getenv(name, default))
    if not minimum <= value <= maximum:
        raise ValueError(f'{name} must be between {minimum} and {maximum}')
    return value

def ids(name: str) -> frozenset[int]:
    return frozenset(int(part.strip()) for part in os.getenv(name, '').split(',') if part.strip())

@dataclass(frozen=True)
class Settings:
    token: str
    guild_ids: frozenset[int]
    channel_ids: frozenset[int]
    developer_guild: int | None
    max_input_bytes: int
    concurrency: int
    cooldown_seconds: int
    worker_timeout: int
    purge_slash_commands: bool
    prefix_enabled: bool = True

    @classmethod
    def load(cls) -> 'Settings':
        token = os.getenv('DISCORD_TOKEN', '').strip()
        if not token:
            raise ValueError('DISCORD_TOKEN is missing. Put your bot token in .env; never upload it.')
        dev = os.getenv('DEV_GUILD_ID', '').strip()
        return cls(token, ids('ALLOWED_GUILD_IDS'), ids('ALLOWED_CHANNEL_IDS'),
                   int(dev) if dev else None, number('MAX_INPUT_BYTES', 8388608, 1024, 8388608),
                   number('MAX_CONCURRENT_JOBS', 2, 1, 4), number('USER_COOLDOWN_SECONDS', 30, 1, 3600),
                   number('WORKER_TIMEOUT_SECONDS', 900, 5, 1800), os.getenv('PURGE_SLASH_COMMANDS', '1') == '1',
                   os.getenv('ENABLE_PREFIX_COMMANDS', '1') == '1')
