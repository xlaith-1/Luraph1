from __future__ import annotations
import asyncio
import logging
import math
import time
import os
from collections import deque
from contextlib import suppress
import tempfile
import uuid
from pathlib import Path
from urllib.parse import urlparse
import aiohttp
import discord
from dotenv import load_dotenv
from .config import ROOT, Settings, AUTHORIZED_USER_ID
from .jobs import Gate, JobError
from .engines import ENGINES, COMMANDS, ALL_COMMANDS, HELP_COMMANDS, STATUS_COMMANDS, help_text, run_engine, select_source

log = logging.getLogger('wrd_bot')

async def download_attachment(session: aiohttp.ClientSession, attachment: discord.Attachment,
                              target: Path, max_bytes: int, extensions=frozenset({'.lua', '.txt'})) -> None:
    if Path(attachment.filename).suffix.lower() not in extensions:
        raise JobError('Attach one ' + '/'.join(sorted(extensions)) + ' file. Archives and links are not accepted.')
    if attachment.size <= 0 or attachment.size > max_bytes:
        raise JobError(f'Files must be nonempty and no larger than {max_bytes // 1024} KiB.')
    url = urlparse(attachment.url)
    if url.scheme != 'https' or url.hostname not in {'cdn.discordapp.com', 'media.discordapp.net'}:
        raise JobError('Only Discord-hosted attachments are accepted.')
    total = 0
    # Do not follow redirects to arbitrary hosts. The byte limit also applies to
    # actual streamed bytes, rather than trusting the attachment metadata alone.
    async with session.get(attachment.url, allow_redirects=False) as response:
        if response.status != 200:
            raise JobError('Discord could not provide that attachment. Re-upload it and try again.')
        with target.open('xb') as output:
            async for chunk in response.content.iter_chunked(16384):
                total += len(chunk)
                if total > max_bytes:
                    raise JobError('The downloaded attachment exceeds the input limit.')
                output.write(chunk)
    if total == 0:
        raise JobError('The attachment is empty.')

class DeobfuscatorBot(discord.Client):
    def __init__(self, settings: Settings):
        intents = discord.Intents.none()
        intents.guilds = True
        intents.guild_messages = settings.prefix_enabled
        intents.dm_messages = settings.prefix_enabled
        intents.message_content = settings.prefix_enabled
        super().__init__(intents=intents, allowed_mentions=discord.AllowedMentions.none())
        self.settings = settings
        self.purged_global = False
        self.purged_guilds = set()
        self.gate = Gate(settings.concurrency, settings.cooldown_seconds)
        self.session: aiohttp.ClientSession | None = None
        self.health_task: asyncio.Task | None = None
        self.diagnostic_guild = int(os.getenv("DIAGNOSTIC_GUILD_ID", "0"))
        self.message_events_seen = 0
        self.poll_task = None
        self.cleanup_task = None
        self.prefix_delivery_tasks = set()
        self.gateway_unhealthy_since = None
        self.restart_pending = False
        self.watchdog_seconds = max(30, min(600, int(os.getenv("GATEWAY_WATCHDOG_SECONDS", "90"))))
        self.poll_channels = tuple(int(x) for x in os.getenv("PREFIX_POLL_CHANNEL_IDS", "").split(",") if x.strip())
        self.seen_commands = set()
        self.seen_order = deque()

    async def setup_hook(self) -> None:
        self.session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20), trust_env=False)

    async def purge_remote_commands(self) -> None:
        # No command tree or slash handlers are registered. Delete old definitions
        # belonging to this application, including guild-scoped legacy commands.
        if not self.settings.purge_slash_commands or not self.application_id:
            return
        try:
            if not self.purged_global:
                await self.http.bulk_upsert_global_commands(self.application_id, payload=[])
                self.purged_global = True
            guild_ids = {g.id for g in self.guilds} | set(self.settings.guild_ids)
            if self.settings.developer_guild:
                guild_ids.add(self.settings.developer_guild)
            for guild_id in guild_ids - self.purged_guilds:
                await self.http.bulk_upsert_guild_commands(self.application_id, guild_id, payload=[])
                self.purged_guilds.add(guild_id)
        except discord.HTTPException:
            log.warning('Legacy slash-command cleanup failed; will retry on reconnect')

    async def close(self) -> None:
        current = asyncio.current_task()
        tasks = [t for t in (self.poll_task, self.health_task, self.cleanup_task, *self.prefix_delivery_tasks) if t and t is not current]
        for task in tasks: task.cancel()
        if tasks: await asyncio.gather(*tasks, return_exceptions=True)
        if self.session:
            await self.session.close()
        await super().close()

    def schedule_prefix(self, message) -> None:
        if getattr(message.author, "id", None) != AUTHORIZED_USER_ID:
            return
        if len(self.prefix_delivery_tasks) >= 64:
            log.warning('REST prefix delivery task limit reached')
            return
        task = asyncio.create_task(self.on_message(message))
        self.prefix_delivery_tasks.add(task)
        def finished(t):
            self.prefix_delivery_tasks.discard(t)
            if not t.cancelled() and t.exception():
                log.warning('REST delivery task failed: type=%s', type(t.exception()).__name__)
        task.add_done_callback(finished)

    async def poll_prefix_messages(self) -> None:
        # Opt-in channel-scoped REST fallback. Never replay old attachments on
        # startup. Gateway and REST deliveries share an atomic deduplication gate.
        cursors = {cid: discord.utils.time_snowflake(discord.utils.utcnow()) for cid in self.poll_channels}
        probe = int(os.getenv('PREFIX_DIAGNOSTIC_MESSAGE_ID', '0'))
        for cid in self.poll_channels:
            channel = self.get_channel(cid)
            if not channel or not getattr(channel, 'guild', None):
                continue
            if self.settings.guild_ids and channel.guild.id not in self.settings.guild_ids:
                continue
            if self.settings.channel_ids and cid not in self.settings.channel_ids:
                continue
            if probe:
                try:
                    message = await channel.fetch_message(probe)
                    if message.content.strip().lower() == '?ping':
                        await self.on_message(message)
                        log.info('Diagnostic ping handled through REST: channel=%s', cid)
                except discord.HTTPException as exc:
                    log.warning('Diagnostic REST check failed: status=%s', exc.status)
        while not self.is_closed():
            for cid in self.poll_channels:
                channel = self.get_channel(cid)
                if not channel or not getattr(channel, 'guild', None):
                    continue
                if self.settings.guild_ids and channel.guild.id not in self.settings.guild_ids:
                    continue
                if self.settings.channel_ids and cid not in self.settings.channel_ids:
                    continue
                try:
                    async for message in channel.history(limit=20, after=discord.Object(id=cursors[cid]), oldest_first=True):
                        cursors[cid] = max(cursors[cid], message.id)
                        if getattr(message.author, "id", None) != AUTHORIZED_USER_ID or message.author.bot or message.webhook_id:
                            continue
                        text = message.content.strip().split(maxsplit=1)
                        if text and text[0].lower() in ALL_COMMANDS:
                            log.info('REST prefix delivery: channel=%s', cid)
                            self.schedule_prefix(message)
                except discord.HTTPException as exc:
                    log.warning('REST prefix fallback failed: status=%s channel=%s', exc.status, cid)
                except Exception as exc:
                    log.warning('REST prefix fallback error: type=%s channel=%s', type(exc).__name__, cid)
            await asyncio.sleep(4)

    async def on_guild_join(self, guild: discord.Guild) -> None:
        await self.purge_remote_commands()

    async def on_ready(self) -> None:
        if self.cleanup_task is None or self.cleanup_task.done():
            self.cleanup_task = asyncio.create_task(self.purge_remote_commands())
        if self.settings.prefix_enabled and self.poll_channels and (self.poll_task is None or self.poll_task.done()):
            self.poll_task = asyncio.create_task(self.poll_prefix_messages())
            log.info('Channel-scoped REST prefix fallback enabled: channels=%s', len(self.poll_channels))
        log.info('Discord connected; bot ID=%s; servers=%s; intents=%s; prefix=%s',
                 self.user.id if self.user else None, len(self.guilds), self.intents.value,
                 self.settings.prefix_enabled)
        if self.diagnostic_guild:
            guild = self.get_guild(self.diagnostic_guild)
            log.info('Diagnostic server cached=%s; unavailable=%s; own member cached=%s',
                     guild is not None, getattr(guild, 'unavailable', None),
                     bool(guild and guild.me))
        if self.health_task is None or self.health_task.done():
            self.health_task = asyncio.create_task(self.connection_health())

    def gateway_ack_age(self):
        # discord.py 2.5.2 is pinned. Latency alone is the *last* round trip
        # and can stay deceptively low after heartbeat acknowledgements stop.
        keepalive = getattr(self.ws, '_keep_alive', None)
        last_ack = getattr(keepalive, '_last_ack', None)
        return max(0, time.perf_counter()-last_ack) if isinstance(last_ack, (int, float)) else None

    async def connection_health(self) -> None:
        while not self.is_closed():
            await asyncio.sleep(20)
            latency = self.latency
            ack_age = self.gateway_ack_age()
            stale_ack = ack_age is not None and ack_age >= self.watchdog_seconds
            healthy = self.is_ready() and math.isfinite(latency) and latency < 30 and not stale_ack
            if healthy:
                self.gateway_unhealthy_since = None
                self.restart_pending = False
            elif self.gateway_unhealthy_since is None:
                self.gateway_unhealthy_since = time.monotonic()
            log.info('Gateway health: ready=%s latency_ms=%.0f message_events=%s REST_fallback=%s',
                     self.is_ready(), latency * 1000, self.message_events_seen, bool(self.poll_channels))
            if stale_ack or self.gateway_unhealthy_since is not None and time.monotonic()-self.gateway_unhealthy_since >= self.watchdog_seconds:
                self.restart_pending = True
                if self.gate.active:
                    log.warning('Gateway restart deferred until active jobs finish; new jobs paused')
                    continue
                log.warning('Gateway unhealthy beyond watchdog limit; closing for supervisor restart')
                await self.close()
                return

    async def on_disconnect(self) -> None:
        log.warning('Discord gateway disconnected; client will attempt reconnect')

    async def on_resumed(self) -> None:
        log.info('Discord gateway session resumed')

    def permitted(self, interaction: discord.Interaction) -> bool:
        if getattr(getattr(interaction, "user", None), "id", None) != AUTHORIZED_USER_ID:
            return False
        if interaction.guild_id is None:
            return False
        return ((not self.settings.guild_ids or interaction.guild_id in self.settings.guild_ids)
                and (not self.settings.channel_ids or interaction.channel_id in self.settings.channel_ids))

    async def on_message(self, message: discord.Message) -> None:
        # Check identity before diagnostics, replies, attachment access, or admission.
        # Both gateway and REST fallback deliveries pass through this check.
        if getattr(message.author, "id", None) != AUTHORIZED_USER_ID:
            return
        if self.diagnostic_guild and message.guild and message.guild.id == self.diagnostic_guild:
            self.message_events_seen += 1
            log.info('Diagnostic message event: text_available=%s question_prefix=%s attachments=%s bot_author=%s',
                     bool(message.content), message.content.strip().startswith('?'),
                     len(message.attachments), message.author.bot)
        if not self.settings.prefix_enabled or message.author.bot or message.webhook_id:
            return
        content = message.content.strip()
        command = content.split(maxsplit=1)[0].lower() if content else ''
        if command in ALL_COMMANDS:
            log.info('Recognized prefix received: guild=%s channel=%s', getattr(message.guild, 'id', None), message.channel.id)
        if command not in ALL_COMMANDS:
            return
        message_id = getattr(message, 'id', None)
        if message_id is not None:
            if message_id in self.seen_commands:
                return
            self.seen_commands.add(message_id)
            self.seen_order.append(message_id)
            if len(self.seen_order) > 4096:
                self.seen_commands.discard(self.seen_order.popleft())
        if message.guild is None:
            await message.reply('Use this command in a server channel, not a DM.', mention_author=False)
            return
        if ((self.settings.guild_ids and message.guild.id not in self.settings.guild_ids)
                or (self.settings.channel_ids and message.channel.id not in self.settings.channel_ids)):
            log.warning('Prefix rejected by configured server/channel allowlist')
            try:
                await message.reply('Testing is not enabled in this server/channel. Use the configured test server and channel.', mention_author=False)
            except discord.HTTPException:
                log.warning('Unable to send allowlist explanation')
            return
        log.info('Prefix command received')
        permissions = message.channel.permissions_for(message.guild.me)
        can_send = permissions.send_messages_in_threads if isinstance(message.channel, discord.Thread) else permissions.send_messages
        if not can_send:
            log.warning('Prefix command cannot be answered: missing send permission')
            return
        if command in STATUS_COMMANDS:
            await message.reply(f'Online. Workers: {len(self.gate.active)}/{self.settings.concurrency}. '
                                f'{len(ENGINES)} engines. Best-effort/partial output is enabled. '
                                f'Time limit: {self.settings.worker_timeout // 60:g} minutes. Use ?help.', mention_author=False)
            return
        if command in HELP_COMMANDS or not message.attachments:
            parts = content.split(maxsplit=1)
            selected = COMMANDS.get('?' + parts[1].lower().lstrip('?')) if len(parts) > 1 else COMMANDS.get(command)
            await message.reply(help_text(self.settings.worker_timeout, selected), mention_author=False)
            return
        if self.restart_pending:
            await message.reply('Reconnecting after current jobs finish. New jobs are paused; please retry shortly.', mention_author=False)
            return
        engine = ENGINES[COMMANDS[command]]
        if len(message.attachments) != 1:
            await message.reply('Please attach exactly one source file per command; see ?help for extensions.', mention_author=False)
            return
        if not permissions.attach_files:
            await message.reply('I need the **Attach Files** permission in this channel to return the result.', mention_author=False)
            return
        try:
            self.gate.enter(message.author.id)
        except JobError as exc:
            await message.reply(str(exc), mention_author=False)
            return
        job_id = uuid.uuid4().hex[:12]
        progress = None
        try:
            progress = await message.reply(f'Running **{engine.name}** (up to {self.settings.worker_timeout // 60:g} minutes). '
                                           'I will return any source output produced, even if it is partial or has errors.', mention_author=False)
            with tempfile.TemporaryDirectory(prefix='deobf-job-') as tmp:
                work = Path(tmp)
                assert self.session is not None
                await download_attachment(self.session, message.attachments[0], work / ('input' + engine.suffix),
                                          self.settings.max_input_bytes, engine.extensions)
                result = await run_engine(engine.name, work, self.settings.worker_timeout,
                                          min(message.guild.filesize_limit, 8 * 1024 * 1024))
                status = 'output' if result.source else 'no-output'
                if result.source:
                    upload = discord.File(result.source, filename=('luraph-constants.lua' if result.source.name=='luraph-constants.lua' else 'luraph.application.candidate.lua' if result.source.name=='application.candidate.lua' else 'luraph.dump.lua' if engine.name=='luraph' and result.source.name=='luraph.dump.lua' else 'luraph-v15.application.lua' if result.source.name=='v15.application.lua' else 'luraph-v15.trace.lua' if result.source.name=='v15.trace.lua' else engine.name + '.output' + engine.suffix))
                    uploads=[upload]
                    if engine.name=='v15':
                        other=select_source(result.source.parent,(('v15.trace.lua',) if result.source.name=='v15.application.lua' else ('v15.application.lua',)),min(message.guild.filesize_limit,8*1024*1024))
                        if other and other!=result.source:
                            uploads.append(discord.File(other,filename=('luraph-v15.trace.lua' if other.name=='v15.trace.lua' else 'luraph-v15.application.lua')))
                    if engine.name=='luraph':
                        readable=select_source(result.source.parent,(('luraph.dump.lua',) if result.source.name=='application.candidate.lua' else ('readable.vm.lua',)),min(message.guild.filesize_limit,8*1024*1024))
                        if readable and readable!=result.source:
                            uploads.append(discord.File(readable,filename=('luraph.dump.lua' if readable.name=='luraph.dump.lua' else 'luraph.readable.lua')))
                    try:
                        await progress.edit(content=result.summary(), attachments=uploads)
                    finally:
                        for item in uploads:item.close()
                else:
                    await progress.edit(content=result.summary())
            log.info('Prefix job %s completed (%s)', job_id, status)
        except JobError as exc:
            if progress:
                await progress.edit(content=str(exc))
            log.info('Prefix job %s rejected or unsupported', job_id)
        except (aiohttp.ClientError, TimeoutError):
            if progress:
                await progress.edit(content='Attachment download failed or timed out. Re-upload and try again.')
            log.warning('Prefix job %s attachment transport failure', job_id)
        except Exception as exc:
            log.error('Prefix job %s failed (%s)', job_id, type(exc).__name__)
            if progress:
                try:
                    await progress.edit(content=f'Job {job_id} failed. Check my channel permissions and try again.')
                except discord.HTTPException:
                    pass
        finally:
            self.gate.leave(message.author.id)


def main() -> None:
    load_dotenv(ROOT / '.env')
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
    logging.getLogger('discord').setLevel(logging.WARNING)
    bot = DeobfuscatorBot(Settings.load())
    bot.run(bot.settings.token, log_handler=None)

if __name__ == '__main__':
    main()
