"""Trusted launcher. Never import or execute uploaded Lua/Python files."""
import os
import sys

if __name__ == '__main__':
    if len(sys.argv) != 5:
        raise SystemExit('Invalid worker invocation')
    if os.name == 'posix':
        import resource
        resource.setrlimit(resource.RLIMIT_CPU, (20, 22))
        resource.setrlimit(resource.RLIMIT_FSIZE, (16 * 1024 * 1024, 16 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_NOFILE, (64, 64))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        # Node/V8 reserves address space beyond its heap. The container supplies
        # the hard RSS limit; this is a generous secondary address-space bound.
        if sys.platform == 'linux':
            resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    node, script, input_file, output = sys.argv[1:]
    os.execv(node, [node, '--max-old-space-size=192', script, input_file, output])
