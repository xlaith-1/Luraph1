"""Fixed command registry and best-effort, OS-isolated engine runner."""
from __future__ import annotations
import asyncio
from dataclasses import dataclass
import math
import json
import hashlib
import os
from pathlib import Path
import shutil
import signal
import stat
import sys
import time
from .config import ROOT
from .jobs import JobError

@dataclass(frozen=True)
class Engine:
    name: str
    language: str
    aliases: tuple[str, ...] = ()
    note: str = ''
    @property
    def suffix(self): return '.js' if self.language == 'JavaScript' else '.lua'
    @property
    def extensions(self): return frozenset({self.suffix, '.txt', *(['.luau'] if self.name == 'v15' else [])})

ENGINES = {
    e.name: e for e in [
        Engine('v15', 'Lua', (), 'Luraph v15 devirtualization. Executes instrumented input in a fake Roblox environment inside a networkless OS sandbox. Partial application candidate or behaviour trace; not certified complete.'),
        Engine('luraph', 'Lua', (), 'Luraph constant dumping: grouped constants where supported, or a flat string inventory for the reviewed periodic-payload family. Bounded data capture, no application execution; partial coverage. Also imports numbered string dumps.'),
    ]
}
COMMANDS = {'?' + alias: e.name for e in ENGINES.values() for alias in (e.name, *e.aliases)}
HELP_COMMANDS = {'?help', '?deobfhelp', '?engines'}
STATUS_COMMANDS = {'?ping', '?status', '?deobfstatus'}
ALL_COMMANDS = frozenset(COMMANDS) | HELP_COMMANDS | STATUS_COMMANDS

def help_text(timeout: int, engine: str | None = None) -> str:
    selected = [ENGINES[engine]] if engine in ENGINES else list(ENGINES.values())
    lines = ['**Deobfuscator commands** — attach one file to the **same message**.']
    for e in selected:
        exts='/'.join(sorted(e.extensions))
        lines.append(f'`?{e.name}` — {e.language} ({exts}). {e.note}')
    lines += ['`?help [engine]` • `?status` • `?ping`',
              f'**Output:** best-effort code, including partial or error-containing output. Up to {timeout // 60:g} minutes per job; engines may finish sooner.',
              'On failure/timeout, any source file already written is returned. No source produced means no attachment.',
              '**Privacy:** replies and files are public in this channel. Maximum input: 8 MiB.']
    return '\n'.join(lines)

@dataclass
class EngineResult:
    engine: str
    source: Path | None
    returncode: int | None
    timed_out: bool
    elapsed: float
    stopped_reason: str | None = None
    diagnostic: str | None = None
    def summary(self) -> str:
        if self.timed_out:
            state = 'Time limit reached'
        elif self.stopped_reason:
            state = 'Worker stopped at a resource limit'
        elif self.returncode:
            state = 'Engine stopped with an error'
        else:
            state = 'Engine finished'
        if self.source:
            if self.engine == 'v15':
                kind = 'devirtualized application candidate' if self.source.name == 'v15.application.lua' else 'observed-behaviour trace'
                return f'{state} after {self.elapsed:.1f}s. **Partial Luraph v15 {kind} attached.** Instrumented input ran in a fake Roblox environment inside the isolated worker. Not verified complete or equivalent.'
            if self.source.name == 'luraph-constants.lua':
                # Counts come only from a syntax-checked result report, never
                # the reference dump, the version banner, or a filename.
                try:
                    report_path = self.source.parent / 'report.json'
                    if report_path.stat().st_size > 262144: raise ValueError('report limit')
                    report = json.loads(report_path.read_text())
                    count, protos = report.get('constantCount'), report.get('prototypeCount')
                    valid = report.get('stage') == 'download-ready' and report.get('syntaxChecked') is True and type(count) is int and 0 < count <= 1000000
                    if valid and not self.timed_out and not self.returncode and not self.stopped_reason:
                        if report.get('groupingRecovered') is True and type(protos) is int and 0 < protos <= 100000:
                            return f'Successfully dumped {count} constants across {protos} prototypes. Partial capture; not reconstructed source.'
                        if report.get('inventoryOnly') is True:
                            return f'Successfully dumped {count} string constants. Flat inventory only; prototype grouping was not recovered.'
                except (OSError, ValueError, TypeError):
                    pass
                return f'{state} after {self.elapsed:.1f}s. **Partial constant dump attached**. Some variants provide a flat string inventory only; check the file header for grouping/scalar limitations. Not reconstructed source.'
            if self.source.name == 'application.candidate.lua':
                return f'{state} after {self.elapsed:.1f}s. **Application candidate attached**, with captured prototype data. Strings are inferred; the original decoder is not fully verified. Exact reviewed sample support, not a general Luraph decompiler.'
            if self.source.name == 'luraph.dump.lua':
                return f'{state} after {self.elapsed:.1f}s. **Best-effort dump attached**, with readable VM Lua where available. Capture is partial; this is not original-source reconstruction.'
            if self.source.name == 'strings.inventory.lua':
                return f'{state} after {self.elapsed:.1f}s. **String inventory attached**, not reconstructed application source. May include unrelated game/runtime strings.'
            if self.source.name == 'unpacked.vm.lua':
                return f'{state} after {self.elapsed:.1f}s. **Unpacked VM source attached** (partial result, not reconstructed application code).'
            return (f'{state} after {self.elapsed:.1f}s. **Best-effort output attached** '
                    '(possibly partial, still obfuscated, or containing errors; not verified).')
        detail = (' ' + self.diagnostic) if self.diagnostic else ''
        return f'{state} after {self.elapsed:.1f}s.{detail} No source file was produced, so there is nothing to attach.'

def safe_worker_diagnostic(engine: str, stderr: bytes) -> str | None:
    # Map known worker failures to fixed text. Never echo raw uploaded source,
    # private filenames, URLs, or arbitrary exception strings back into chat.
    text = stderr.decode('utf8', errors='replace').lower()
    if engine == 'v15' and 'v15_' in text:
        if 'v15_unsupported' in text:
            return 'This input did not pass the Luraph v15 detection/VM-structure checks. No generic script execution fallback was used.'
        if 'v15_isolation_required' in text:
            return 'The v15 worker requires its configured OS sandbox.'
        return 'The v15 capture/lifting pipeline did not finish successfully. Any validated checkpoint already written is returned; full recovery is not guaranteed.'
    if engine == 'luraph' and 'luraph_constants_unsupported' in text:
        return 'No validated constant dump was produced for this variant. No protected input or empty dump is being returned.'
    if engine == 'luraph' and 'luraph_no_capture' in text:
        return 'No useful data was captured from this variant. The bot will not send an empty dump or relabel the original protected input as readable code.'
    if engine == 'luraph' and 'luraph_static_unpack_unsupported' in text:
        return 'The available Luraph paths did not recover source from this variant. A numbered string dump can also be imported with ?luraph.'
    if 'no ironbrew bytecode payload candidate was found' in text:
        return 'IronBrew2 could not find an IronBrew bytecode payload. This may be readable Lua, another obfuscator, or an unsupported variant. Choose the matching engine with ?help.'
    if 'hasnt been obfuscated using hercules' in text:
        return 'Hercules could not decode this input. It may use a different obfuscator or an unsupported Hercules variant.'
    if 'hasnt been obfuscated using xhider' in text:
        return 'XHider could not decode this input. It may use a different obfuscator or an unsupported XHider variant.'
    if 'bwrap:' in text:
        return 'The host could not start the isolated worker. This is a host setup problem, not a deobfuscation result.'
    if any(t in text for t in ['cannot find package', 'cannot find module', 'you must install or update .net', 'no lua runtime found']):
        return 'A required engine dependency is missing. The bot owner needs to rebuild/check the installation.'
    if engine == 'goofyscator' and ('[parse]' in text or '[discovery]' in text):
        return 'Goofyscator did not recognize a supported wrapper in this input.'
    if engine == 'goofyscator' and '[probe]' in text:
        return 'Goofyscator stopped during its isolated VM probe; this input or runtime behavior is not currently supported.'
    return None

def command_for(engine: str, timeout: int) -> tuple[list[str], tuple[str, ...]]:
    if engine not in ENGINES: raise JobError('Unknown deobfuscation engine.')
    if engine == 'v15':
        return ['/usr/bin/python3', '/opt/legacy/worker/luraph-v15-cli.py', '/job/input.lua', '/job/result'], ('v15.application.lua', 'v15.trace.lua')
    source = '/job/input' + ENGINES[engine].suffix
    output = '/job/result/output' + ENGINES[engine].suffix
    upstream = '/opt/engines/upstream'
    if engine in {'goofyscator', 'luaobfuscator', 'obfuscator.io'}:
        return ['node', '/opt/engines/run-node.mjs', engine, source, output, str(timeout)], ('output' + ENGINES[engine].suffix,)
    if engine in {'hercules', 'xhider', 'ironbrew2'}:
        dll = {'hercules': 'HerculesDeobfuscator', 'xhider': 'XHiderDeobfuscator', 'ironbrew2': 'IronBrew2Deobfuscator'}[engine]
        target = '/job/result' if engine == 'ironbrew2' else output
        return ['dotnet', f'/opt/engines/runtime/{engine}/{dll}.dll', source, target], ('input_deobfuscated.lua',) if engine == 'ironbrew2' else ('output.lua',)
    script = 'luraph-constants-cli.mjs' if engine == 'luraph' else 'index.mjs'
    command = ['node', '/opt/legacy/worker/' + script, source, '/job/result']
    if engine == 'luraph': command.append('/usr/bin/python3')
    if engine == 'luraph': return command, ('luraph-constants.lua', 'strings.inventory.lua')
    return command, ('recovered.lua', 'standalone.candidate.lua', 'deobfuscated.lua', 'main.analysis.lua', 'strings.inventory.lua', 'unpacked.vm.lua')

def select_source(directory: Path, candidates: tuple[str, ...], max_bytes: int) -> Path | None:
    # Only known source filenames; never package maps, logs, bytecode, or input.
    if directory.is_symlink() or not directory.is_dir(): return None
    for name in candidates:
        p = directory / name
        try: info = p.lstat()
        except FileNotFoundError: continue
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1: continue
        if info.st_size == 0: continue
        if info.st_size > min(max_bytes, 16 * 1024 * 1024):
            raise JobError('A source file was produced, but it exceeds the upload limit.')
        # Lua/JS source must not be a bytecode/binary artifact mislabeled as code.
        with p.open('rb') as f: head = f.read(4096)
        if b'\x00' in head or head.startswith((b'\x1bLua', b'\x1bLJ')): continue
        return p
    return None

def dotnet_root() -> Path:
    configured = os.getenv('DOTNET_ROOT')
    if configured: return Path(configured)
    executable = shutil.which('dotnet')
    return Path(executable).resolve().parent if executable else Path('/opt/dotnet')

def luraph_installation_valid(root: Path = ROOT, manifest_name: str = 'luraph-release-manifest.json') -> bool:
    """Detect accidental partial installs; this is not a signed trust boundary."""
    try:
        manifest_path = root / manifest_name
        if manifest_path.stat().st_size > 65536: return False
        manifest = json.loads(manifest_path.read_text())
        files = manifest.get('files')
        if manifest.get('schema') != 1 or not isinstance(files, dict) or len(files) < 7: return False
        for relative, expected in files.items():
            path = root / relative
            if path.resolve().is_relative_to(root.resolve()) is False: return False
            if not isinstance(expected, str) or len(expected) != 64: return False
            if hashlib.sha256(path.read_bytes()).hexdigest() != expected: return False
        return True
    except (OSError, ValueError, TypeError):
        return False

def engine_unavailable_reason(engine: str) -> str | None:
    if engine not in ENGINES: return 'Unknown engine.'
    if engine == 'luraph' and not luraph_installation_valid(): return 'The Luraph installation is incomplete or does not match its release manifest. Reinstall the complete current release.'
    if engine == 'v15':
        if not luraph_installation_valid(manifest_name='v15-release-manifest.json'):
            return 'The v15 installation is incomplete or its integrity check failed. Install the complete v0.7 release (including the pinned Luau runtime).'
        for executable in ('luau', 'luau-ast', 'luau-compile'):
            if not os.access(ROOT / 'engines/luraph-v15/runtime' / executable, os.X_OK):
                return 'The v15 runtime is not executable. Run chmod +x engines/luraph-v15/runtime/* or rebuild using scripts/build_v15_runtime.py.'
    for executable in ['bwrap', 'node']:
        if not shutil.which(executable): return f'{executable} is not installed. Run the build/setup steps.'
    if engine == 'goofyscator' and not Path('/usr/bin/lua5.4').exists(): return 'Lua 5.4 is not installed.'
    if engine in {'hercules', 'ironbrew2'} and not shutil.which('java'): return 'Java is not installed.'
    if engine in {'hercules', 'ironbrew2', 'xhider'}:
        if not (dotnet_root() / 'dotnet').is_file(): return '.NET 8 runtime is not installed.'
        if not list((ROOT / 'engines' / 'runtime' / engine).glob('*Deobfuscator.dll')): return 'This engine has not been built. Run scripts/build_engines.sh.'
    if engine == 'wearedevs' and not (ROOT / 'node_modules' / 'luaparse').is_dir(): return 'Legacy Node dependencies are missing; run npm ci.'
    dependency = {'luaobfuscator': ('luaobfuscator', 'luaparse'), 'obfuscator.io': ('obfuscator.io-debofuscator', 'acorn')}.get(engine)
    if dependency and not (ROOT / 'engines/upstream' / dependency[0] / 'node_modules' / dependency[1]).is_dir(): return 'Engine Node dependencies are missing; run scripts/build_engines.sh.'
    return None

def sandbox_command(work: Path, command: list[str], timeout: int) -> list[str]:
    bwrap = shutil.which('bwrap')
    if not bwrap: raise JobError('Bubblewrap is missing. Engines are disabled until OS isolation is installed.')
    dotnet = dotnet_root()
    mounts = ['--ro-bind', '/usr', '/usr', '--ro-bind', '/lib', '/lib', '--symlink', 'usr/bin', '/bin']
    for path in ['/lib64', '/etc/alternatives', '/etc/ld.so.cache']:
        if Path(path).exists(): mounts += ['--ro-bind', path, path]
    if dotnet.is_dir(): mounts += ['--ro-bind', str(dotnet.resolve()), '/opt/dotnet']
    mounts += ['--ro-bind', str(ROOT / 'engines'), '/opt/engines',
               '--ro-bind', str(ROOT / 'worker'), '/opt/legacy/worker']
    # Only explicit recovery/capture dependencies, never the research workspace.
    for relative in ('recover-literal147.mjs', 'instrument147.mjs', 'vendor/luaparse.cjs', 'runtime-dump.lua', 'trace147-recorder.lua', 'static-data-eval.mjs', 'normalize_for_analysis.py', 'constant-capture.mjs', 'payload-analysis.mjs', 'periodic-pool.mjs', 'serialized-pool.mjs', 'detect-input.mjs', 'dispatch147.mjs', 'unpack_container.py', 'unpack_lzma.py'):
        mounts += ['--ro-bind', str(ROOT / 'tools/luraph' / relative),
                   '/opt/legacy/tools/luraph/' + relative]
    modules = ROOT / 'node_modules'
    if modules.exists(): mounts += ['--ro-bind', str(modules), '/opt/legacy/node_modules']
    python_env = []
    if sys.prefix != sys.base_prefix:
        import sysconfig
        packages = Path(sysconfig.get_path('purelib'))
        if packages.is_dir():
            mounts += ['--ro-bind', str(packages), '/opt/python-packages']
            python_env = ['--setenv', 'PYTHONPATH', '/opt/python-packages']
    # No bot directory, token, uploads directory, host /home, or network mount.
    return [sys.executable, str(ROOT / 'bot' / 'engine_limits.py'), str(timeout), bwrap,
            '--unshare-all', '--die-with-parent', '--new-session', '--cap-drop', 'ALL',
            *mounts, '--proc', '/proc', '--dev', '/dev', '--size', str(128 * 1024 * 1024), '--tmpfs', '/tmp',
            '--bind', str(work.resolve()), '/job', '--chdir', '/job', '--clearenv',
            '--setenv', 'PATH', '/opt/dotnet:/usr/bin:/bin', '--setenv', 'HOME', '/tmp',
            '--setenv', 'ENGINE_TIMEOUT_SECONDS', str(timeout),
            '--setenv', 'LURAPH_ISOLATED', '1',
            '--setenv', 'LANG', 'C.UTF-8', '--setenv', 'TMPDIR', '/tmp', *python_env,
            '--setenv', 'DOTNET_ROOT', '/opt/dotnet', '--setenv', 'DOTNET_CLI_TELEMETRY_OPTOUT', '1',
            '--setenv', 'DOTNET_GCHeapHardLimit', '0x10000000',
            '--setenv', 'JAVA_TOOL_OPTIONS', '-Xmx192m -XX:CompressedClassSpaceSize=32m -XX:ReservedCodeCacheSize=32m -XX:+UseSerialGC',
            '--setenv', 'NODE_OPTIONS', '--max-old-space-size=1024', '--', *command]

async def run_engine(engine: str, work: Path, timeout: int, max_bytes: int) -> EngineResult:
    if not isinstance(timeout, int) or not 1 <= timeout <= 1800: raise JobError('Invalid worker time limit.')
    missing = engine_unavailable_reason(engine)
    if missing: raise JobError(missing)
    command, candidates = command_for(engine, timeout)
    work = work.resolve()
    (work / 'result').mkdir(exist_ok=True)
    proc = await asyncio.create_subprocess_exec(*sandbox_command(work, command, timeout),
            cwd=work, env={'PATH': os.getenv('PATH', ''), 'LANG': 'C.UTF-8'},
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, start_new_session=True)
    started = time.monotonic(); timed_out = False; reason = None
    stderr_tail = bytearray()
    async def drain(stream, capture=False):
        count = 0
        while chunk := await stream.read(16384):
            count += len(chunk)
            if capture:
                stderr_tail.extend(chunk)
                del stderr_tail[:-8192]
            if count > 256 * 1024: raise JobError('worker-log-limit')
        return count
    tasks = [asyncio.create_task(drain(proc.stdout)), asyncio.create_task(drain(proc.stderr, True)), asyncio.create_task(proc.wait())]
    async def kill():
        # Namespace init death terminates all descendants, including Lua/Java probes.
        try: os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError: pass
        await proc.wait()
    try:
        await asyncio.wait_for(asyncio.gather(*tasks), timeout)
    except asyncio.TimeoutError:
        timed_out = True; await kill()
    except JobError:
        reason = 'worker-log-limit'; await kill()
    except asyncio.CancelledError:
        await kill(); raise
    finally:
        for task in tasks:
            if not task.done(): task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)
    source = select_source(work / 'result', candidates, max_bytes)
    return EngineResult(engine, source, proc.returncode, timed_out, time.monotonic()-started, reason, safe_worker_diagnostic(engine, bytes(stderr_tail)))
