"""Restart the Discord client after exits; cannot survive the hosting VM stopping."""
from __future__ import annotations
import asyncio
import logging
import os
import signal
import sys
import tempfile
import time
from .config import ROOT

log = logging.getLogger('deobf_supervisor')

async def supervise(command=None, *, stop=None, base_delay=2, max_restarts=None):
    command = command or [sys.executable, '-m', 'bot.main']
    stop = stop or asyncio.Event()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, stop.set)
    restarts = 0
    delay = base_delay
    while not stop.is_set():
        # Crash leftovers are removed when the child exits. Inputs and output
        # checkpoints are private to this client session, not stored in the ZIP.
        with tempfile.TemporaryDirectory(prefix='deobf-session-') as session:
            environment = os.environ.copy()
            environment['TMPDIR'] = session
            proc = await asyncio.create_subprocess_exec(*command, cwd=ROOT, env=environment, start_new_session=True)
            started = time.monotonic()
            log.info('Bot client started: pid=%s restart=%s', proc.pid, restarts)
            waiter = asyncio.create_task(proc.wait())
            stopping = asyncio.create_task(stop.wait())
            try:
                await asyncio.wait({waiter, stopping}, return_when=asyncio.FIRST_COMPLETED)
                if stop.is_set() and proc.returncode is None:
                    try: os.killpg(proc.pid, signal.SIGTERM)
                    except ProcessLookupError: pass
                    try: await asyncio.wait_for(asyncio.shield(waiter), 5)
                    except asyncio.TimeoutError:
                        try: os.killpg(proc.pid, signal.SIGKILL)
                        except ProcessLookupError: pass
                        await waiter
                else:
                    await waiter
            finally:
                stopping.cancel()
                await asyncio.gather(stopping, return_exceptions=True)
                # Any surviving worker launcher gets the same termination signal;
                # Bubblewrap also kills its descendants when its namespace exits.
                try: os.killpg(proc.pid, signal.SIGKILL)
                except ProcessLookupError: pass
            log.warning('Bot client exited: code=%s', proc.returncode)
        if stop.is_set() or max_restarts is not None and restarts >= max_restarts:
            return proc.returncode
        restarts += 1
        delay = base_delay if time.monotonic()-started >= 60 else min(60, max(base_delay, delay * 2))
        log.info('Restarting client in %.1fs', delay)
        try: await asyncio.wait_for(stop.wait(), delay)
        except asyncio.TimeoutError: pass
    return 0

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s %(message)s')
    asyncio.run(supervise())
