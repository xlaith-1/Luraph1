"""Fetch pinned public research samples as inert bytes, never execute them.
Usage: python tools/luraph/fetch_corpus.py MANIFEST_JSON OUTPUT_DIR
The manifest has repository, commit and GitHub tree files (path/sha/size).
Only seven development samples are fetched; four holdouts are reserved by name.
"""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import sys
import urllib.request


def select(manifest):
    rows=sorted((r for r in manifest['files'] if r['path'].endswith('.lua')),key=lambda r:(r['size'],r['path']))
    # Predetermined size strata; selection is independent of decoder results.
    picked=[]
    for target in (0,100000,200000,350000,500000,800000,1200000):
        choices=[r for r in rows if r not in picked]
        picked.append(min(choices,key=lambda r:(abs(r['size']-target),r['path'])))
    rest=[r for r in rows if r not in picked and r['size']<=1500000]
    holdouts=sorted(rest,key=lambda r:hashlib.sha256(r['path'].encode()).digest())[:4]
    return picked,holdouts


def fetch(manifest,row,directory):
    relative=row['path']
    if not relative.startswith('Luraph/v14.7/') or Path(relative).name!=relative.split('/')[-1]:
        raise ValueError('Unexpected sample path')
    url='https://raw.githubusercontent.com/terrorlua/obfuscator-samples/'+manifest['commit']+'/'+relative
    req=urllib.request.Request(url,headers={'User-Agent':'Static-Luraph-research'})
    with urllib.request.urlopen(req,timeout=60) as response:data=response.read(2*1024*1024+1)
    if len(data)!=row['size']:raise ValueError('Size mismatch or download cap')
    blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if blob!=row['sha']:raise ValueError('Git blob mismatch')
    (directory/Path(relative).name).write_bytes(data)
    return {**row,'sha256':hashlib.sha256(data).hexdigest(),'url':url}


def main():
    manifest=json.loads(Path(sys.argv[1]).read_text())
    directory=Path(sys.argv[2]);directory.mkdir(parents=True,exist_ok=True)
    development,holdouts=select(manifest)
    (directory.parent/'split.json').write_text(json.dumps({'commit':manifest['commit'],'development':development,'holdouts':holdouts,'holdoutsInspected':False},indent=2))
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        verified=list(pool.map(lambda row:fetch(manifest,row,directory),development))
    (directory.parent/'downloads.json').write_text(json.dumps(verified,indent=2))
    print(json.dumps({'downloaded':len(verified),'bytes':sum(r['size'] for r in verified),'reservedHoldouts':len(holdouts),'executedSamples':False}))

if __name__=='__main__':main()
