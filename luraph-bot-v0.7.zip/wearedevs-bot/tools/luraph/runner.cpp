// OFFLINE RESEARCH ONLY. No require, filesystem, HTTP, process APIs or Python
// objects are installed. Instrumented bootstrap only; never call the payload.
#include "lua.h"
#include "lualib.h"
#include "luacode.h"
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <unicode/unorm2.h>
#include <unicode/ustring.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <unordered_map>
#include <vector>
#include "research_random.hpp"
static size_t allocated=0;
static void* alloc(void*,void* p,size_t old,size_t n){
    if(!p)old=0;
    if(!n){allocated-=old;free(p);return nullptr;}
    if(allocated-old+n>128*1024*1024)return nullptr;
    void* q=realloc(p,n);if(q)allocated=allocated-old+n;return q;
}
static auto deadline=std::chrono::steady_clock::now();
static void interrupt(lua_State* L,int){if(std::chrono::steady_clock::now()>deadline){std::cerr<<"Research time limit reached\n";std::exit(124);}}
static std::string quote(const char* p,size_t n){
    std::ostringstream s;s<<'"';const char* hex="0123456789abcdef";
    for(size_t i=0;i<n;i++){unsigned char c=p[i];if(c=='"'||c=='\\')s<<'\\'<<char(c);else if(c<32||c>=127)s<<"\\u00"<<hex[c>>4]<<hex[c&15];else s<<char(c);}s<<'"';return s.str();
}
static std::unordered_map<const void*,int> ids;
static size_t items=0;
static std::string dump(lua_State* L,int index,int depth=0){
    if(++items>250000||depth>100)throw std::runtime_error("Dump budget reached");
    if(!lua_checkstack(L,8))throw std::runtime_error("Dump stack limit");
    index=lua_absindex(L,index);
    switch(lua_type(L,index)){
    case LUA_TNIL:return "null";
    case LUA_TBOOLEAN:return lua_toboolean(L,index)?"true":"false";
    case LUA_TNUMBER:{std::ostringstream s;s.precision(17);s<<lua_tonumber(L,index);return "{\"number\":"+quote(s.str().c_str(),s.str().size())+"}";}
    case LUA_TSTRING:{size_t n;const char* p=lua_tolstring(L,index,&n);return quote(p,n);}
    case LUA_TTABLE:{const void* ptr=lua_topointer(L,index);if(ids.count(ptr))return "{\"ref\":"+std::to_string(ids[ptr])+"}";int id=ids.size()+1;ids[ptr]=id;std::string s="{\"id\":"+std::to_string(id)+",\"entries\":[";bool comma=false;lua_pushnil(L);while(lua_next(L,index)){if(comma)s+=",";comma=true;s+="["+dump(L,-2,depth+1)+","+dump(L,-1,depth+1)+"]";lua_pop(L,1);}return s+"]}";}
    case LUA_TFUNCTION:{
        lua_pushvalue(L,index);lua_Debug ar{};lua_getinfo(L,-1,"sn",&ar);lua_pop(L,1);
        std::string result="{\"type\":\"function\",\"name\":"+quote(ar.name?ar.name:"",strlen(ar.name?ar.name:""))+",\"source\":"+quote(ar.short_src?ar.short_src:"",strlen(ar.short_src?ar.short_src:""));
        if(!lua_iscfunction(L,index))for(int u=1;u<=64;u++){
            if(!lua_getupvalue(L,index,u))break;
            if(lua_istable(L,-1)){lua_rawgeti(L,-1,10);if(lua_istable(L,-1))result+=",\"vmInstructions\":"+std::to_string(lua_objlen(L,-1));lua_pop(L,1);}
            lua_pop(L,1);
        }
        return result+"}";
    }
    case LUA_TUSERDATA:{std::string kind=luaL_typename(L,index);if(lua_getmetatable(L,index)){lua_pushstring(L,"__index");lua_rawget(L,-2);if(!lua_istable(L,-1)){lua_pop(L,1);lua_pushstring(L,"__researchFields");lua_rawget(L,-2);}std::string fields=lua_istable(L,-1)?dump(L,-1,depth+1):"null";lua_pop(L,2);return "{\"userdata\":"+quote(kind.c_str(),kind.size())+",\"fields\":"+fields+"}";}return "{\"userdata\":"+quote(kind.c_str(),kind.size())+"}";}
    case LUA_TBUFFER:{size_t n;const char* p=(const char*)lua_tobuffer(L,index,&n);if(n>2*1024*1024)throw std::runtime_error("Buffer budget reached");return "{\"buffer\":"+quote(p,n)+"}";}
    default:return "{\"type\":"+quote(lua_typename(L,lua_type(L,index)),strlen(lua_typename(L,lua_type(L,index))))+"}";
    }
}
static int normalizeUnicode(lua_State* L,bool compose){
size_t n;const char* input=luaL_checklstring(L,1,&n);if(n>1024*1024)luaL_error(L,"Unicode input budget");
UErrorCode status=U_ZERO_ERROR;int32_t len=0;u_strFromUTF8(nullptr,0,&len,input,int32_t(n),&status);if(status!=U_BUFFER_OVERFLOW_ERROR&&U_FAILURE(status))luaL_error(L,"invalid UTF-8");
std::vector<UChar> in(len+1);status=U_ZERO_ERROR;u_strFromUTF8(in.data(),len+1,nullptr,input,int32_t(n),&status);
const UNormalizer2* normal=compose?unorm2_getNFCInstance(&status):unorm2_getNFDInstance(&status);int32_t outlen=unorm2_normalize(normal,in.data(),len,nullptr,0,&status);if(status!=U_BUFFER_OVERFLOW_ERROR&&U_FAILURE(status))luaL_error(L,"normalization error");
std::vector<UChar> out(outlen+1);status=U_ZERO_ERROR;unorm2_normalize(normal,in.data(),len,out.data(),outlen+1,&status);int32_t bytes=0;u_strToUTF8(nullptr,0,&bytes,out.data(),outlen,&status);if(status!=U_BUFFER_OVERFLOW_ERROR&&U_FAILURE(status))luaL_error(L,"normalization conversion error");
std::vector<char> result(bytes+1);status=U_ZERO_ERROR;u_strToUTF8(result.data(),bytes+1,nullptr,out.data(),outlen,&status);if(U_FAILURE(status))luaL_error(L,"normalization conversion error");lua_pushlstring(L,result.data(),bytes);return 1;
}
static int normalizeNFC(lua_State* L){return normalizeUnicode(L,true);}
static int normalizeNFD(lua_State* L){return normalizeUnicode(L,false);}
static int blockedGraphemes(lua_State* L){luaL_checkstring(L,1);luaL_error(L,"UNIMPLEMENTED_RESEARCH_API:utf8.graphemes");}
static int blockedDebug(lua_State* L){const char* name=lua_tostring(L,lua_upvalueindex(1));luaL_error(L,"UNIMPLEMENTED_RESEARCH_API:debug.%s",name);}
static int dataDisplay(lua_State* L){lua_pushvalue(L,lua_upvalueindex(1));return 1;}
static int signalEqual(lua_State* L){
for(int i=1;i<=2;i++){if(!lua_getmetatable(L,i)){lua_pushboolean(L,0);return 1;}lua_getfield(L,-1,"__researchFields");lua_getfield(L,-1,"__researchSignalIdentity");}
lua_pushboolean(L,!lua_isnil(L,-1)&&lua_rawequal(L,-1,-4));return 1;
}
static int researchData(lua_State* L){luaL_checkstring(L,1);luaL_checktype(L,2,LUA_TTABLE);luaL_checkstring(L,3);bool getter=lua_isfunction(L,4);bool setter=lua_isfunction(L,5);lua_newuserdata(L,1);lua_newtable(L);lua_pushvalue(L,1);lua_setfield(L,-2,"__type");if(!strcmp(lua_tostring(L,1),"Instance")||!strcmp(lua_tostring(L,1),"Enum")||!strcmp(lua_tostring(L,1),"Enums")||!strcmp(lua_tostring(L,1),"EnumItem")){lua_pushstring(L,"The metatable is locked");lua_setfield(L,-2,"__metatable");}if(!strcmp(lua_tostring(L,1),"RBXScriptSignal")){lua_getfield(L,LUA_REGISTRYINDEX,"researchSignalEqual");lua_setfield(L,-2,"__eq");}lua_pushvalue(L,2);lua_setfield(L,-2,"__researchFields");lua_pushvalue(L,getter?4:2);lua_setfield(L,-2,"__index");if(!strcmp(lua_tostring(L,1),"Instance")){lua_pushvalue(L,setter?5:2);lua_setfield(L,-2,"__newindex");}lua_pushvalue(L,3);lua_pushcclosure(L,dataDisplay,"__tostring",1);lua_setfield(L,-2,"__tostring");lua_setmetatable(L,-2);return 1;}
static void protectedError(lua_State* L){static int n=0;if(++n>30)return;const char* s=lua_tostring(L,-1);std::cerr<<"PROTECTED "<<(s?s:"non-string error")<<"\n";}
static int researchWait(lua_State* L){luaL_optnumber(L,1,0);return lua_yield(L,0);}
static int forwardMock(lua_State* L){
const char* name=lua_tostring(L,lua_upvalueindex(2));
const char* kind=lua_tostring(L,lua_upvalueindex(3));
if(name&&(!strcmp(name,"Connect")||!strcmp(name,"Disconnect"))){luaL_checktype(L,1,LUA_TUSERDATA);const char* expected=!strcmp(name,"Connect")?"RBXScriptSignal":"RBXScriptConnection";if(strcmp(luaL_typename(L,1),expected))luaL_argerror(L,1,expected);if(!strcmp(name,"Connect"))luaL_checktype(L,2,LUA_TFUNCTION);}
if(kind&&!strcmp(kind,"Random")&&name&&!strcmp(name,"new"))luaL_optnumber(L,1,0);
if(kind&&!strcmp(kind,"Path2DControlPoint")){for(int j=1;j<=lua_gettop(L)&&j<=3;j++)luaL_checktype(L,j,LUA_TUSERDATA);}
if(kind&&!strcmp(kind,"Instance")&&name&&!strcmp(name,"new"))luaL_checkstring(L,1);
if(name&&(!strcmp(name,"GetAsync")||!strcmp(name,"PostAsync")||!strcmp(name,"RequestAsync")||!strcmp(name,"GetService")||!strcmp(name,"IsA")||!strcmp(name,"IsStudio")||!strcmp(name,"IsClient")||!strcmp(name,"IsServer")||!strcmp(name,"Destroy")||!strcmp(name,"GetChildren"))){
luaL_checktype(L,1,LUA_TUSERDATA);if(strcmp(luaL_typename(L,1),"Instance")&&!(name&&!strcmp(name,"IsA")&&!strcmp(luaL_typename(L,1),"EnumItem")))luaL_argerror(L,1,"Instance expected");
if(!strcmp(name,"RequestAsync"))luaL_checktype(L,2,LUA_TTABLE);
if(!strcmp(name,"GetAsync")||!strcmp(name,"PostAsync")||!strcmp(name,"GetService")||!strcmp(name,"IsA"))luaL_checkstring(L,2);
if(!strcmp(name,"PostAsync"))luaL_checkstring(L,3);
}
if(name&&(!strcmp(name,"FromName")||!strcmp(name,"FromValue"))){luaL_checktype(L,1,LUA_TUSERDATA);if(strcmp(luaL_typename(L,1),"Enum"))luaL_argerror(L,1,"Enum expected");if(!strcmp(name,"FromName"))luaL_checkstring(L,2);else luaL_checknumber(L,2);}
if(name&&!strcmp(name,"WaitForChild")){luaL_checktype(L,1,LUA_TUSERDATA);luaL_checkstring(L,2);}
if(name&&!strcmp(name,"cancel"))luaL_checktype(L,1,LUA_TTHREAD);
if(name&&(!strcmp(name,"spawn")||!strcmp(name,"defer"))&&!lua_isthread(L,1))luaL_checktype(L,1,LUA_TFUNCTION);
if(name&&!strcmp(name,"delay")){luaL_checknumber(L,1);if(!lua_isthread(L,2))luaL_checktype(L,2,LUA_TFUNCTION);}
int count=lua_gettop(L);lua_pushvalue(L,lua_upvalueindex(1));lua_insert(L,1);lua_call(L,count,LUA_MULTRET);return lua_gettop(L);}
static int nativeMock(lua_State* L){luaL_checktype(L,1,LUA_TFUNCTION);const char* name=luaL_optstring(L,2,"researchMock");const char* kind=luaL_optstring(L,3,"");lua_pushvalue(L,1);lua_pushstring(L,name);lua_pushstring(L,kind);lua_pushcclosure(L,forwardMock,name,3);return 1;}
int main(int argc,char** argv){
    if(argc!=2)return 2;std::ifstream file(argv[1],std::ios::binary);std::string source((std::istreambuf_iterator<char>(file)),{});if(source.size()>1024*1024)return 2;
    lua_State* L=lua_newstate(alloc,nullptr);luaL_openlibs(L);registerRandom(L);lua_pushcfunction(L,signalEqual,"__eq");lua_setfield(L,LUA_REGISTRYINDEX,"researchSignalEqual");
    lua_getglobal(L,"debug");for(const char* name:{"resetmemorycategory","getmemorycategory","profileend","profilebegin","setmemorycategory"}){lua_pushstring(L,name);lua_pushcclosure(L,blockedDebug,name,1);lua_setfield(L,-2,name);}lua_pop(L,1);
    lua_getglobal(L,"utf8");lua_pushcfunction(L,normalizeNFC,"nfcnormalize");lua_setfield(L,-2,"nfcnormalize");lua_pushcfunction(L,normalizeNFD,"nfdnormalize");lua_setfield(L,-2,"nfdnormalize");lua_pushcfunction(L,blockedGraphemes,"graphemes");lua_setfield(L,-2,"graphemes");lua_pop(L,1);
    lua_pushcfunction(L,nativeMock,"researchNative");lua_setglobal(L,"__research_native");
    lua_pushcfunction(L,researchWait,"wait");lua_setglobal(L,"__research_wait");
    lua_pushcfunction(L,researchData,"researchData");lua_setglobal(L,"__research_userdata");
    for(const char* key:{"require","loadstring","loadfile","dofile","io","os","print"}){lua_pushnil(L);lua_setglobal(L,key);}
    luaL_sandbox(L);luaL_sandboxthread(L);
    size_t n=0;char* code=luau_compile(source.data(),source.size(),nullptr,&n);
    int status=luau_load(L,"@instrumented-bootstrap",code,n,0);free(code);
    deadline=std::chrono::steady_clock::now()+std::chrono::seconds(8);lua_callbacks(L)->interrupt=interrupt;lua_callbacks(L)->debugprotectederror=protectedError;
    if(!status)status=lua_resume(L,nullptr,0);
    for(int resumes=0;status==LUA_YIELD&&resumes<100;resumes++){lua_pushnumber(L,1.0/60.0);status=lua_resume(L,nullptr,1);}
    if(status){const char* error=lua_tostring(L,-1);std::cerr<<"status="<<status<<" "<<(error?error:"error")<<"\n";lua_close(L);return 1;}
    try{std::cout<<dump(L,-1)<<"\n";}catch(const std::exception& e){std::cerr<<e.what()<<"\n";lua_close(L);return 1;}
    lua_close(L);return 0;
}
