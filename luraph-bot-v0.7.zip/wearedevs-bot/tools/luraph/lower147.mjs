// Non-executing IR/CFG research stage. Never emits recovered.lua.
// Usage: node tools/luraph/lower147.mjs DATA_ANALYSIS_DIR NEW_OUTPUT_DIR
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import {InstructionLowerer,lowerFrame147} from './ir147.mjs';
import {InitialImageCFG} from './cfg147.mjs';
const [input,output]=process.argv.slice(2);
if(!input||!output)throw Error('Expected analysis directory and new output directory');
fs.mkdirSync(output);
function load(name){
 let file=path.join(input,name+'.json'),packed=false;
 if(!fs.existsSync(file)){file+='.gz';packed=true;}
 if(fs.statSync(file).size>16*1024*1024)throw Error('Research artifact size limit');
 const data=fs.readFileSync(file);
 return JSON.parse((packed?zlib.gunzipSync(data,{maxOutputLength:16*1024*1024}):data).toString('utf8'));
}
let report={status:'blocked',fullRecoveryVerified:false,programCallsExecuted:false,error:null};
try{
 const description=load('dispatch.ast'),frame=load('selected-frame.ast'),graph=load('decoded-graph');
 const frameIR=lowerFrame147(description,frame);
 const ir=new InstructionLowerer(description,frame).lower(description.handlers);
 const analyzer=new InitialImageCFG(graph,description,ir),cfg=analyzer.analyze(),prefix=analyzer.traceEntry();
 fs.writeFileSync(path.join(output,'frame-setup-ir.json.gz'),zlib.gzipSync(JSON.stringify(frameIR)));
 fs.writeFileSync(path.join(output,'instruction-ir.json.gz'),zlib.gzipSync(JSON.stringify(ir)));
 fs.writeFileSync(path.join(output,'initial-cfg.json'),JSON.stringify(cfg,null,2));
 fs.writeFileSync(path.join(output,'entry-prefix.json'),JSON.stringify(prefix,null,2));
 report={...report,status:'ir-and-provisional-cfg',entryInstructions:cfg.instructionCount,loweredHandlers:ir.instructions.length,
  unresolvedInstructions:cfg.unresolvedInstructionCount,abstractPrefixSteps:prefix.trace.length,prefixStop:prefix.stop,
  limitations:['Initial-image edges are provisional, not a verified whole-program CFG.','Bounded entry tracing stops at unknown calls, effects or control flow.','No application source or full-source certificate is produced.']};
}catch(error){report.error=error.message;}
fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
