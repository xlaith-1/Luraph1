"""Bounded DATA-ONLY raw LZMA1 unpacking for observed v14.7 outer wrappers.
This does not execute the loader/VM or recover application source.
Observed wrapper: lc=3 (previous byte >>5), lp=0, pb=0 (position %1).
"""
import hashlib
import json
import lzma
from pathlib import Path
import sys

MAX_COMPRESSED=8*1024*1024
MAX_DECOMPRESSED=16*1024*1024
FILTER={'id':lzma.FILTER_LZMA1,'dict_size':16*1024*1024,'lc':3,'lp':0,'pb':0}

def unpack_raw(data,limit=MAX_DECOMPRESSED):
    if len(data)>MAX_COMPRESSED:raise ValueError('Compressed data exceeds research limit')
    if not isinstance(limit,int) or not 0<limit<=MAX_DECOMPRESSED:raise ValueError('Invalid decompression limit')
    decoder=lzma.LZMADecompressor(format=lzma.FORMAT_RAW,filters=[FILTER])
    result=decoder.decompress(data,max_length=limit+1)
    if len(result)>limit:raise ValueError('Decompressed data exceeds limit')
    if not decoder.eof:raise ValueError('Truncated raw LZMA stream')
    tail=decoder.unused_data
    if len(tail)>3 or any(tail):raise ValueError('Unexplained data after LZMA end marker')
    return result,len(tail)

if __name__=='__main__':
    try:
        source=Path(sys.argv[1]);target=Path(sys.argv[2])
        if source.stat().st_size>MAX_COMPRESSED:raise ValueError('Compressed data exceeds research limit')
        result,padding=unpack_raw(source.read_bytes())
        target.write_bytes(result)
        print(json.dumps({'ok':True,'bytes':len(result),'zeroPadding':padding,'sha256':hashlib.sha256(result).hexdigest(),'executedCode':False}))
    except (ValueError,lzma.LZMAError) as exc:
        print(json.dumps({'ok':False,'error':str(exc)}));sys.exit(1)
