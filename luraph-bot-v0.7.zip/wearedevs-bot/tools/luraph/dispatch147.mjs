// Structural dispatcher discovery/specialization. Internal VM analysis only;
// these ASTs are NOT reconstructed application source or a recovery certificate.
const UNKNOWN=Symbol('unknown');
const truth=x=>x!==null&&x!==false;
function walk(n,fn){if(!n||typeof n!=='object')return;if(n.type)fn(n);for(const [k,v]of Object.entries(n)){if(['range','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>walk(x,fn));else walk(v,fn);}}
function hasIdentifier(n,name){let found=false;walk(n,x=>{if(x.type==='Identifier'&&x.name===name)found=true;});return found;}
function condition(n,variable,opcode,known){
 if(!n)return true;
 if(['NumericLiteral','StringLiteral','BooleanLiteral'].includes(n.type))return n.value;
 if(n.type==='NilLiteral')return null;
 if(n.type==='Identifier')return known&&n.name===variable?opcode:UNKNOWN;
 if(n.type==='UnaryExpression'){const a=condition(n.argument,variable,opcode,known);if(a===UNKNOWN)return UNKNOWN;if(n.operator==='not')return !truth(a);if(n.operator==='-'&&typeof a==='number')return -a;return UNKNOWN;}
 if(n.type==='LogicalExpression'){
  const a=condition(n.left,variable,opcode,known);if(a===UNKNOWN)return UNKNOWN;
  if(n.operator==='and')return truth(a)?condition(n.right,variable,opcode,known):a;
  return truth(a)?a:condition(n.right,variable,opcode,known);
 }
 if(n.type==='BinaryExpression'){
  const a=condition(n.left,variable,opcode,known),b=condition(n.right,variable,opcode,known);if(a===UNKNOWN||b===UNKNOWN)return UNKNOWN;
  if(n.operator==='==')return a===b;if(n.operator==='~=')return a!==b;
  if(typeof a!==typeof b||!['number','string'].includes(typeof a))return UNKNOWN;
  switch(n.operator){case '<':return a<b;case '<=':return a<=b;case '>':return a>b;case '>=':return a>=b;}
  if(typeof a!=='number')return UNKNOWN;
  switch(n.operator){case '+':return a+b;case '-':return a-b;case '*':return a*b;case '/':return b===0?UNKNOWN:a/b;case '%':return b===0?UNKNOWN:a-Math.floor(a/b)*b;case '^':return a**b;}
 }
 return UNKNOWN;
}
const writesCache=new WeakMap();
function writes(n,name){const cache=writesCache.get(n);if(cache?.has(name))return cache.get(name);let yes=false;walk(n,x=>{
 if(['AssignmentStatement','LocalStatement'].includes(x.type)&&x.variables.some(v=>v.type==='Identifier'&&v.name===name))yes=true;
 if(x.type==='CompoundAssignmentStatement'&&x.variable.type==='Identifier'&&x.variable.name===name)yes=true;
 if(x.type==='ForNumericStatement'&&x.variable.name===name)yes=true;
 if(x.type==='FunctionDeclaration'&&(x.identifier?.name===name||x.parameters.some(p=>p.name===name)))yes=true;
 });const result=cache??new Map();result.set(name,yes);writesCache.set(n,result);return yes;}
export function specialize(nodes,variable,opcode,known=true){
 const out=[];
 for(const original of nodes){
  const n={...original}; // Read-only expression subtrees are shared; no AST mutation.
  if(n.type==='IfStatement'){
   const clauses=[];
   for(const c of n.clauses){
    const v=condition(c.condition,variable,opcode,known);
    if(v===UNKNOWN){clauses.push({...c,body:specialize(c.body,variable,opcode,known)});continue;}
    if(!truth(v))continue;
    const body=specialize(c.body,variable,opcode,known);
    if(!clauses.length)out.push({type:'DoStatement',body});else clauses.push({type:'ElseClause',body});
    break;
   }
   if(clauses.length)out.push({...n,clauses});
  }else{
   // Nested functions are deliberately opaque: do not substitute across lexical
   // bindings/captured state, and never erase unknown data-dependent branches.
   if(n.type!=='FunctionDeclaration'&&Array.isArray(n.body))n.body=specialize(n.body,variable,opcode,known&&!writes(n,variable));
   out.push(n);
  }
  if(writes(original,variable))known=false;
 }
 return out;
}
export function describeFactory(factory,selectedFrame=null){
 const target=selectedFrame??factory;
 const comparisons=new Map();
 walk(target,n=>{if(n.type==='BinaryExpression'&&['<','<=','>','>=','==','~='].includes(n.operator)&&n.left.type==='Identifier'&&n.right.type==='NumericLiteral')comparisons.set(n.left.name,(comparisons.get(n.left.name)??0)+1);});
 const [opcodeVariable,count]=[...comparisons].sort((a,b)=>b[1]-a[1])[0]??[];
 if(!opcodeVariable||count<(selectedFrame?5:40))throw Error('No dominant numeric opcode dispatcher');
 const parameter=factory.parameters[0]?.name,aliases=new Map();
 for(const n of factory.body){if(n.type!=='LocalStatement')continue;n.variables.forEach((v,i)=>{
  const x=n.init[i];if(v.type==='Identifier'&&x?.type==='IndexExpression'&&x.base.name===parameter&&x.index.type==='NumericLiteral')aliases.set(v.name,x.index.value);
 });}
 let dispatch=null,score=0;const reads=[],frames=[];
 walk(target,n=>{
  if(n.type==='FunctionDeclaration'&&n.parameters.some(p=>p.type==='VarargLiteral')){
   const first=n.body[0];
   if(first?.type==='LocalStatement')first.init.forEach((call,i)=>{const arg=call?.arguments?.[0];if(call?.type==='CallExpression'&&arg?.type==='Identifier'&&aliases.has(arg.name))frames.push({registerArray:first.variables[i].name,registerCountSlot:aliases.get(arg.name)});});
  }
  if(n.type==='IfStatement'&&n.clauses.some(c=>hasIdentifier(c.condition,opcodeVariable))){let s=0;walk(n,x=>{if(x.type==='BinaryExpression'&&hasIdentifier(x,opcodeVariable))s++;});if(s>score){score=s;dispatch=n;}}
  if(['AssignmentStatement','LocalStatement'].includes(n.type))n.variables.forEach((v,i)=>{
   const x=n.init[i];if(v.name===opcodeVariable&&x?.type==='IndexExpression'&&x.base.type==='Identifier'&&x.index.type==='Identifier')reads.push({opcodeArray:x.base.name,programCounter:x.index.name,opcodeSlot:aliases.get(x.base.name)??null});
  });
 });
 if(!dispatch)throw Error('Dispatcher tree not found');
 let maxComparedOpcode=0;walk(dispatch,n=>{if(n.type==='BinaryExpression'&&['<','<=','>','>=','==','~='].includes(n.operator)&&n.left.type==='Identifier'&&n.left.name===opcodeVariable&&n.right.type==='NumericLiteral')maxComparedOpcode=Math.max(maxComparedOpcode,n.right.value);});
 const unique=[...new Map(reads.filter(r=>r.opcodeSlot!==null).map(r=>[JSON.stringify(r),r])).values()];
 const read=unique.length===1?unique[0]:null;
 const loops=[];
 if(read)walk(target,n=>{
  if(!['RepeatStatement','WhileStatement'].includes(n.type))return;
  const index=n.body.findIndex(s=>['AssignmentStatement','LocalStatement'].includes(s.type)&&s.variables.some((v,i)=>v.name===opcodeVariable&&s.init[i]?.type==='IndexExpression'&&s.init[i].base.name===read.opcodeArray&&s.init[i].index.name===read.programCounter));
  if(index>=0)loops.push({type:n.type,condition:n.condition,prefix:n.body.slice(0,index+1),remaining:n.body.slice(index+1)});
 });
 const iteration=loops.length===1?loops[0]:null;
 return {opcodeVariable,comparisonCount:count,maxComparedOpcode,slotAliases:Object.fromEntries(aliases),read,frame:frames.length===1?frames[0]:null,iteration,dispatch};
}
export function extractHandlers(factory,maxOpcode=null,selectedFrame=null){
 const description=describeFactory(factory,selectedFrame);
 if(maxOpcode===null)maxOpcode=Math.max(255,Math.ceil(description.maxComparedOpcode)+1);
 if(!Number.isInteger(maxOpcode)||maxOpcode<0||maxOpcode>1023)throw Error('Opcode specialization limit');
 return {...description,selectedFrameOnly:!!selectedFrame,domainTruncated:maxOpcode<description.maxComparedOpcode,handlers:Array.from({length:maxOpcode+1},(_,opcode)=>({opcode,body:specialize([description.dispatch],description.opcodeVariable,opcode),iterationBody:description.iteration?[...description.iteration.prefix,...specialize(description.iteration.remaining,description.opcodeVariable,opcode)]:null})),fullRecoveryVerified:false};
}
