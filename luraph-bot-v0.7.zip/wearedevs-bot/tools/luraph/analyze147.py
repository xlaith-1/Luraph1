"""End-to-end RESEARCH analysis, not recovered application source.
Usage: python tools/luraph/analyze147.py INPUT.lua NEW_OUTPUT_DIRECTORY
Runs fixed lexing/unpacking/AST-analysis tools, never an uploaded Lua runtime.
"""
import json
from pathlib import Path
import subprocess
import sys

TOOLS=Path(__file__).resolve().parent

def command(args,timeout):
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
    if p.returncode:raise ValueError('Research tool failed: '+p.stderr[-1500:])
    return p.stdout

def main():
    source=Path(sys.argv[1]).resolve();out=Path(sys.argv[2]).resolve()
    out.mkdir()  # Never reuse another job's directory.
    result={'status':'blocked','fullRecoveryVerified':False,'error':None}
    try:
        front=json.loads(command(['node',str(TOOLS/'inspect147.mjs'),str(source),str(out/'transport')],30))
        if front['errors']:raise ValueError('; '.join(front['errors']))
        layers=front['layers'];data='--inline'
        if len(layers)==1 and not layers[0]['compressedCandidate']:
            code=source
        elif len(layers)==2 and all(x.get('unpack',{}).get('ok') for x in layers):
            code_layers=[x for x in layers if x.get('contentHint')=='inner-vm-source']
            data_layers=[x for x in layers if x.get('contentHint')=='binary-data']
            if len(code_layers)!=1 or len(data_layers)!=1:raise ValueError('Unrecognized compressed layer roles')
            code=out/'transport'/f"layer-{code_layers[0]['index']}.unpacked"
            data=str(out/'transport'/f"layer-{data_layers[0]['index']}.unpacked")
        else:raise ValueError('Unrecognized transport layout')
        normalized=out/'normalized-analysis.lua'
        command([sys.executable,str(TOOLS/'normalize_for_analysis.py'),str(code),str(normalized),'--preserve-compound'],30)
        result=json.loads(command(['node','--max-old-space-size=384',str(TOOLS/'evaluate147.mjs'),str(normalized),data,str(out/'data-analysis')],180))
        result['inputSha256']=front['inputSha256']
    except (ValueError,subprocess.TimeoutExpired) as exc:
        result['error']=str(exc)
    (out/'research-report.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))

if __name__=='__main__':main()
