// Bounded, data-only recovery of a periodically masked tagged constant pool.
// This does NOT parse application prototypes or execute a VM. Schema/key
// inference is heuristic and must be followed by independent cipher validation.
export function inferPeriodicPool(blob,start,{deadline=Date.now()+30000}={}){
 if(Date.now()>deadline)throw Error('Periodic pool inference budget');
 if(Buffer.isBuffer(blob)&&Number.isInteger(start)&&start>=0&&start<blob.length&&blob.subarray(start,Math.min(blob.length,start+8192)).every(v=>v===blob[start]))return null;
 return inferLanes(blob,start,deadline,1)??inferLanes(blob,start,deadline,2)??inferLanes(blob,start,deadline,3);
}
function inferLanes(blob,start,deadline,laneBits){
 const laneMask=(1<<laneBits)-1;
 if(!Buffer.isBuffer(blob)||blob.length>16*1024*1024||!Number.isInteger(start)||start<0||blob.length-start<8192)return null;
 let operations=0;const tick=()=>{if(++operations>8000000||(operations%1024===0&&Date.now()>deadline))throw Error('Periodic pool inference budget');};
 const period=8,modes=[];const counts=Array.from({length:period},()=>new Uint32Array(256));
 const from=Math.max(start,blob.length-Math.min(262144,Math.floor((blob.length-start)/2)));
 for(let i=from;i<blob.length;i++)counts[i%8][blob[i]]++;
 for(const c of counts){let m=0;for(let i=0;i<256;i++)if(c[i]>c[m])m=i;modes.push(m);}
 const byte=(i,bits)=>blob[i]^modes[i%8]^((bits>>((i%8)*laneBits))&laneMask);
 const limit=Math.min(blob.length-512,start+4096),seeds=new Map();
 function readString(p,bits){let n=0;for(let shift=0;shift<35;shift+=7){if(p>=blob.length)return null;const v=byte(p++,bits);n+=(v&127)*2**shift;if(v<128){if(n>65536||p+n>blob.length)return null;return {begin:p,end:p+n};}}return null;}
 // Repeated compact-number tags constrain four key lanes. Enumerate the
 // remaining low-bit ambiguities instead of assuming the most common byte is 0.
 for(let pos=start;pos<limit;pos++){
  tick();const base=(blob[pos]^modes[pos%8])&(255^laneMask);let compatible=true;
  // Interior starts in the same compact-number run cannot improve the
  // earliest seed. Same-phase equality proves the preceding tag fits the
  // same key constraints; avoid enumerating its free lanes again.
  if(pos>=start+2){const prev=blob[pos-2]^modes[(pos-2)%8],same=blob[pos+6]^modes[(pos+6)%8];if(prev===same&&(prev&(255^laneMask))===base)continue;}
  for(let j=1;j<6;j++)if(((blob[pos+2*j]^modes[(pos+2*j)%8])&(255^laneMask))!==base){compatible=false;break;}
  if(!compatible)continue;
  for(let numberTag=base;numberTag<=base+laneMask;numberTag++){
   const fixed=new Map();let ok=true;
   for(let j=0;j<6;j++){const i=pos+2*j,lane=i%8,bit=(blob[i]^modes[lane])^numberTag;if(fixed.has(lane)&&fixed.get(lane)!==bit){ok=false;break;}fixed.set(lane,bit);}if(!ok)continue;
   const free=[0,1,2,3,4,5,6,7].filter(i=>!fixed.has(i));
   for(let v=0;v<2**(free.length*laneBits);v++){
    tick();
    let bits=0;for(const[i,b]of fixed)bits|=b<<(i*laneBits);free.forEach((lane,j)=>bits|=((v>>(j*laneBits))&laneMask)<<(lane*laneBits));
    let p=pos;while(p<limit&&byte(p,bits)===numberTag){tick();p+=2;}
    const stringTag=byte(p,bits);if(stringTag===numberTag||!readString(p+1,bits))continue;
    const key=bits+':'+numberTag+':'+stringTag;
    const state={bits,numberTag,stringTag,start:pos,p:pos,count:0,strings:[],schema:{[numberTag]:1}};
    const end=advance(state);
    if(end.count>=10&&end.strings.length>=2){const old=seeds.get(key);if(!old||end.start<old.start)seeds.set(key,end);}
   }
  }
 }
 function advance(st){let {p,count}=st;const strings=st.strings.slice();let unknown=null;
  while(p<blob.length&&count<100000){
   tick();const pos=p,t=byte(p++,st.bits);
   if(t===st.stringTag){const s=readString(p,st.bits);if(!s){p=pos;break;}strings.push(s);p=s.end;}
   else if(Object.hasOwn(st.schema,t)){p+=st.schema[t];if(p>blob.length){p=pos;break;}}
   else{p=pos;unknown=t;break;}count++;
  }
  return {...st,p,count,strings,unknown};
 }
 let states=[...seeds.values()].sort((a,b)=>b.count-a.count).slice(0,128),best=null;
 for(let depth=0;depth<10&&states.length;depth++){
  const next=[];
  for(const st of states){
   if(!best||st.count>best.count)best=st;
   if(st.unknown===null||Object.keys(st.schema).length>=10)continue;
   for(const width of [0,1,2,4,8])next.push(advance({...st,schema:{...st.schema,[st.unknown]:width}}));
  }
  next.sort((a,b)=>b.count-a.count);states=next.slice(0,128);
 }
 if(!best||best.count<500||best.strings.length<100)return null;
 // Recover a consistent prefix omitted by the compact-number seed. Every
 // proposed prefix must join the established pool exactly, with known types.
 let earliest=best.start,prefix=[];
 for(let pos=Math.max(start,best.start-512);pos<best.start;pos++){
  tick();let p=pos,ss=[],valid=true;
  while(p<best.start){tick();const t=byte(p++,best.bits);if(t===best.stringTag){const s=readString(p,best.bits);if(!s){valid=false;break;}ss.push(s);p=s.end;}else if(Object.hasOwn(best.schema,t))p+=best.schema[t];else{valid=false;break;}}
  if(valid&&p===best.start){earliest=pos;prefix=ss;break;}
 }
 const strings=[...prefix,...best.strings].map(s=>{const data=Buffer.alloc(s.end-s.begin);for(let i=s.begin;i<s.end;i++)data[i-s.begin]=byte(i,best.bits);return {value:data.toString('latin1'),byteStart:s.begin,byteEnd:s.end};});
 return {strings,report:{method:'periodic-tagged-pool',period,laneBits,guessedKeyHex:Buffer.from(modes.map((v,i)=>v^((best.bits>>(i*laneBits))&laneMask))).toString('hex'),poolStart:earliest,poolEnd:best.p,parsedRecords:best.count,stringTag:best.stringTag,numberTag:best.numberTag,inferredFieldWidths:best.schema,operations,validation:'Inferred key and field widths, followed by cipher validation; not a complete serializer or coverage proof'}};
}
