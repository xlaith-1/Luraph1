// Static devirtualization of closed, literal-prototype VM wrappers.
// Never executes input Lua. Unsupported semantics abort the whole candidate.
import lp from './vendor/luaparse.cjs';
import {instrument147} from './instrument147.mjs';
import {createHash} from 'node:crypto';
const fail=message=>{throw Error(message);};
const C=(value,code)=>({kind:'constant',value,code});
const nil=()=>C(null,'nil');
const truth=v=>v!==null&&v!==false;
function quote(s){return '"'+[...s].map(c=>{const b=c.charCodeAt(0);if(b>255)fail('Non-byte string');return b>=32&&b<127&&b!==34&&b!==92?c:'\\'+String(b).padStart(3,'0');}).join('')+'"';}
export function recoverLiteral147(source,{maxInstructions=512,maxBranches=16,maxOperations=100000,maxOutputBytes=1024*1024}={}){
 const report={schema:1,status:'unsupported',engine:'literal-vm-static-subset/0.1',programCallsExecuted:false,fullRecoveryVerified:false};
 try{
  for(const n of [maxInstructions,maxBranches,maxOperations,maxOutputBytes])if(!Number.isSafeInteger(n)||n<1)fail('Invalid recovery limit');
  if(typeof source!=='string'||source.length>524288||/[^\x00-\xff]/.test(source))fail('Input byte/size limit');
  report.sourceSha256=createHash('sha256').update(Buffer.from(source,'latin1')).digest('hex');
  const ast=lp.parse(source,{luaVersion:'5.3',ranges:true,encodingMode:'pseudo-latin1'});
  const checkEnvironment=n=>{if(!n||typeof n!=='object')return;if(n.type==='Identifier'&&n.name==='_ENV')fail('Explicit environment binding is unsupported');for(const [k,v]of Object.entries(n)){if(['range','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(checkEnvironment);else if(v&&typeof v==='object')checkEnvironment(v);}};
  checkEnvironment(ast);
  const last=ast.body.at(-1);if(last?.type!=='ReturnStatement'||last.arguments.length!==1)fail('Expected a closed returned VM wrapper');
  let invocation=last.arguments[0],outerArgs=null;
  if(invocation.type==='CallExpression'&&invocation.base.type==='CallExpression'){outerArgs=invocation.arguments;invocation=invocation.base;}
  if(invocation.type!=='CallExpression'||invocation.arguments.length!==1||invocation.arguments[0].type!=='TableConstructorExpression')fail('Literal prototype argument required');
  let factory=invocation.base;const factoryName=factory.type==='Identifier'?factory.name:null;
  if(factory.type==='Identifier'){
   if(ast.body.length!==2)fail('Additional top-level effects');
   const declaration=ast.body[0];
   if(declaration.type==='LocalStatement'&&declaration.variables.length===1&&declaration.variables[0].name===factory.name&&declaration.init.length===1)factory=declaration.init[0];
   else if(declaration.type==='FunctionDeclaration'&&declaration.isLocal&&declaration.identifier.name===factory.name)factory=declaration;
   else fail('Factory binding is not closed');
  }else if(ast.body.length!==1)fail('Additional top-level effects');
  if(factory.type!=='FunctionDeclaration'||factory.parameters.length!==1||factory.parameters[0].type!=='Identifier')fail('Unsupported factory signature');
  const frameReturn=factory.body.at(-1),frame=frameReturn?.arguments?.[0];
  if(frameReturn?.type!=='ReturnStatement'||frameReturn.arguments.length!==1||frame?.type!=='FunctionDeclaration'||frame.parameters.length!==1||frame.parameters[0].type!=='VarargLiteral')fail('Expected one directly returned vararg frame');
  const plan=instrument147(source).report;
  const site=plan.sites.find(s=>s.functionRange[0]===frame.range[0]);if(!site)fail('Frame dispatcher was not structurally recognized');
  const loops=frame.body.filter(n=>['WhileStatement','RepeatStatement'].includes(n.type)&&n.range[0]<site.fetchRange[0]&&n.range[1]>site.fetchRange[1]);
  if(loops.length!==1)fail('Expected a direct frame dispatcher loop');
  const loop=loops[0];
  if(loop.condition.type!=='BooleanLiteral'||loop.condition.value!==(loop.type==='WhileStatement'))fail('Nonconstant dispatcher loop condition');
  let naming='recovered_';
  for(let i=0;source.includes(naming);i++){if(i>64)fail('Generated-name collision');naming+='x';}
  let serial=0,operations=0,branches=0,instructions=0,maxArgument=0;
  const tick=()=>{if(++operations>maxOperations)fail('Recovery operation limit');};
  const emit=(s,line)=>{s.lines.push(line);s.outputBytes+=line.length;if(s.outputBytes>maxOutputBytes)fail('Recovery output limit');};
  const material=(s,code,hint='value')=>{if(code.length>32768)fail('Expression size limit');const name=naming+hint+'_'+(++serial);emit(s,`local ${name} = ${code}`);return {kind:'symbolic',code:name};};
  const single=(v,s)=>v.kind==='multiple'?material(s,v.code):v;
  const text=v=>{if(!['constant','symbolic','multiple'].includes(v.kind))fail('Internal VM table escapes into application code');return v.code;};
  function lookup(name,s){for(let i=s.env.length-1;i>=0;i--)if(s.env[i].has(name)){const v=s.env[i].get(name);if(v.kind==='forbidden')fail('Factory closure reference is unsupported');return v;}return material(s,name,'global_'+name);}
  function key(v){if(v.kind!=='constant'||v.value===null)fail('Dynamic or nil internal-table index');return v.value;}
  function read(base,index,s){
   if(base.kind==='table')return base.entries.get(key(index))??nil();
   if(base.kind==='arguments'){
    const k=key(index);if(base.entries.has(k))return base.entries.get(k);if(!Number.isInteger(k)||k<1||k>128)fail('Unsupported argument-array index');
    maxArgument=Math.max(maxArgument,k);return {kind:'symbolic',code:naming+'argument_'+k};
   }
   return material(s,`(${text(base)})[${text(index)}]`);
  }
  function expr(n,s,literalOnly=false){
   tick();if(!n)fail('Missing expression');
   let v;
   if(n.type==='NilLiteral')v=nil();
   else if(n.type==='StringLiteral')v=C(n.value,quote(n.value));
   else if(n.type==='BooleanLiteral')v=C(n.value,n.value?'true':'false');
   else if(n.type==='NumericLiteral'){
    if(!Number.isFinite(n.value)||Math.abs(n.value)>Number.MAX_SAFE_INTEGER)fail('Unsafe numeric literal');
    v=C(n.value,n.raw??String(n.value));
   }else if(n.type==='TableConstructorExpression'){
    if(!literalOnly&&n.fields.length===1&&n.fields[0].type==='TableValue'&&n.fields[0].value.type==='VarargLiteral'&&!n.fields[0].value.inParens)v={kind:'arguments',entries:new Map()};
    else{
     v={kind:'table',entries:new Map(),persistent:s.phase==='factory'};let at=1;
     for(const f of n.fields){const k=f.type==='TableValue'?at++:f.type==='TableKeyString'?f.key.name:key(single(expr(f.key,s,literalOnly),s));const raw=expr(f.value,s,literalOnly);if(f===n.fields.at(-1)&&f.type==='TableValue'&&raw.kind==='multiple')fail('Expandable table constructor');const value=single(raw,s);if(v.entries.has(k))fail('Duplicate table-constructor key');v.entries.set(k,value);}
    }
   }else if(n.type==='UnaryExpression'){
    const a=single(expr(n.argument,s,literalOnly),s),code=`(${n.operator==='not'?'not ':n.operator}${text(a)})`;
    if(a.kind==='constant'&&n.operator==='not')v=C(!truth(a.value),code);
    else if(a.kind==='constant'&&n.operator==='-'&&typeof a.value==='number')v=C(-a.value,code);
    else if(literalOnly)fail('Nonliteral prototype expression');else v=material(s,code);
   }else if(literalOnly)fail('Nonliteral prototype expression');
   else if(n.type==='Identifier')v=lookup(n.name,s);
   else if(n.type==='VarargLiteral')v={kind:'multiple',code:'...'};
   else if(n.type==='IndexExpression'||n.type==='MemberExpression')v=read(single(expr(n.base,s),s),n.type==='MemberExpression'?C(n.identifier.name,quote(n.identifier.name)):single(expr(n.index,s),s),s);
   else if(n.type==='BinaryExpression'||n.type==='LogicalExpression'){
    const a=single(expr(n.left,s),s);
    if(n.type==='LogicalExpression'){
     if(a.kind!=='constant')fail('Dynamic short-circuit expression');
     v=(n.operator==='and'?truth(a.value):!truth(a.value))?single(expr(n.right,s),s):a;
    }else{
     const b=single(expr(n.right,s),s),code=`(${text(a)} ${n.operator} ${text(b)})`;
     let known=false,result;
     if(a.kind==='constant'&&b.kind==='constant'){
      const x=a.value,y=b.value;
      if(['==','~='].includes(n.operator)){result=n.operator==='=='?x===y:x!==y;known=true;}
      else if(typeof x==='number'&&typeof y==='number'&&['<','<=','>','>='].includes(n.operator)){result=n.operator==='<'?x<y:n.operator==='<='?x<=y:n.operator==='>'?x>y:x>=y;known=true;}
      else if(typeof x==='number'&&typeof y==='number'&&Number.isSafeInteger(x)&&Number.isSafeInteger(y)&&['+','-','*'].includes(n.operator)){
       result=n.operator==='+'?x+y:n.operator==='-'?x-y:x*y;known=Number.isSafeInteger(result)&&Math.abs(result)<=2147483647;
      }
     }
     // Keep the original Lua expression even when a control value is known:
     // JS folding must not change Lua integer/float representation in output.
     if(code.length>32768)fail('Expression size limit');v=known?C(result,code):material(s,code);
    }
   }else if(['CallExpression','TableCallExpression','StringCallExpression'].includes(n.type)){
    let callee,args=[];
    if(n.base.type==='MemberExpression'&&n.base.indexer===':'){
     const receiver=single(expr(n.base.base,s),s);callee=read(receiver,C(n.base.identifier.name,quote(n.base.identifier.name)),s);args.push(receiver);
    }else callee=single(expr(n.base,s),s);
    const nodes=n.type==='CallExpression'?n.arguments:[n.type==='TableCallExpression'?n.arguments:n.argument];
    nodes.forEach((a,i)=>{const x=expr(a,s);args.push(i===nodes.length-1?x:single(x,s));});
    v={kind:'multiple',code:`${text(callee)}(${args.map(text).join(', ')})`};
   }else fail('Unsupported expression '+n.type);
   return n.inParens?single(v,s):v;
  }
  function values(nodes,count,s){
   const result=[];
   nodes.forEach((n,i)=>{const v=expr(n,s);result.push(i===nodes.length-1?v:single(v,s));});
   if(result.at(-1)?.kind==='multiple'){
    const last=result.pop(),needed=Math.max(1,count-result.length),names=Array.from({length:needed},()=> naming+'value_'+(++serial));
    emit(s,`local ${names.join(', ')} = ${last.code}`);result.push(...names.map(code=>({kind:'symbolic',code})));
   }
   while(result.length<count)result.push(nil());return result.slice(0,count);
  }
  function address(n,s){
   if(n.type==='Identifier'){for(let i=s.env.length-1;i>=0;i--)if(s.env[i].has(n.name)){if(outerArgs===null&&i===0)fail('Persistent closure-cell write');return {scope:i,name:n.name};}fail('Global assignment is unsupported');}
   if(n.type==='IndexExpression'){
    const table=single(expr(n.base,s),s),k=key(single(expr(n.index,s),s));
    if(!['table','arguments'].includes(table.kind))fail('Assignment to escaped table');if(outerArgs===null&&table.persistent)fail('Persistent closure-table write');return {table,key:k};
   }
   fail('Unsupported assignment target');
  }
  function store(a,v,s){if(a.table)a.table.entries.set(a.key,v);else s.env[a.scope].set(a.name,v);}
  function local(n,s){const vs=values(n.init,n.variables.length,s);n.variables.forEach((v,i)=>s.env.at(-1).set(v.name,vs[i]));}
  const state={phase:'factory',env:[new Map()],lines:[],outputBytes:0,todo:[],steps:0};
  if(factoryName)state.env[0].set(factoryName,{kind:'forbidden'});
  const prototype=expr(invocation.arguments[0],state,true);state.env[0].set(factory.parameters[0].name,prototype);
  for(const n of factory.body.slice(0,-1)){if(n.type!=='LocalStatement')fail('Factory setup effects');local(n,state);}
  if(state.lines.length)fail('Factory setup requires runtime effects');
  state.phase='frame';state.env.push(new Map());state.todo=[...frame.body];
  function scoped(body,s){s.env.push(new Map());s.todo.unshift(...body,{type:'__pop'});}
  function run(s){
   while(s.todo.length){
    tick();const n=s.todo.shift();
    if(n.type==='__pop'){s.env.pop();continue;}
    if(n.type==='__dispatch'){
     if(++s.steps>maxInstructions)fail('Instruction recovery limit');instructions++;
     s.todo.unshift({type:'__dispatch'});scoped(loop.body,s);continue;
    }
    if(n===loop){s.todo.unshift({type:'__dispatch'});continue;}
    if(n.type==='LocalStatement'){local(n,s);continue;}
    if(n.type==='AssignmentStatement'){
     const targets=n.variables.map(v=>address(v,s));
     for(let i=0;i<targets.length;i++)for(let j=0;j<i;j++){const a=targets[i],b=targets[j];if(a.table&&a.table===b.table&&a.key===b.key||!a.table&&!b.table&&a.scope===b.scope&&a.name===b.name)fail('Aliased simultaneous assignment');}
     const vs=values(n.init,targets.length,s);targets.forEach((a,i)=>store(a,vs[i],s));continue;
    }
    if(n.type==='CompoundAssignmentStatement')fail('Compound-assignment runtime dialect is unsupported');
    if(n.type==='DoStatement'){scoped(n.body,s);continue;}
    if(n.type==='IfStatement'){
     let selected=false;
     for(let i=0;i<n.clauses.length;i++){
      const clause=n.clauses[i],condition=clause.condition?single(expr(clause.condition,s),s):C(true,'true');
      if(condition.kind==='constant'){
       if(truth(condition.value)){scoped(clause.body,s);selected=true;break;}continue;
      }
      if(++branches>maxBranches)fail('Branch recovery limit');
      const clone=()=>({...s,env:structuredClone(s.env),lines:[],todo:[...s.todo]});
      const yes=clone(),no=clone();scoped(clause.body,yes);
      if(i+1<n.clauses.length)no.todo.unshift({type:'IfStatement',clauses:n.clauses.slice(i+1)});
      const y=run(yes),z=run(no);
      emit(s,`if ${text(condition)} then\n${indent(y)}\nelse\n${indent(z)}\nend`);return s.lines.join('\n');
     }
     void selected;continue;
    }
    if(n.type==='CallStatement'){
     const call=expr(n.expression,s);if(call.kind!=='multiple')fail('Parenthesized call statement');emit(s,text(call));continue;
    }
    if(n.type==='ReturnStatement'){
     const args=n.arguments.map((a,i)=>{const v=expr(a,s);return i===n.arguments.length-1?v:single(v,s);});
     emit(s,'return'+(args.length?' '+args.map(text).join(', '):''));return s.lines.join('\n');
    }
    fail('Unsupported statement '+n.type);
   }
   emit(s,'return');return s.lines.join('\n');
  }
  function indent(s){return s.split('\n').map(l=>'  '+l).join('\n');}
  let body=run(state);
  if(serial+maxArgument>180)fail('Generated Lua local-variable limit');
  if(maxArgument)body='local '+Array.from({length:maxArgument},(_,i)=>naming+'argument_'+(i+1)).join(', ')+' = ...\n'+body;
  let ending='end';
  if(outerArgs!==null){
   const temporary={env:[],lines:[],outputBytes:0};
   const args=outerArgs.map(n=>n.type==='VarargLiteral'&&!n.inParens?'...':text(expr(n,temporary,true)));
   ending='end)('+args.join(', ')+')';
  }
  const output='-- Recovered closed literal-prototype VM subset; original names are unavailable.\n-- Static reconstruction, not a whole-program equivalence certificate.\nreturn '+(outerArgs!==null?'(':'')+'function(...)\n'+indent(body)+'\n'+ending+'\n';
  if(output.length>maxOutputBytes)fail('Recovery output limit');
  lp.parse(output,{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
  return {source:output,report:{...report,status:'recovered-static-subset',instructions,branches,operations,
   limitations:['Only a closed literal-prototype wrapper and bounded supported control flow are recovered.','Debug/stack/timing observations are not preserved.','External calls are emitted, never executed during recovery.','No general Luraph version support or application equivalence is certified.']}};
 }catch(error){return {source:null,report:{...report,error:error.message}};}
}
