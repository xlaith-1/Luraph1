# Offline Luraph research tools

These are **not** the production bot runtime or a reviewed general-purpose sandbox. Never expose the native harness as an upload service. Production `worker/luraph-recovery.mjs` performs bounded data decoding and abstract evaluation only.

## Current result

The exact private v14.8 sample62 was recovered to a standalone one-call program. A successful instrumented bootstrap produced one35-instruction entry. The original entry, separately instantiated in a recording-only environment, agrees with an independent handler lifter and the production JavaScript abstract evaluator on all34 reachable steps and its observable call. PC13 is unreachable. There are no payload callbacks/nested prototypes.

The original bootstrap launch callsite remains replaced with a descriptor return. Later, after inspecting/lifting the entry, a **separate reviewed test** instantiated its original VM function with only a recording print sink; unexpected global reads/writes failed. No real Roblox APIs or network requests were used. This is stronger than string extraction but not a real Roblox execution test. Early state-corrupting trap-bypass experiments were discarded and were not used for certification.

The production review stores input/output digests, eight-byte stage cipher material, string LCG parameters, and two arithmetic capture values. It does not store or return a cached recovered script. The worker decrypts and lifts the uploaded records each time. Its approval is restricted to the exact reviewed fingerprint.

## Tools

- `normalize_for_analysis.py`: normalizes literals and replaces `continue` with a marker for AST analysis. **That output is not executable-equivalent source. Never execute it.**
- `parse_analysis.mjs`, `extract_opcodes.mjs`: extract specialized handler AST/source; still internal VM semantics, not user source.
- `compare_prototypes.py`: compare original deserializer records with static parser records.
- `runner.cpp`, `research_random.hpp`: bounded native Luau embedding for specifically reviewed inputs. The runner does not discover a payload boundary automatically.

## Build

Official Luau source: https://github.com/luau-lang/luau, commit `c54f558b4d5748ab0658610b8ce0c432053e41eb`. Build the five static libraries using `make config=release`. ICU development headers/libraries are also required.

```bash
L=/path/to/luau
c++ -O2 -std=c++17 -I$L/VM/include -I$L/Compiler/include \
  tools/luraph/runner.cpp -Wl,--start-group \
  $L/build/release/libluauvm.a $L/build/release/libluaucompiler.a \
  $L/build/release/libluaubytecode.a $L/build/release/libluauast.a \
  $L/build/release/libluaucommon.a -Wl,--end-group \
  $(pkg-config --libs icu-uc) -o research-runner
```

Reference runs also use `ulimit -c 0; ulimit -t 15; ulimit -v 524288`. The VM allocator is capped at128MiB and an interrupt hook exits after8seconds. Root yields resume at most100 times with a synthetic1/60 value; this is **not a scheduler**.

## Compatibility limits

The local fixtures use native-named closures, tagged userdata, NFC/NFD via ICU, approximate cubic geometry, a limited synchronous hierarchy/signal model, restricted enums, a synthetic non-Studio client scenario, and explicit-seed PCG. Native argument checks cover observed probes, not all overloads/receivers.

Memory-category/profiling debug functions, synchronization APIs, HTTP functions, missing-child waits, `utf8.graphemes`, Random.NextUnitVector and Random.Shuffle remain explicitly blocked if called. Random default-seed behavior is synthetic. The successful sample does not require those blocked operations. No Lua filesystem, require, HTTP, process or dynamic-loader APIs are installed.

Graph output includes host backing fields and heuristic function metadata. `vmInstructions` is not a reliable prototype identity. Large research graphs may be archived as `.json.gz`; consult the workspace session notes for the current checkpoint.

Latest checks:65 repository tests (38 Node,27 Python);266 research assertions (204 PCG,31 environment,22 native compatibility,9 geometry); original VM / independent lifter / static lifter / emitted-source recording agreement. Private-sample integration tests require the original input and skip when it is absent.

## General v14.7 research, later checkpoint

See the root README and `/home/user/luraph-14.7-research/SESSION_NOTES.md` for the
new bounded AST data-evaluation pipeline (`analyze147.py`). It does not use this
native runner.158 repository tests now pass (123 Node /35 Python). Six intact development samples
reach a VM boundary; no v14.7 protected application has yet been fully recovered
or approved. Do not confuse this with the separately completed reviewed v14.8
sample62. Large intermediate graphs may be gzip-archived.


The research-only `lower147.mjs` stage reads saved dispatch/frame/graph artifacts
and emits typed instruction IR plus provisional CFG diagnostics, never readable
application recovery. See the root README for its CLI and limitations. Following
a preamble-effect audit, earlier corpus prefix traces are withdrawn: all six
currently stop before execution of the first abstract instruction. Unknown setup
calls, fresh-register assumptions, captured environments and protected-call
wrappers require explicit modeling.27 IR/CFG tests pass; this is not proof of
whole-program equivalence. No holdouts were inspected or approvals added.


Frame setup now has a separate non-executing representation: `lowerFrame147`
(in `ir147.mjs`). The lowering CLI additionally writes `frame-setup-ir.json.gz`.
It preserves setup-call order, lexical bindings, nested callback creation and
post-call continuations. A dispatcher is an explicit hole, not an executed loop.
Capture dependencies use symbol identities; sets crossing dispatcher holes are
explicitly incomplete. Six new frame tests pass, and all six development frames
lower successfully. This does not resume tracing or certify recovered source.


The data evaluator can now export exact selected-frame lexical bindings and
bounded direct captured-helper ASTs (`frame-bindings.json`,
`captured-helpers.json`). These are same-run data artifacts, not permission to
execute helpers. The small development example was rerun successfully to capture
this metadata; the other five have not yet been refreshed with these artifacts.
General source recovery and setup-effect interpretation remain incomplete.


`helper147.mjs` adds narrow bounded abstract helper analysis, with no native or
uploaded callback invocation. It models scalar declarations, return adjustment,
conditional paths, captured-table reads and identity-resolved `select('#', ...)`
for argument packing. Nil positions and unknown argument tails are preserved.
On the small sample, one of16 exported helpers produces conditional abstract
outcomes;15 fail closed. This stage is not wired into frame tracing or source
certification. Eight helper tests pass;158 total tests now pass.


`setup147.mjs` connects exact captured helper identities to straight-line frame
setup analysis. It models table.create allocation, argument packing, and opaque
getfenv results without invoking native APIs. pcall remains an explicit frontier;
no callback or dispatcher is entered. The small sample now reaches that frontier
with a33-slot abstract register allocation. This is not source recovery or a
resumption of prior instruction traces. Six setup regression tests pass.


`protected147.mjs` prepares a conditional protected-call continuation plan and
abstract callback-local bindings, stopping before the dispatcher. Its result
binding API requires an explicitly hypothetical normal return or Lua error; an
analysis blocker is never converted into a Lua error. Optional
`lowerFrame147(...,{includeInstructions:true})` now lowers frame and instruction
IR with shared lexical symbol identities. All six development frames pass this
lowering. These changes do not authorize instruction entry or full source recovery.


### Conditional BitOp/goto research profile

`evaluate147.mjs NORMALIZED.lua DATA.bin NEW_DIR --integer-bit` enables a narrow
safe-integer BitOp model and passes data as a byte string. `--integer-bit-no-ffi`
also probes the explicit environment where require('ffi') fails; this is not a
claim about the uploaded script's real host. Native module loading remains blocked.
Goto handling rejects crossed local declarations and cross-function jumps.
Optional helper-export failures are reported separately from core decoding.
Latest full check:165 tests (130 Node /35 Python), including7 profile/goto tests.
The pro.lua.txt upload reaches a conditional data/VM boundary, NOT readable source.

## Reusable versioned trace stage

See [TRACE147.md](TRACE147.md) for the new offline instruction-version tracker,
explicit frame event contract, bounded CLI importer, and evidence limitations.
This is research infrastructure, not a new full-recovery claim or live bot change.

The capture-side recorder and its integration contract are documented in
[RECORDER147.md](RECORDER147.md). Tests use synthetic Lua5.4/LuaJIT fixtures only.

## Experimental automatic capture integration

See [INSTRUMENT147.md](INSTRUMENT147.md) for raw-source structural hook discovery,
preparation-only CLI, and tested recorder/importer integration. This is not yet
readable application recovery and is not connected to the production worker.

## Readable-source path integrated into the worker

`recover-literal147.mjs` reconstructs a bounded closed literal-prototype subset
as application Lua. See [LITERAL_RECOVERY.md](LITERAL_RECOVERY.md). This route is
separate from runtime trace evidence: it follows private mutable tables statically
and emits structured branches. Packed/encrypted bootstrap recovery remains open.
