# Capture-event recorder

`trace147-recorder.lua` is the producer for the versioned tracker. It has been
tested under Lua5.4 and LuaJIT. It emits the JSONL contract described in
[TRACE147.md](TRACE147.md), using a caller-supplied sink.

It does not discover VM functions, inject hooks automatically, start a sandbox,
execute a protected input on its own, or reconstruct source. The trusted capture
harness still has to choose correct instruction/call boundaries.

## Minimal integration

Load this module in the trusted harness, before executing anything untrusted:

```lua
local Recorder = assert(loadfile("tools/luraph/trace147-recorder.lua"))()
local output = assert(io.open("events.jsonl", "wb"))
local recorder = Recorder.new({
    sessionId = "run-1",
    emit = function(line)
        assert(output:write(line))
        assert(output:flush())
    end,
    maxEvents = 100000,
    maxBytes = 8 * 1024 * 1024,
})

local frame = recorder:enter("main", "prototype-0")
-- An instrumented dispatcher calls this at a reviewed instruction boundary:
recorder:step(frame, 0, 17, {constant = 5, missing = Recorder.NIL})
recorder:exit(frame)

local status, statusJSON = recorder:finish("producer-ended")
output:close()
local statusFile = assert(io.open("status.json", "wb"))
assert(statusFile:write(statusJSON))
statusFile:close()
```

The module itself has no filesystem or network code. The example's I/O belongs to
the trusted harness; never expose that harness's globals or output handles to a
protected program. Always retain OS containment and independent runtime limits.

## API

- `enter(threadId, prototypeId)` returns an opaque frame handle.
- `current(threadId)` returns that thread's active frame, or nil.
- `step(frame, pc, opcode, operandMap)` records a snapshot at that boundary.
- `exit(frame, "return" | "error")` closes the active frame.
- `gap(threadId)` marks missing observations without inventing intervening edges.
- `registerPrototype(table, prototypeId)` labels prototype references. Register
  before recording the table as an operand: late reclassification is rejected.
- `withFrame(threadId, prototypeId, fn, ...)` wraps an already-instrumented function,
  preserves arguments and all return positions (including nils), emits an error
  exit if the function throws, and rethrows the original error object.
- `finish(reason)` closes the recorder and returns a status table **and JSON text**.
  Write the latter to a separate file, not into the event stream.

IDs and reason labels are bounded ASCII identifiers. PC/opcodes must be
nonnegative safe integers. Frame IDs and event sequence numbers are assigned by
the recorder; prototype names and opcode numbers are not hardcoded.

### Wrapper restrictions

`withFrame` uses `pcall`. It is not a transparent wrapper for every Lua runtime:
yield behavior, debug stack observations and function identity can differ. No
coroutine-yield equivalence is claimed. Explicit hooks are preferable when such
behavior matters. Thread IDs must come from the trusted harness's thread mapping;
the recorder does not infer scheduler behavior.

## Operand fidelity

- Strings are raw bytes encoded as hexadecimal—not decoded as UTF-8.
- Use `Recorder.NIL` for an explicit nil-valued operand. A missing Lua table key
  cannot distinguish a nil read from an operand that was not recorded.
- Booleans, finite numbers, NaN, infinities and negative zero retain typed values.
- Lua5.4 integers outside JavaScript's safe-integer range retain decimal strings.
  LuaJIT cdata is opaque; it is not silently converted into a rounded number.
- Objects retain bounded identity references; registered prototypes retain IDs.
  Tables/functions/userdata are not traversed or stringified, and their metamethods
  are not called by snapshotting. An object's contents changing behind a stable
  reference is **not** captured by this API.
- The recorder copies the immediate snapshot into JSON before returning. Later
  edits to the caller's operand map do not rewrite past events.

The recorder cannot know whether the harness supplied every operand read or the
correct snapshot timing. Fused instructions, deferred reads and heap mutations
need further instrumentation. Do not treat this as complete execution evidence.

## Limits and failure handling

Configuration bounds events, total/event bytes, strings, operand count, frame
count/depth, threads and retained object references. A limit, invalid frame, or
sink failure makes the recorder terminal. A failed sink cannot be safely retried
in the same session; it may already have written partial data.

A recorder limit does not forcibly stop the Lua VM. Protected code may catch
errors. Keep the surrounding instruction/CPU/wall-time/memory sandbox limits.
Reference-count limits also do not bound the size of the target objects held by
those references.

The finish status identifies recording failures and remaining open frames.
Exceptions from the instrumented function itself can still produce a valid trace
prefix with an error exit; validity is not application success or path coverage.

## Import with producer status

Add a status path to an event-stream manifest:

```json
{
  "identity": {
    "sourceSha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "symbolNamespace": "replace-with-real-layout-identity",
    "sessionId": "run-1",
    "executionProfile": "describe-the-actual-runtime-profile"
  },
  "inputs": [{"format": "events-jsonl", "path": "events.jsonl"}],
  "producerStatus": "status.json"
}
```

```sh
node tools/luraph/trace147-cli.mjs manifest.json evidence.json
```

The CLI checks the producer session, event count and validity. A failed producer
or mismatched status quarantines the import and suppresses derived edges. Legacy
observation files remain supported without a status file, but their missing
execution/frame information is not manufactured.

## Tests and integration status

The Lua fixtures execute only synthetic code. Tests run the recorder under both
Lua5.4 and LuaJIT, then ingest its events with the Node tracker. They cover recursion,
multiple returns, original error objects, thread interleaving, gaps, byte/number
fidelity, hostile object metamethods, limits, sink failure and status reporting.

Three small VM fixtures use different instruction-table keys, PCs and opcode
values. Each mutates instructions while executing. Instrumented and baseline
results agree, and their changed instruction versions are retained.

These tests demonstrate the component contract—not general Luraph capture or
compatibility with every protected sample. No live bot behavior was changed.
Limited structural hook selection and synthetic producer/importer integration
now exist in `instrument147.mjs`; see `INSTRUMENT147.md`. Still needed: validation
in an isolated reusable protected-input capture harness,
then a version-aware control-flow consumer.
