// Research-only, bounded concrete evaluation of the PURE DATA portion of a Lua
// AST. No Lua runtime, environment emulation, IO, loadstring, or VM execution.
// All unknown native calls fail closed. A structural VM-factory boundary stops
// before any decoded instruction is run. Never issues a source certificate.
import lp from './vendor/luaparse.cjs';
export class Unsupported extends Error {}
export class Boundary extends Error {constructor(value){super('VM factory boundary');this.value=value;}}
class Flow {constructor(kind,values=[]){this.kind=kind;this.values=values;}}
class LuaError extends Error {}
class Many {constructor(values){this.values=values;}}
class Scope {
 constructor(parent=null){this.parent=parent;this.cells=new Map();this.varargs=null;}
 define(name,value){this.cells.set(name,{value});}
 cell(name){return this.cells.get(name)??this.parent?.cell(name);}
 get(name){const c=this.cell(name);if(!c)throw new Unsupported('Unknown global '+name);return c.value;}
 args(){if(this.varargs!==null)return this.varargs;return this.parent?.args()??[];}
}
export class LuaTable {
 constructor(id){this.id=id;this.values=new Map();}
 get(k){return this.values.get(k)??null;}
 set(k,v){if(k===null||Number.isNaN(k))throw new LuaError('Invalid table key');if(v===null)this.values.delete(k);else this.values.set(k,v);}
 length(){let n=0;while(this.values.has(n+1))n++;return n;}
}
class Native {constructor(name,fn=null){this.name=name;this.fn=fn;}}
class Closure {constructor(node,scope){this.node=node;this.scope=scope;}}
const truth=x=>x!==null&&x!==false;
const numeric=x=>{if(typeof x!=='number'||!Number.isFinite(x))throw new LuaError('Expected finite number');return x;};
const integer=x=>Math.trunc(numeric(x));
const uint=x=>integer(x)>>>0;
const one=x=>x instanceof Many?(x.values[0]??null):x;
function visit(n,fn,skipFunctions=false){if(!n||typeof n!=='object')return;if(n.type)fn(n);for(const [k,v]of Object.entries(n)){if(k==='range'||k==='comments')continue;const child=x=>{if(!skipFunctions||x?.type!=='FunctionDeclaration')visit(x,fn,skipFunctions);};if(Array.isArray(v))v.forEach(child);else child(v);}}
const factoryCache=new WeakMap();
export function isVmFactory(node){
 if(factoryCache.has(node))return factoryCache.get(node);
 const first=node.parameters[0];if(first?.type!=='Identifier')return false;
 const slots=new Set(),comparisons=new Map();let vararg=false,dispatcher=false;
 visit({body:node.body},n=>{if(n.type==='IndexExpression'&&n.base.type==='Identifier'&&n.base.name===first.name&&n.index.type==='NumericLiteral')slots.add(n.index.value);},true);
 visit({body:node.body},n=>{
  if(n.type==='FunctionDeclaration'&&n.parameters.some(p=>p.type==='VarargLiteral'))vararg=true;
  if(n.type==='BinaryExpression'&&['<','<=','>','>=','==','~='].includes(n.operator)&&n.left.type==='Identifier'&&n.right.type==='NumericLiteral')comparisons.set(n.left.name,(comparisons.get(n.left.name)??0)+1);
  if(n.type==='RepeatStatement'&&n.body[0]?.type==='LocalStatement'&&n.body[0].init[0]?.type==='IndexExpression'&&n.body[1]?.type==='IfStatement')dispatcher=true;
 });
 const result=slots.size>=6&&vararg&&(dispatcher||Math.max(0,...comparisons.values())>=40);factoryCache.set(node,result);return result;
}
export class StaticDataEvaluator {
 constructor({maxSteps=4000000,maxTables=100000,maxDepth=100,maxMilliseconds=15000,integerBitLibrary=false,ffiUnavailable=false,tracePrimitiveWrites=false}={}){
  this.tracePrimitiveWrites=tracePrimitiveWrites;this.primitiveWriteCount=0;this.lastReadBuffer=null;this.lastReadEnd=0;
  this.ffiUnavailable=ffiUnavailable;this.integerBitLibrary=integerBitLibrary;this.limits={maxSteps,maxTables,maxDepth,maxMilliseconds};this.steps=0;this.depth=0;this.tables=[];this.started=Date.now();this.nativeCalls=new Map();this.stringBytes=0;this.bufferBytes=0;this.ownedBuffers=new WeakSet();this.bufferReads=new Map();this.callStack=[];this.root=new Scope();this.install();
 }
 tick(){if(++this.steps>this.limits.maxSteps)throw new Unsupported('AST step budget exceeded');if((this.steps&1023)===0&&Date.now()-this.started>this.limits.maxMilliseconds)throw new Unsupported('AST time budget exceeded');}
 read(b,offset,size){this.lastReadBuffer=b;this.lastReadEnd=offset+size;let r=this.bufferReads.get(b);if(!r){r={bufferBytes:b.length,calls:0,readBytes:0,maxEnd:0,lastEnd:0,contiguous:true};this.bufferReads.set(b,r);}r.calls++;r.readBytes+=size;r.contiguous=r.contiguous&&offset===r.lastEnd;r.lastEnd=offset+size;r.maxEnd=Math.max(r.maxEnd,offset+size);}
 string(value){this.stringBytes+=value.length;if(this.stringBytes>64*1024*1024)throw new Unsupported('Cumulative string allocation budget');return value;}
 table(){if(this.tables.length>=this.limits.maxTables)throw new Unsupported('Table allocation budget exceeded');const t=new LuaTable(this.tables.length+1);this.tables.push(t);
  if(this.tracePrimitiveWrites){const set=t.set.bind(t);t.primitiveWrites=[];t.set=(key,value)=>{set(key,value);if(this.lastReadBuffer&&Number.isInteger(key)&&key>0&&['string','number','boolean'].includes(typeof value)&&this.primitiveWriteCount<200000){t.primitiveWrites.push({key,end:this.lastReadEnd,buffer:this.lastReadBuffer});this.primitiveWriteCount++;}};}
  return t;}
 install(){
  const native=(name,fn=null)=>new Native(name,fn),globals={};
  const lib=(name,entries)=>{const t=this.table();t.namespace=name;for(const [k,v]of Object.entries(entries))t.set(k,native(name+'.'+k,v));globals[name]=t;return t;};
  const counttz=x=>{x=uint(x);return x===0?32:31-Math.clz32((x&-x)>>>0);};
  const shift=(x,n,left)=>{n=integer(n);if(n<0)return shift(x,-n,!left);if(n>=32)return 0;return left?(uint(x)<<n)>>>0:uint(x)>>>n;};
  lib('bit32',{
   band:(...v)=>v.reduce((a,b)=>a&uint(b),0xffffffff)>>>0,bor:(...v)=>v.reduce((a,b)=>a|uint(b),0)>>>0,bxor:(...v)=>v.reduce((a,b)=>a^uint(b),0)>>>0,
   bnot:x=>(~uint(x))>>>0,lshift:(x,n)=>shift(x,n,true),rshift:(x,n)=>shift(x,n,false),
   lrotate:(x,n)=>{n=integer(n)&31;x=uint(x);return ((x<<n)|(x>>>((32-n)&31)))>>>0;},
   rrotate:(x,n)=>{n=integer(n)&31;x=uint(x);return ((x>>>n)|(x<<((32-n)&31)))>>>0;},countlz:x=>Math.clz32(uint(x)),countrz:counttz,
  });
  if(this.integerBitLibrary){
   // Lua BitOp differs from bit32: signed results and masked shift counts.
   // Only safe integer inputs are modeled; fractional/cdata coercions fail closed.
   const int=x=>{if(!Number.isSafeInteger(x))throw new Unsupported('bit input outside safe-integer subset');return x|0;};
   const fold=(values,op)=>{if(!values.length)throw new Unsupported('bit operand required');return values.slice(1).reduce((a,b)=>op(a,int(b)),int(values[0]));};
   lib('bit',{tobit:int,band:(...v)=>fold(v,(a,b)=>a&b),bor:(...v)=>fold(v,(a,b)=>a|b),bxor:(...v)=>fold(v,(a,b)=>a^b),
    bnot:x=>~int(x),lshift:(x,n)=>int(x)<<(int(n)&31),rshift:(x,n)=>(int(x)>>>(int(n)&31))|0,arshift:(x,n)=>int(x)>>(int(n)&31),
    rol:(x,n)=>{x=int(x);n=int(n)&31;return (x<<n)|(x>>>((32-n)&31));},
    ror:(x,n)=>{x=int(x);n=int(n)&31;return (x>>>n)|(x<<((32-n)&31));},
    bswap:x=>{x=int(x);return (x<<24)|((x&0xff00)<<8)|((x>>>8)&0xff00)|(x>>>24);},tohex:null});
  }
  const mathlib=lib('math',{floor:x=>Math.floor(numeric(x)),ceil:x=>Math.ceil(numeric(x)),abs:x=>Math.abs(numeric(x)),min:(...v)=>Math.min(...v.map(numeric)),max:(...v)=>Math.max(...v.map(numeric)),ldexp:(x,n)=>numeric(x)*2**integer(n),frexp:null,random:null,randomseed:null});
  mathlib.set('huge',Infinity);mathlib.set('pi',Math.PI);
  const readers={readu8:['readUInt8',1],readi8:['readInt8',1],readu16:['readUInt16LE',2],readi16:['readInt16LE',2],readu32:['readUInt32LE',4],readi32:['readInt32LE',4],readf32:['readFloatLE',4],readf64:['readDoubleLE',8]};
  const bufferFns={};for(const [name,[fn,size]]of Object.entries(readers))bufferFns[name]=(b,offset)=>{if(!Buffer.isBuffer(b))throw new LuaError('Expected buffer');offset=integer(offset);if(offset<0||offset+size>b.length)throw new LuaError('Buffer read outside data');this.read(b,offset,size);return b[fn](offset);};
  bufferFns.readstring=(b,offset,len)=>{if(!Buffer.isBuffer(b))throw new LuaError('Expected buffer');offset=integer(offset);len=integer(len);if(offset<0||len<0||offset+len>b.length)throw new LuaError('String read outside data');this.read(b,offset,len);return this.string(b.subarray(offset,offset+len).toString('latin1'));};
  // Only newly allocated, evaluator-owned buffers can be written. The input
  // buffer passed from outside is read-only. No host IO is exposed.
  for(const name of ['copy','create','fromstring','tostring','len','writeu8','writei8','writeu16','writei16','writei32','writef32','writef64','readbits','writebits'])bufferFns[name]=null;
  bufferFns.fromstring=s=>{if(typeof s!=='string')throw new LuaError('Expected byte string');if(s.length>8*1024*1024)throw new Unsupported('Buffer size limit');this.bufferBytes+=s.length;if(this.bufferBytes>32*1024*1024)throw new Unsupported('Buffer allocation budget');const b=Buffer.from(s,'latin1');this.ownedBuffers.add(b);return b;};
  bufferFns.create=n=>{n=integer(n);if(n<0||n>8*1024*1024||(this.bufferBytes+=n)>32*1024*1024)throw new Unsupported('Buffer allocation budget');const b=Buffer.alloc(n);this.ownedBuffers.add(b);return b;};
  bufferFns.writeu32=(b,offset,n)=>{if(!this.ownedBuffers.has(b))throw new Unsupported('Cannot write external input buffer');offset=integer(offset);if(offset<0||offset+4>b.length)throw new LuaError('Buffer write outside data');b.writeUInt32LE(uint(n),offset);};
  bufferFns.copy=(dest,offset,src,start=0,count=null)=>{if(!this.ownedBuffers.has(dest)||!Buffer.isBuffer(src))throw new Unsupported('Unsupported buffer copy');offset=integer(offset);start=integer(start);count=count===null?src.length-start:integer(count);if(offset<0||start<0||count<0||offset+count>dest.length||start+count>src.length)throw new LuaError('Buffer copy outside data');src.copy(dest,offset,start,start+count);};
  bufferFns.len=b=>{if(!Buffer.isBuffer(b))throw new LuaError('Expected buffer');return b.length;};
  bufferFns.tostring=b=>{if(!Buffer.isBuffer(b))throw new LuaError('Expected buffer');return this.string(b.toString('latin1'));};
  lib('buffer',bufferFns);
  const tablelib=lib('table',{
   create:(n,fill=null)=>{n=integer(n);if(n<0||n>1000000)throw new Unsupported('Table size limit');const t=this.table();if(fill!==null)for(let i=1;i<=n;i++)t.set(i,fill);return t;},
   move:(from,start,end,target,to=from)=>{if(!(from instanceof LuaTable)||!(to instanceof LuaTable))throw new LuaError('Expected table');[start,end,target]=[start,end,target].map(integer);if(end-start>100000)throw new Unsupported('Table move limit');const values=[];for(let i=start;i<=end;i++)values.push(from.get(i));values.forEach((v,i)=>to.set(target+i,v));return to;},
   unpack:(t,start=1,end=null)=>{if(!(t instanceof LuaTable))throw new LuaError('Expected table');start=integer(start);end=end===null?t.length():integer(end);if(end-start>100000)throw new Unsupported('Unpack limit');const v=[];for(let i=start;i<=end;i++)v.push(t.get(i));return new Many(v);},
  });
  lib('string',{
   char:(...ns)=>{if(ns.length>100000)throw new Unsupported('String size limit');return this.string(ns.map(n=>{n=integer(n);if(n<0||n>255)throw new LuaError('Byte out of range');return String.fromCharCode(n);}).join(''));},
   byte:(s,i=1,j=i)=>{if(typeof s!=='string')throw new LuaError('Expected byte string');i=integer(i);j=integer(j);if(i<0)i=s.length+i+1;if(j<0)j=s.length+j+1;const a=[];for(let k=Math.max(1,i);k<=Math.min(s.length,j);k++)a.push(s.charCodeAt(k-1));return new Many(a);},
   unpack:(format,text,position=1)=>{
    if(typeof format!=='string'||typeof text!=='string')throw new LuaError('Expected unpack strings');
    const m=/^([<>]?)([iIfd])(1|2|4|8)?$/.exec(format);if(!m)throw new Unsupported('Only single-scalar unpack formats are modeled');
    const type=m[2],size=type==='f'?4:type==='d'?8:Number(m[3]??4),endian=m[1]==='>'?'BE':'LE';
    position=integer(position);if(position<0)position=text.length+position+1;const offset=position-1,b=Buffer.from(text,'latin1');
    if(offset<0||offset+size>b.length)throw new LuaError('Unpack outside string');let value;
    if(type==='f')value=b['readFloat'+endian](offset);else if(type==='d')value=b['readDouble'+endian](offset);
    else if(size===8)value=Number(b[(type==='I'?'readBigUInt64':'readBigInt64')+endian](offset));
    else value=b[(type==='I'?'readUInt':'readInt')+endian](offset,size);
    return new Many([value,position+size]);
   },match:null,rep:null,
   sub:(s,i,j=-1)=>{if(typeof s!=='string')throw new LuaError('Expected string');i=integer(i);j=integer(j);if(i<0)i=s.length+i+1;if(j<0)j=s.length+j+1;return this.string(s.slice(Math.max(0,i-1),Math.max(0,j)));},
   pack:(format,...values)=>{if(format!=='<I4'||values.length!==1)throw new Unsupported('Unsupported string.pack format');const n=numeric(values[0]);if(!Number.isInteger(n)||n<0||n>0xffffffff)throw new LuaError('Packed word out of range');const b=Buffer.alloc(4);b.writeUInt32LE(n);return this.string(b.toString('latin1'));},
   gsub:(text,pattern,replacement,limit=Infinity)=>{
    if(typeof text!=='string'||!['z','.....'].includes(pattern))throw new Unsupported('Only observed base85 gsub patterns are allowed');
    if(limit!==Infinity)limit=integer(limit);let count=0,position=0;const parts=[];
    while(position<text.length){this.tick();const start=pattern==='z'?text.indexOf('z',position):position;
     if(count>=limit||start<0||(pattern==='.....'&&start+5>text.length)){parts.push(text.slice(position));break;}
     parts.push(text.slice(position,start));const end=start+(pattern==='z'?1:5),match=text.slice(start,end);let result;
     if(typeof replacement==='string'){if(replacement.includes('%'))throw new Unsupported('gsub replacement captures not implemented');result=replacement;}
     else if(replacement instanceof LuaTable)result=this.get(replacement,match);
     else result=one(this.call(replacement,[match]));
     if(result===null||result===false)result=match;
     if(!['number','string'].includes(typeof result))throw new LuaError('Invalid replacement value');
     parts.push(String(result));position=end;count++;
    }
    return new Many([this.string(parts.join('')),count]);
   },
  });
  lib('utf8',{char:null,len:null,codepoint:null,codes:null,offset:null,nfcnormalize:null,nfdnormalize:null,graphemes:null});
  lib('coroutine',{yield:null,wrap:null,create:null,resume:null});
  for(const name of ['getfenv','setfenv','loadstring','load','require','setmetatable','getmetatable','newproxy','print','tostring','tonumber','select','next'])globals[name]=native(name);
  globals.setmetatable=native('setmetatable',(t,meta)=>{if(!(t instanceof LuaTable)||!(meta instanceof LuaTable))throw new Unsupported('Unsupported metatable operation');if([...meta.values.keys()].some(k=>k!=='__index'))throw new Unsupported('Only __index data metatables are modeled');t.meta=meta;return t;});
  if(this.ffiUnavailable)globals.require=native('require',name=>{if(name!=='ffi')throw new Unsupported('Module loading remains blocked');throw new LuaError('ffi unavailable in explicit research profile');});
  globals.type=native('type',x=>x===null?'nil':x instanceof Closure||x instanceof Native?'function':x instanceof LuaTable?'table':Buffer.isBuffer(x)?'buffer':typeof x);
  globals.unpack=tablelib.get('unpack');
  globals.error=native('error',x=>{throw new LuaError(typeof x==='string'?x:'Lua error');});
  globals.assert=native('assert',(x,...rest)=>{if(!truth(x))throw new LuaError('Lua assertion');return new Many([x,...rest]);});
  globals.pcall=native('pcall',(fn,...args)=>{try{const r=this.call(fn,args);return new Many([true,...(r instanceof Many?r.values:[r])]);}catch(e){if(e instanceof LuaError)return new Many([false,e.message]);throw e;}});
  // Known Luau library members may be stored as opaque identity values. Their
  // presence is explicit; calls remain blocked unless implemented above.
  const opaqueMembers={
   string:'find format gmatch len lower reverse upper split packsize',
   table:'concat foreach foreachi getn maxn insert remove sort pack find clear freeze isfrozen clone',
   math:'acos asin atan2 atan cosh cos deg exp fmod log10 log modf pow rad sinh sin sqrt tanh tan noise clamp sign round map lerp isnan isinf isfinite',
   bit32:'arshift btest extract replace byteswap',
   coroutine:'status running isyieldable close',
  };
  for(const [library,names]of Object.entries(opaqueMembers))for(const name of names.split(' '))if(!globals[library].values.has(name))globals[library].set(name,native(library+'.'+name));
  for(const [k,v]of Object.entries(globals))this.root.define(k,v);
 }
 get(base,key){if(base instanceof LuaTable){if(base.namespace&&!base.values.has(key))throw new Unsupported('Unmodeled builtin member '+base.namespace+'.'+String(key));const value=base.get(key);if(value!==null)return value;const index=base.meta?.get('__index')??null;if(index instanceof LuaTable)return this.get(index,key);if(index!==null)return one(this.call(index,[base,key]));return null;}throw new LuaError('Index of non-table');}
 expressions(nodes,scope){const out=[];nodes.forEach((n,i)=>{const v=this.eval(n,scope);if(i===nodes.length-1&&v instanceof Many)out.push(...v.values);else out.push(one(v));});return out;}
 eval(n,scope){const value=this.evalValue(n,scope);return n.inParens?one(value):value;}
 evalValue(n,scope){
  this.tick();const value=x=>one(this.eval(x,scope));
  switch(n.type){
   case 'NilLiteral':return null;
   case 'NumericLiteral':case 'StringLiteral':case 'BooleanLiteral':return n.value;
   case 'Identifier':return scope.get(n.name);
   case 'VarargLiteral':return new Many(scope.args());
   case 'FunctionDeclaration':return new Closure(n,scope);
   case 'TableConstructorExpression':{const t=this.table();let i=1;n.fields.forEach((f,j)=>{if(f.type==='TableKeyString')t.set(f.key.name,value(f.value));else if(f.type==='TableKey')t.set(value(f.key),value(f.value));else{const v=this.eval(f.value,scope);const a=j===n.fields.length-1&&v instanceof Many?v.values:[one(v)];a.forEach(x=>t.set(i++,x));}});return t;}
   case 'MemberExpression':return this.get(value(n.base),n.identifier.name);
   case 'IndexExpression':return this.get(value(n.base),value(n.index));
   case 'LogicalExpression':{const a=value(n.left);return n.operator==='and'?(truth(a)?value(n.right):a):(truth(a)?a:value(n.right));}
   case 'UnaryExpression':{const a=value(n.argument);if(n.operator==='not')return !truth(a);if(n.operator==='-')return -numeric(a);if(n.operator==='#'){if(typeof a==='string')return a.length;if(a instanceof LuaTable)return a.length();}throw new Unsupported('Unary operator '+n.operator);}
   case 'BinaryExpression':{
    const a=value(n.left),b=value(n.right);
    switch(n.operator){case '==':return a===b;case '~=':return a!==b;case '<':case '<=':case '>':case '>=':{if(typeof a!==typeof b||!['string','number'].includes(typeof a))throw new LuaError('Invalid comparison');return n.operator==='<'?a<b:n.operator==='<='?a<=b:n.operator==='>'?a>b:a>=b;}
    case '+':return numeric(a)+numeric(b);case '-':return numeric(a)-numeric(b);case '*':return numeric(a)*numeric(b);case '/':return numeric(a)/numeric(b);case '^':return numeric(a)**numeric(b);case '//':return Math.floor(numeric(a)/numeric(b));case '%':return numeric(a)-Math.floor(numeric(a)/numeric(b))*numeric(b);case '..':if(!['string','number'].includes(typeof a)||!['string','number'].includes(typeof b))throw new LuaError('Invalid concatenation');return this.string(String(a)+String(b));default:throw new Unsupported('Binary operator '+n.operator);}
   }
   case 'CallExpression':case 'TableCallExpression':case 'StringCallExpression':{
    let fn,self,method=false;
    if(n.base.type==='MemberExpression'&&n.base.indexer===':'){self=value(n.base.base);fn=this.get(self,n.base.identifier.name);method=true;}else fn=value(n.base);
    const args=n.type==='CallExpression'?this.expressions(n.arguments,scope):[value(n.type==='TableCallExpression'?n.arguments:n.argument)];
    if(method)args.unshift(self);
    return this.call(fn,args);
   }
   default:throw new Unsupported('Expression '+n.type);
  }
 }
 call(fn,args){
  this.tick();if(this.selectingFactory&&fn!==this.selectingFactory&&(!(fn instanceof Native)||!(fn.name.startsWith('bit32.')||(this.integerBitLibrary&&fn.name.startsWith('bit.'))||fn.name==='type')))throw new Unsupported('Factory selection attempted a call outside its pure selector');if(fn instanceof Native){this.nativeCalls.set(fn.name,(this.nativeCalls.get(fn.name)??0)+1);if(!fn.fn)throw new Unsupported('Blocked native call '+fn.name);return fn.fn(...args)??null;}
  if(!(fn instanceof Closure))throw new LuaError('Call of non-function');
  if(isVmFactory(fn.node)&&fn!==this.selectingFactory)throw new Boundary({closure:fn,args});
  if(++this.depth>this.limits.maxDepth)throw new Unsupported('Call depth budget');
  this.callStack.push(fn);
  try{const s=new Scope(fn.scope);let i=0;for(const p of fn.node.parameters){if(p.type==='VarargLiteral')s.varargs=args.slice(i);else s.define(p.name,args[i++]??null);}if(s.varargs===null)s.varargs=[];
   try{this.block(fn.node.body,s,false);}catch(e){if(e instanceof Flow&&e.kind==='return')return new Many(e.values);if(e instanceof Flow&&e.kind==='goto')throw new Unsupported('Goto cannot cross a function boundary');throw e;}return new Many([]);
  }finally{this.depth--;this.callStack.pop();}
 }
 assignTarget(n,scope){
  if(n.type==='Identifier'){const cell=scope.cell(n.name);if(!cell)throw new Unsupported('Global write '+n.name);return v=>{if(this.selectingFactory&&this.selectionExistingCells.has(cell))throw new Unsupported('Factory selector attempted to change captured data');cell.value=v;};}
  if(n.type==='IndexExpression'||n.type==='MemberExpression'){const t=one(this.eval(n.base,scope)),k=n.type==='MemberExpression'?n.identifier.name:one(this.eval(n.index,scope));if(!(t instanceof LuaTable))throw new LuaError('Assignment to non-table');return v=>{if(this.selectingFactory&&t.id<=this.selectionExistingTables)throw new Unsupported('Factory selector attempted to change parsed data');t.set(k,v);};}
  throw new Unsupported('Assignment target '+n.type);
 }
 block(nodes,scope,newScope=true){
  const s=newScope?new Scope(scope):scope,labels=new Map();
  nodes.forEach((n,i)=>{if(n.type==='LabelStatement'){if(labels.has(n.label.name))throw new Unsupported('Duplicate label');labels.set(n.label.name,i);}});
  for(let i=0;i<nodes.length;i++){
   try{this.statement(nodes[i],s);}catch(error){
    if(!(error instanceof Flow)||error.kind!=='goto'||!labels.has(error.values[0]))throw error;
    const target=labels.get(error.values[0]);
    const crossed=nodes.slice(Math.min(i,target)+1,Math.max(i,target)+1);
    if(crossed.some(n=>n.type==='LocalStatement'||n.type==='FunctionDeclaration'&&n.isLocal))throw new Unsupported('Goto crossing local declaration requires scope modeling');
    i=target-1;
   }
  }
  return s;
 }
 statement(n,s){
  this.tick();const val=x=>one(this.eval(x,s));
  switch(n.type){
   case 'LocalStatement':{const a=this.expressions(n.init,s);n.variables.forEach((v,i)=>s.define(v.name,a[i]??null));return;}
   case 'CompoundAssignmentStatement':{
    const target=n.variable;let read,write;
    if(target.type==='Identifier'){const cell=s.cell(target.name);if(!cell)throw new Unsupported('Global compound write');read=()=>cell.value;write=v=>{if(this.selectingFactory&&this.selectionExistingCells.has(cell))throw new Unsupported('Factory selector attempted to change captured data');cell.value=v;};}
    else if(target.type==='IndexExpression'||target.type==='MemberExpression'){const base=one(this.eval(target.base,s)),key=target.type==='MemberExpression'?target.identifier.name:one(this.eval(target.index,s));if(!(base instanceof LuaTable))throw new LuaError('Compound assignment to non-table');read=()=>this.get(base,key);write=v=>{if(this.selectingFactory&&base.id<=this.selectionExistingTables)throw new Unsupported('Factory selector attempted to change parsed data');base.set(key,v);};}
    else throw new Unsupported('Compound target');
    const a=read(),b=val(n.value);write(this.eval({type:'BinaryExpression',operator:n.operator,left:{type:'NumericLiteral',value:a},right:{type:'NumericLiteral',value:b}},s));return;
   }
   case 'AssignmentStatement':{const targets=n.variables.map(v=>this.assignTarget(v,s)),a=this.expressions(n.init,s);targets.forEach((f,i)=>f(a[i]??null));return;}
   case 'CallStatement':if(n.expression.base.type==='Identifier'&&n.expression.base.name==='__analysis_continue')throw new Flow('continue');this.eval(n.expression,s);return;
   case 'ReturnStatement':throw new Flow('return',this.expressions(n.arguments,s));
   case 'BreakStatement':throw new Flow('break');
   case 'LabelStatement':return;
   case 'GotoStatement':throw new Flow('goto',[n.label.name]);
   case 'DoStatement':this.block(n.body,s);return;
   case 'IfStatement':for(const c of n.clauses)if(!c.condition||truth(val(c.condition))){this.block(c.body,s);break;}return;
   case 'ForNumericStatement':{const start=numeric(val(n.start)),end=numeric(val(n.end)),step=n.step?numeric(val(n.step)):1;if(step===0)throw new Unsupported('Zero loop step');for(let i=start;step>0?i<=end:i>=end;i+=step){this.tick();const child=new Scope(s);child.define(n.variable.name,i);try{this.block(n.body,child,false);}catch(e){if(e instanceof Flow&&e.kind==='break')break;if(e instanceof Flow&&e.kind==='continue')continue;throw e;}}return;}
   case 'WhileStatement':while(truth(val(n.condition))){this.tick();try{this.block(n.body,s);}catch(e){if(e instanceof Flow&&e.kind==='break')break;if(e instanceof Flow&&e.kind==='continue')continue;throw e;}}return;
   case 'RepeatStatement':{for(;;){this.tick();const child=new Scope(s);try{this.block(n.body,child,false);}catch(e){if(e instanceof Flow&&e.kind==='break')break;if(!(e instanceof Flow&&e.kind==='continue'))throw e;}if(truth(one(this.eval(n.condition,child))))break;}return;}
   case 'FunctionDeclaration':{if(!n.identifier)throw new Unsupported('Unnamed statement function');if(n.isLocal){s.define(n.identifier.name,null);s.cell(n.identifier.name).value=new Closure(n,s);}else this.assignTarget(n.identifier,s)(new Closure(n,s));return;}
   default:throw new Unsupported('Statement '+n.type);
  }
 }
 run(source,data){
  const ast=lp.parse(source,{luaVersion:'5.3',encodingMode:'pseudo-latin1',comments:false});
  return this.runAst(ast,data);
 }
 runAst(ast,data){
  const s=new Scope(this.root);s.varargs=data===undefined?[]:[data];
  try{this.block(ast.body,s,false);return {status:'finished-data-evaluation'};}catch(e){if(e instanceof Boundary)return {status:'vm-boundary',args:e.value.args,closure:e.value.closure};if(e instanceof Flow&&e.kind==='return')return {status:'returned',values:e.values};throw e;}
 }
 selectFrame(boundary){
  this.selectedFrame=null;
  if(boundary.status!=='vm-boundary')throw new Unsupported('No factory boundary to select');
  this.selectingFactory=boundary.closure;this.selectionExistingTables=this.tables.length;this.selectionExistingCells=new WeakSet();
  for(let scope=boundary.closure.scope;scope;scope=scope.parent)for(const cell of scope.cells.values())this.selectionExistingCells.add(cell);
  try{const frame=one(this.call(boundary.closure,boundary.args));if(!(frame instanceof Closure))throw new Unsupported('Factory did not return a closure');this.selectedFrame=frame;return frame.node;}
  finally{this.selectingFactory=null;}
 }
 snapshotFrameBindings(names){
  if(!this.selectedFrame)throw new Unsupported('No selected frame bindings');
  if(!Array.isArray(names)||names.length>512||names.some(n=>typeof n!=='string'||n.length>256))throw new Unsupported('Frame binding request limit');
  const encode=x=>{if(x===null||typeof x==='string'||typeof x==='boolean')return x;
   if(typeof x==='number')return Number.isFinite(x)?x:{number:String(x)};
   if(x instanceof LuaTable)return {table:x.id};
   if(x instanceof Native)return {native:x.name};
   if(x instanceof Closure)return {closure:true,vmFactory:isVmFactory(x.node)};
   if(Buffer.isBuffer(x))return {bufferBytes:x.length};return {unknown:true};};
  return {schema:1,kind:'selected-frame-lexical-bindings',fullRecoveryVerified:false,selectedFrameNotInvoked:true,
   bindings:[...new Set(names)].map(name=>{const cell=this.selectedFrame.scope.cell(name);
    return cell?{name,resolved:true,value:encode(cell.value)}:{name,resolved:false};}),
   limitations:['Closure bodies and captured cells are not serialized by this artifact.',
    'Native identity is not approval to invoke it; VM and application effects remain unmodeled.']};
 }
 snapshotFrameHelpers(names){
  const bindings=this.snapshotFrameBindings(names),helpers=[];let bytes=0;
  const ids=new Set(bindings.bindings.filter(b=>b.resolved&&b.value?.table).map(b=>b.value.table));
  for(const id of ids){const table=this.tables.find(t=>t.id===id);if(!table)throw new Unsupported('Missing captured table');
   for(const [key,value]of table.values){
    if(!(value instanceof Closure)||isVmFactory(value.node))continue;
    if(typeof key!=='number'&&typeof key!=='string')continue;
    // Reuse the exact lexical binding encoder, without invoking this closure.
    const frame=this.selectedFrame;let captures;
    try{this.selectedFrame=value;const seen=new Set();
     for(let scope=value.scope;scope;scope=scope.parent)for(const name of scope.cells.keys())seen.add(name);
     captures=this.snapshotFrameBindings([...seen]).bindings;
    }finally{this.selectedFrame=frame;}
    const record={table:id,key,node:value.node,captures};
    bytes+=Buffer.byteLength(JSON.stringify(record));
    if(bytes>8*1024*1024||helpers.length>=256)throw new Unsupported('Captured helper artifact limit');
    helpers.push(record);
   }
  }
  return {schema:1,kind:'captured-helper-asts',fullRecoveryVerified:false,programCallsExecuted:false,helpers,
   limitations:['Only direct non-factory closures in requested captured tables are included.',
    'Closure-valued captures are unresolved descriptors; helper bodies are not approved to execute.']};
 }
 snapshot(result){
  const encode=x=>{if(x===null||typeof x==='string'||typeof x==='boolean')return x;if(typeof x==='number')return Number.isFinite(x)?x:{number:String(x)};if(x instanceof LuaTable)return {table:x.id};if(x instanceof Native)return {native:x.name};if(x instanceof Closure)return {closure:true,vmFactory:isVmFactory(x.node)};if(Buffer.isBuffer(x))return {bufferBytes:x.length};return {unknown:true};};
  return {status:result.status,steps:this.steps,allocatedTables:this.tables.length,nativeCalls:Object.fromEntries(this.nativeCalls),bufferReads:[...this.bufferReads.values()].map(r=>({...r,trailingBytes:r.bufferBytes-r.maxEnd})),args:result.args?.map(encode),tables:this.tables.map(t=>({id:t.id,entries:[...t.values].map(([k,v])=>[encode(k),encode(v)])})),vmExecuted:false,fullRecoveryVerified:false};
 }
}
