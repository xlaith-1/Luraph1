// Bounded AST data capture. Never executes the decoded application or native Lua.
import {StaticDataEvaluator,LuaTable,isVmFactory} from './static-data-eval.mjs';
import lp from './vendor/luaparse.cjs';
import {learnPoolLayout,validatePoolAt,periodicApplicationCandidates} from './serialized-pool.mjs';
import {inferPeriodicPool} from './periodic-pool.mjs';
import {analyzeRemainder} from './payload-analysis.mjs';
import {extractHandlers} from './dispatch147.mjs';
const walk=(n,fn)=>{if(!n||typeof n!=='object')return;if(n.type)fn(n);for(const[k,v]of Object.entries(n)){if(['range','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>walk(x,fn));else walk(v,fn);}};
const flat=nodes=>nodes.flatMap(n=>n.type==='DoStatement'?flat(n.body):[n]);
const slot=(n,d)=>n?.type==='IndexExpression'&&n.index?.name===d.read.programCounter?d.slotAliases[n.base?.name]:undefined;
function proto(t,d){return t instanceof LuaTable&&typeof t.get(d.frame.registerCountSlot)==='number'&&t.get(d.read.opcodeSlot) instanceof LuaTable&&Object.values(d.slotAliases).filter(s=>t.get(s) instanceof LuaTable).length>=6;}
function header(b,offset=0){let n=0,j=offset;for(let shift=0;shift<35&&j<b.length;shift+=7){let x=b[j++];n+=(x&127)*2**shift;if(x<128)return {n,end:j};}return null;}
function masksFromBootstrap(e,r,d){
 const specs=[];
 for(const h of d.handlers)walk(h.body,n=>{if(n.type!=='CallExpression'||n.arguments.length!==2)return;
  const s=slot(n.arguments[1],d);if(!s)return;
  // This discovers candidates inside captured guards too; uniqueness is still
  // checked against encrypted strings before any constants are returned.
  try{if(e.eval(n.base,e.selectedFrame.scope)?.name==='bit32.bxor')specs.push({opcode:h.opcode,slot:s});}catch{}
 });
 const found=[];
 for(const p of e.tables.filter(t=>proto(t,d)))for(const spec of specs)for(const[pc,op]of p.get(d.read.opcodeSlot).values){const value=p.get(spec.slot).get(pc);if(op===spec.opcode&&Number.isInteger(value)&&value>=0&&value<=255)found.push({prototype:p.id,pc,value,...spec});}
 return found;
}
export function solveCipher(strings,masks,{deadline=Infinity}={}){
 const unique=[...new Set(strings.filter(s=>s.length>=7&&s.length<=24))];
 if(!unique.length)throw Error('No suitable cipher-validation strings');
 const maskValues=[...new Set(masks.filter(m=>Number.isInteger(m)&&m>=0&&m<=255))];
 if(!maskValues.length)throw Error('No captured XOR mask evidence');
 const printable=(s,m,a,k)=>{let state=s.charCodeAt(1);for(let i=2;i<s.length;i++){state=(state*m+a)&255;const ch=s.charCodeAt(i)^state^k;if(ch<32||ch>126)return false;}return true;};
 const check=()=>{if(Date.now()>deadline)throw Error('String cipher deadline');};
 const legacy=unique.slice(0,4),candidates=[];
 for(const mask of maskValues)for(let multiplier=0;multiplier<256;multiplier++){
  check();for(let increment=0;increment<256;increment++)if(candidates.length<2&&legacy.every(s=>printable(s,multiplier,increment,mask)))candidates.push({multiplier,increment,mask});
 }
 if(candidates.length===1)return {...candidates[0],method:'unique-prefix-probes',validation:'Unique printable-string solution constrained by captured bootstrap XOR operands; not a general cryptographic proof'};
 // A few binary or UTF-8 strings at the front must not invalidate the entire
 // pool. Require independent consensus and a substantial runner-up margin.
 // This remains heuristic: never describe successful scoring as full recovery.
 if(unique.length<8)throw Error('String cipher ambiguous: '+candidates.length+' candidates');
 const probes=unique.length<=24?unique:unique.slice(0,12).concat(Array.from({length:12},(_,i)=>unique[12+Math.floor(i*(unique.length-12)/12)]));
 let best=null,bestScore=0,secondScore=0;
 for(const mask of maskValues)for(let multiplier=0;multiplier<256;multiplier++){
  check();for(let increment=0;increment<256;increment++){
   let score=0;for(const s of probes)if(printable(s,multiplier,increment,mask))score++;
   if(score>bestScore){secondScore=bestScore;bestScore=score;best={multiplier,increment,mask};}else if(score>secondScore)secondScore=score;
  }
 }
 const required=Math.max(6,Math.ceil(probes.length*0.6));
 if(bestScore<required||bestScore-secondScore<Math.max(3,Math.ceil(probes.length*0.15)))throw Error('String cipher has insufficient consensus or is ambiguous');
 return {...best,method:'independent-probe-consensus',printableProbes:bestScore,totalProbes:probes.length,runnerUpProbes:secondScore,validation:'Heuristic printable consensus constrained by captured XOR operands; binary strings retained, not proof of correct decryption'};
}
export function decodeConstant(s,key){let state=s.charCodeAt(1),out='';for(let i=2;i<s.length;i++){state=(state*key.multiplier+key.increment)&255;out+=String.fromCharCode(s.charCodeAt(i)^state^key.mask);}return out;}
// Isolate only a structurally reviewed terminal loader, never execute a Roblox
// prelude or invent mocks for workspace/game. This is loader-only recovery, not
// an assertion that skipped side effects cannot change whole-program behavior.
export function selectLoaderAst(source){
 const options={luaVersion:'5.3',encodingMode:'pseudo-latin1',comments:false,ranges:true};
 const ast=lp.parse(source,options),last=ast.body.at(-1);
 const unchanged={ast,report:{kind:'whole-loader-input',skippedTopLevelStatements:0}};
 if(ast.body.length<2||last?.type!=='ReturnStatement'||last.arguments.length!==1||last.arguments[0].type!=='CallExpression')return unchanged;
 let reviewed=false;walk(last,n=>{if(n.type==='FunctionDeclaration'&&isVmFactory(n))reviewed=true;});
 if(!reviewed)return unchanged;
 const prefix=ast.body.slice(0,-1),prefixNames=new Set();let otherFactory=false;
 walk(prefix,n=>{if(n.type==='Identifier')prefixNames.add(n.name);if(n.type==='FunctionDeclaration'&&isVmFactory(n))otherFactory=true;});
 if(!['workspace','game','script'].some(n=>prefixNames.has(n)))return unchanged;
 if(otherFactory)throw Error('Embedded loader isolation refused: multiple VM-bearing regions');
 if(['_G','_ENV','getfenv','setfenv','require','load','loadstring'].some(n=>prefixNames.has(n)))throw Error('Embedded loader isolation refused: prelude environment mutation or dynamic loading');
 const isolated=lp.parse(source.slice(...last.range),{...options,scope:true});
 // Conservative dependency test: even a read of a loader global in the skipped
// code disqualifies isolation. No skipped local/global bindings are fabricated.
 const dependencies=isolated.globals.filter(n=>prefixNames.has(n.name));
 if(dependencies.length)throw Error('Embedded loader isolation refused: prelude shares loader dependencies');
 return {ast:isolated,report:{kind:'embedded-terminal-loader',skippedTopLevelStatements:prefix.length,preludeExecuted:false,coverage:'Luraph loader only; preceding Roblox code and its effects are excluded'}};
}
export function captureConstants(source,options={}){
 const selected=selectLoaderAst(source);
 try{const result=captureAst(selected.ast,options);return {...result,report:{...result.report,loaderScope:selected.report}};}
 catch(error){error.details={...error.details,loaderScope:selected.report};throw error;}
}
function captureAst(ast,{milliseconds=120000,onProgress=()=>{},inputData}={}){
 const deadline=Date.now()+milliseconds;
 let factoryCandidates=0;walk(ast,n=>{if(n.type==='FunctionDeclaration'&&isVmFactory(n))factoryCandidates++;});
 if(!factoryCandidates)throw Error('Detection failed: no reviewed VM-factory structure');
 onProgress('validated-loader-structure');
 const make=(tracePrimitiveWrites=false)=>new StaticDataEvaluator({tracePrimitiveWrites,maxSteps:1500000000,maxMilliseconds:Math.max(1,Math.min(600000,deadline-Date.now())),maxTables:200000});
 onProgress('capturing-bootstrap');const bootstrap=make(true),boundary=bootstrap.runAst(ast,inputData);
 if(boundary.status!=='vm-boundary')throw Error('No supported VM boundary');
 bootstrap.selectFrame(boundary);const description=extractHandlers(boundary.closure.node,null,bootstrap.selectedFrame.node);
 if(!description.read||!description.frame)throw Error('Unrecognized prototype layout');
 const masks=masksFromBootstrap(bootstrap,boundary,description);if(!masks.length)throw Error('No reviewed string-cipher signature');
 const blobs=[...bootstrap.bufferReads].filter(([b,r])=>r.lastEnd<b.length);if(blobs.length!==1)throw Error('Ambiguous payload buffer');
 const [blob,read]=blobs[0],first=header(blob);
 const pools=bootstrap.tables.filter(t=>t.length()===t.values.size&&[...t.values.values()].some(v=>typeof v==='string')&&[...t.values.values()].some(v=>typeof v==='number')&&[...t.values.values()].every(v=>['string','number','boolean'].includes(typeof v))).sort((a,b)=>b.length()-a.length());
 if(!pools.length)throw Error('No primitive bootstrap constant pool');
 const base=first.n-pools[0].length();
 if(!Number.isSafeInteger(base)||base<0)throw Error('Unsupported constant-count encoding');
 const layout=learnPoolLayout(blob,pools[0]);
 const offsets=[],legacyOffsets=[];
 for(let offset=read.lastEnd;offset<Math.min(read.lastEnd+(layout?4096:1024),blob.length-8);offset++){
  if(layout){const validated=validatePoolAt(blob,offset,layout);if(validated)offsets.push(validated);}
  if(offset>=read.lastEnd+1024)continue;
  const h=header(blob,offset);if(!h)continue;const count=h.n-base;
  if(count<1||count>Math.min(100000,Math.floor((blob.length-h.end)/2))||blob[h.end]===0)continue;
  const tag=blob[h.end+1],window=blob.subarray(h.end+1,h.end+81);let frequency=0;for(const b of window)if(b===tag)frequency++;
  if(count<=4||frequency>=3)legacyOffsets.push({offset,count});
 }
 for(const candidate of legacyOffsets)if(!offsets.some(c=>c.offset===candidate.offset))offsets.push(candidate);
 const attempts=[];
 function replay(candidate,data=blob,profile='direct-serialized-application'){
  if(Date.now()>deadline)throw Error('Constant capture deadline');
  onProgress('capturing-application');const e=make(),payload=data.subarray(candidate.offset);
  for(const[name,n]of e.root.get('buffer').values)if(name.startsWith('read')&&n.fn){const original=n.fn;n.fn=(b,...args)=>original(b.length===blob.length?payload:b,...args);}
  try{
   const r=e.runAst(ast,inputData);if(r.status!=='vm-boundary')throw Error('Not a VM boundary');
   const reads=[...e.bufferReads.values()];if(reads.length!==1||payload.length-reads[0].lastEnd>16)throw Error('Incomplete application parse');
   const records=e.tables.filter(t=>['string','number','boolean'].includes(t.get(2))&&t.get(3) instanceof LuaTable&&typeof t.get(4)==='number');
   const encrypted=records.filter(t=>t.get(2)==='string');if(!encrypted.length)throw Error('No application strings');
   onProgress('decoding-constants');const key=solveCipher(encrypted.map(t=>t.get(1)),masks.map(m=>m.value),{deadline});
   const scalarDecoder=bootstrap.tables.filter(t=>proto(t,description)).find(p=>{const vals=Object.values(description.slotAliases).flatMap(s=>p.get(s) instanceof LuaTable?[...p.get(s).values.values()]:[]);return vals.includes('number')&&vals.includes('boolean');});
   e.selectFrame(r);const applicationDescription=extractHandlers(r.closure.node,null,e.selectedFrame.node);
   const result=organize(e,r,applicationDescription,records,key,!!scalarDecoder);
   return {...result,report:{...result.report,status:'partial-constants',applicationEncoding:profile,payloadOffset:candidate.offset,payloadBytes:payload.length,unconsumedBytes:payload.length-reads[0].lastEnd,bootstrapSteps:bootstrap.steps,applicationParseSteps:e.steps,cipher:key,cipherEvidence:masks.filter(m=>m.value===key.mask),attempts,applicationExecuted:false,thirdPartyUpload:false,fullRecoveryVerified:false}};
  }catch(err){attempts.push({offset:candidate.offset,profile,error:err.message});return null;}
 }
 for(const candidate of offsets.slice(0,48)){const result=replay(candidate);if(result)return result;}
 // A separately validated, flat inventory fallback for the reviewed periodic
 // tagged-pool family. No inferred scalars or prototype relationships are emitted.
 onProgress('probing-periodic-pool');
 let periodicFailure=null;
 try{
  const pool=inferPeriodicPool(blob,read.lastEnd,{deadline});
  if(pool){
   const typed=periodicApplicationCandidates(blob,pool.report.guessedKeyHex,read.lastEnd,layout,pool.report.poolStart,{deadline,minStringEnd:pool.strings.reduce((end,s)=>Math.max(end,s.byteEnd),0)});
   if(typed?.candidates.length===1){
    const result=replay(typed.candidates[0],typed.decoded,'periodic-masked-serialized-application');
    if(result){result.report.periodicPool={...pool.report,validation:'Key candidate validated by typed pool and full application parse'};result.report.serializedPool={...typed.candidates[0],strings:undefined,layout};return result;}
   }
   const key=solveCipher(pool.strings.map(s=>s.value),masks.map(m=>m.value),{deadline});
   const decoded=pool.strings.map(s=>({...s,value:decodeConstant(s.value,key)}));
   const probes=decoded.filter(s=>s.value.length>=5&&s.value.length<=80);
   const held=Array.from({length:Math.min(64,probes.length)},(_,i)=>probes[Math.floor(i*probes.length/Math.min(64,probes.length))]);
   const printable=held.filter(s=>/^[\x20-\x7e]+$/.test(s.value)).length;
   if(held.length<16||printable<Math.ceil(held.length*0.6))throw Error('Periodic pool failed independent text validation');
   const values=new Map();for(const s of decoded){let item=values.get(s.value);if(!item){item={value:s.value,count:0,uses:[]};values.set(s.value,item);}item.count++;item.uses.push({byteStart:s.byteStart,byteEnd:s.byteEnd});}
   return {inventory:[...values.values()],protos:[],wrapper_values:[],report:{status:'partial-string-inventory',inventoryOnly:true,prototypeCount:0,uniqueStringCount:values.size,stringOccurrences:decoded.length,bootstrapSteps:bootstrap.steps,applicationExecuted:false,thirdPartyUpload:false,fullRecoveryVerified:false,cipher:key,cipherEvidence:masks.filter(m=>m.value===key.mask),periodicPool:pool.report,independentValidation:{sampledStrings:held.length,printableStrings:printable},attempts,limitations:['Flat string inventory only; no application prototype, numeric, boolean or closure recovery.','Periodic key and tag widths are inferred, not a verified complete serializer.','The pool ending and completeness are not certified; additional or binary candidates are preserved.']}};
  }
 }catch(err){periodicFailure=err.message;}
 const error=Error('No validated application constant capture; bootstrap parsed, but remaining payload is unsupported or incomplete');
 error.details={phase:'application-capture',periodicFailure,...analyzeRemainder(blob,read.lastEnd),candidateOffsets:offsets.length,attemptedOffsets:attempts.length,attempts};throw error;
}
function organize(e,r,d,records,key,scalarCodec){
 const root=r.args[0],all=e.tables.filter(t=>proto(t,d));if(!all.includes(root))throw Error('Invalid root prototype');
 const ids=new Map([[root,0]]),queue=[root],parents=new Map(),edges=new Map();
 for(let i=0;i<queue.length;i++){const p=queue[i],children=[];for(const s of new Set(Object.values(d.slotAliases))){const arr=p.get(s);if(!(arr instanceof LuaTable))continue;for(const[pc,v]of arr.values)if(all.includes(v))children.push({pc,child:v});}
  children.sort((a,b)=>a.pc-b.pc);edges.set(p,children);for(const{child}of children)if(!ids.has(child)){ids.set(child,ids.size);parents.set(child,p);queue.push(child);}
 }
 const protos=queue.map(p=>({id:ids.get(p),...(parents.has(p)?{parent:ids.get(parents.get(p))}:{}),strings:[],numbers:[],booleans:[],closures:[...new Set((edges.get(p)??[]).map(x=>ids.get(x.child)))]}));
 const wrapper=[],seen=new Map();let stringOccurrences=0,unresolvedNumbers=0;
 // Keep every captured string use in its recorded prototype. Environment and
 // method lookup operands are still constants of that prototype; moving them
 // to a wrapper bucket destroyed grouping and mistook scratch registers for globals.
 const literalSlots=new Map();
 function collect(n,set){if(!n||typeof n!=='object')return;const direct=slot(n,d);if(direct){set.add(direct);return;}if(n.type==='IndexExpression'&&n.base?.name===d.frame.registerArray)return;for(const[k,v]of Object.entries(n)){if(['range','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>collect(x,set));else collect(v,set);}}
 for(const h of d.handlers){const nodes=flat(h.body);if(nodes.length!==1)continue;const n=nodes[0],set=new Set();if(n.type==='AssignmentStatement'){let lhs=n.variables[0],root=lhs;while(root?.type==='IndexExpression')root=root.base;if(root?.name!==d.frame.registerArray)continue;collect(n.init[0],set);if(lhs.base?.type==='IndexExpression')collect(lhs.index,set);}else if(n.type==='IfStatement')for(const c of n.clauses)collect(c.condition,set);let dest=n.type==='AssignmentStatement'?n.variables[0]:null;while(dest?.base?.type==='IndexExpression')dest=dest.base;const regSlot=dest?.base?.name===d.frame.registerArray?slot(dest.index,d):null;literalSlots.set(h.opcode,{slots:set,regSlot,simple:n.type==='AssignmentStatement'});}

 function add(list,map,value,occurrence){const k=typeof value+':'+String(value);let entry=map.get(k);if(!entry){entry={value,count:0,uses:[]};map.set(k,entry);list.push(entry);}entry.count++;entry.uses.push(occurrence);}
 for(const record of records){const kind=record.get(2);if(kind!=='string'&&!scalarCodec){unresolvedNumbers++;continue;}const value=kind==='string'?decodeConstant(record.get(1),key):kind==='number'?-record.get(1):!record.get(1);
  for(let k=3;k<=record.length();k+=3){const p=record.get(k),pc=record.get(k+1),s=record.get(k+2);if(!ids.has(p))continue;const id=ids.get(p),op=p.get(d.read.opcodeSlot).get(pc),occurrence={prototype:id,pc,slot:s};if(kind!=='string'){const use=literalSlots.get(op),dest=use?.regSlot?p.get(use.regSlot).get(pc):null;if(use?.simple&&use.slots.has(s)&&typeof dest==='number'&&dest>=0&&dest<p.get(d.frame.registerCountSlot)){const list=kind==='number'?protos[id].numbers:protos[id].booleans;const sk=id+':'+kind;if(!seen.has(sk))seen.set(sk,new Map());add(list,seen.get(sk),value,occurrence);}else unresolvedNumbers++;continue;}stringOccurrences++;
   if(!seen.has(id))seen.set(id,new Map());add(protos[id].strings,seen.get(id),value,occurrence);
  }
 }
 // Only direct literal/constant loads are emitted as numeric/boolean constants.
 // Register indices, branch addresses and opaque VM operands are not constants.
 const simple=new Map();for(const h of d.handlers){const nodes=flat(h.body);if(nodes.length!==1||nodes[0].type!=='AssignmentStatement')continue;const n=nodes[0],lhs=n.variables[0];if(lhs?.base?.name!==d.frame.registerArray)continue;const rhs=n.init[0],s=slot(rhs,d);if(s)simple.set(h.opcode,{slot:s,destination:slot(lhs.index,d)});else if(rhs?.type==='BooleanLiteral')simple.set(h.opcode,{literal:rhs.value,destination:slot(lhs.index,d)});}
 for(const p of queue){const out=protos[ids.get(p)],nm=new Map(),bm=new Map();for(const[pc,op]of p.get(d.read.opcodeSlot).values){const spec=simple.get(op);if(!spec?.destination)continue;const destinations=p.get(spec.destination);if(!(destinations instanceof LuaTable))continue;const dest=destinations.get(pc);if(!Number.isInteger(dest)||dest<0||dest>=p.get(d.frame.registerCountSlot))continue;const values=p.get(spec.slot);if(!('literal'in spec)&&!(values instanceof LuaTable))continue;const value='literal'in spec?spec.literal:values.get(pc);if(typeof value==='number'&&Number.isFinite(value))add(out.numbers,nm,value,{pc,slot:spec.slot});if(typeof value==='boolean')add(out.booleans,bm,value,{pc,slot:spec.slot});}}
 return {protos,wrapper_values:[{strings:wrapper}],report:{prototypeCount:protos.length,parsedPrototypeCount:all.length,uniqueStringCount:new Set([...protos.flatMap(p=>p.strings.map(s=>s.value)),...wrapper.map(s=>s.value)]).size,stringOccurrences,unresolvedNumericRecords:unresolvedNumbers,limitations:['Numbers/booleans use the matched deferred-scalar decoder convention and recognized literal operand positions; complex VM operands remain omitted.','Cipher validation uses a unique printable-string solution and bootstrap operands; unsupported/ambiguous variants fail closed.','Unreached prototype data is parsed, not application execution. No complete-coverage certificate.']}};
}
