"""Bounded two-stream LPH ASCII85/raw-LZMA container reader. No Lua execution."""
import json
import re
import sys
from pathlib import Path
from unpack_lzma import unpack_raw, MAX_COMPRESSED

def decode85(text):
    # Bound expansion before allocating; z encodes one four-byte zero word.
    text = text[4:]
    expanded = len(text) + 4 * text.count('z')
    if expanded % 5 or expanded // 5 * 4 > MAX_COMPRESSED:
        raise ValueError('Invalid or oversized ASCII85 stream')
    text = text.replace('z', '!!!!!')
    result = bytearray()
    for pos in range(0, len(text), 5):
        value = 0
        for c in text[pos:pos+5]:
            digit = ord(c)-33
            if not 0 <= digit < 85: raise ValueError('Invalid ASCII85 digit')
            value = value*85+digit
        if value > 0xffffffff: raise ValueError('ASCII85 word overflow')
        result.extend(value.to_bytes(4, 'little'))
    return bytes(result)

def unpack(source, destination):
    if source.stat().st_size > 8*1024*1024: raise ValueError('Input exceeds 8 MiB')
    text = source.read_bytes().decode('latin1')
    streams = [v for _,v in re.findall(r'\[(=*)\[(.*?)\]\1\]', text, re.S) if v.startswith('LPH')]
    if len(streams) != 2: raise ValueError('Expected exactly two LPH streams')
    outputs = [unpack_raw(decode85(s))[0] for s in streams]
    if b'bit32' not in outputs[0] or b'buffer' not in outputs[0]:
        raise ValueError('Unrecognized inner VM loader')
    for name, data in zip(('container-vm.lua', 'container-bytecode.bin'), outputs):
        (destination/name).write_bytes(data)
    return {'container': 'two-stream-ascii85-raw-lzma', 'vmBytes': len(outputs[0]), 'bytecodeBytes': len(outputs[1]), 'executedCode': False}

if __name__ == '__main__':
    print(json.dumps(unpack(Path(sys.argv[1]), Path(sys.argv[2]))))
