// Artifact identity checks prevent accidental mixing; these are not certificates.
import {createHash} from 'node:crypto';
export const digest147=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
