// Lexical routing only: comments and strings cannot impersonate library use.
// Version banners are metadata, never authorization or proof of a version.
export function detectInput(input){
 const source=Buffer.isBuffer(input)?input.toString('latin1'):input;
 if(typeof source!=='string'||source.length>8388608)throw Error('Input exceeds 8 MiB limit');
 const claimedVersion=source.slice(0,1024).match(/Luraph Obfuscator v([0-9.]+)/)?.[1]??null;
 if(/^\s*\[1\] \[string\]/.test(source))return {kind:'numbered-string-inventory',claimedVersion,alreadyDumped:true};
 const ids=new Set(),tokens=[],streams=[];let functions=0,i=0;
 const longAt=p=>/^\[(=*)\[/.exec(source.slice(p,p+64));
 while(i<source.length){
  const c=source[i];if(/\s/.test(c)){i++;continue;}
  if(source.startsWith('--',i)){
   const m=longAt(i+2);if(m){const end=source.indexOf(']'+m[1]+']',i+2+m[0].length);if(end<0)throw Error('Unterminated long comment');i=end+m[1].length+2;}else{const end=source.indexOf('\n',i+2);i=end<0?source.length:end+1;}continue;
  }
  const m=longAt(i);
  if(m){const begin=i+m[0].length,end=source.indexOf(']'+m[1]+']',begin);if(end<0)throw Error('Unterminated long string');const raw=source.slice(begin,end).replace(/^(?:\r\n|\n\r|\r|\n)/,'');if(raw.startsWith('LPH'))streams.push({characters:raw.length});i=end+m[1].length+2;continue;}
  if(c==='"'||c==="'"){const q=c;i++;let closed=false;while(i<source.length){if(source[i]==='\\'){i+=2;continue;}if(source[i++]===q){closed=true;break;}}if(!closed)throw Error('Unterminated quoted string');continue;}
  const id=/^[A-Za-z_][A-Za-z_0-9]*/.exec(source.slice(i,i+512));
  if(id){ids.add(id[0]);tokens.push(id[0]);if(id[0]==='function')functions++;i+=id[0].length;}else{tokens.push(c);i++;}
  if(tokens.length>1000000)throw Error('Lexical detection token budget');
 }
 const features={functionDeclarations:functions,lphStreams:streams.length,bufferIdentifier:ids.has('buffer'),bit32Identifier:ids.has('bit32')};
 if(streams.length===2&&functions>=2)return {kind:'lph-two-stream-container',claimedVersion,features,confidence:'candidate; compressed streams and inner VM must validate'};
 if(ids.has('buffer')&&ids.has('bit32')&&functions>=5)return {kind:'inline-buffer-vm-candidate',claimedVersion,features,confidence:'candidate; VM factory and dispatcher must validate'};
 if(functions===0&&tokens[0]==='return'&&tokens[1]==='{'&&ids.has('strings'))return {kind:'constant-table-input',claimedVersion,alreadyDumped:true,features};
 return {kind:'unknown-or-unsupported',claimedVersion,features,reason:'No reviewed buffer VM or two-stream container structure'};
}
