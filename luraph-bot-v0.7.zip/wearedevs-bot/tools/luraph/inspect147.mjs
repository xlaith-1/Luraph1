// Internal research front-end. NO source certificate, NO execution of Lua.
// Usage: node tools/luraph/inspect147.mjs INPUT.lua OUTPUT_DIRECTORY
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {longLiterals,decodeLPH} from '../../worker/luraph.mjs';
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const input=process.argv[2],out=process.argv[3];
if(!input||!out)throw Error('Supply input and a NEW output directory');
if(fs.statSync(input).size>2*1024*1024)throw Error('Research input exceeds 2 MiB');
// Refuse reuse: never leave stale files from a different input in a result dir.
fs.mkdirSync(out);
const bytes=fs.readFileSync(input),source=bytes.toString('latin1');
const report={status:'analysis-only',fullRecoveryVerified:false,executedUploadedCode:false,inputSha256:sha(bytes),inputBytes:bytes.length,
  version:/^--[^\r\n]*Luraph Obfuscator v([\d.]+)/.exec(source)?.[1]??null,layers:[],errors:[],limitations:['Unpacked VM code is NOT readable application source.','No bootstrap execution, VM lifting or payload equivalence approval is performed by this research tool.']};
try{
 if(report.version!=='14.7')throw Error('Expected v14.7 header (header alone is not proof of compatibility)');
 const literals=longLiterals(source).filter(x=>x.startsWith('LPH'));
 if(!literals.length||literals.length>8)throw Error('Unsupported number of candidate LPH literals');
 for(const [i,text] of literals.entries()){
  // Observed base85 transport has variable fourth marker byte. Same arithmetic,
  // not a claim that the v14.8 serializer/VM schema applies to this payload.
  const data=decodeLPH('LPH!'+text.slice(4),8*1024*1024),file=path.resolve(out,`layer-${i}.bin`);
  fs.writeFileSync(file,data);
  const layer={index:i,marker:text.slice(0,4),transport:'base85-le',bytes:data.length,sha256:sha(data),compressedCandidate:data[0]===0};
  if(layer.compressedCandidate){
   const dest=path.resolve(out,`layer-${i}.unpacked`);
   try{
    const tool=fileURLToPath(new URL('./unpack_lzma.py',import.meta.url));
    const result=JSON.parse(execFileSync('python',[tool,file,dest],{encoding:'utf8',timeout:15000,maxBuffer:65536}));
    layer.unpack=result;
    const content=fs.readFileSync(dest);
    layer.contentHint=/^local\s+[A-Za-z_]\w*\s*=\s*\.\.\.\s*;\s*return\s*\(/.test(content.subarray(0,300).toString('latin1'))?'inner-vm-source':'binary-data';
   }catch(e){layer.unpack={ok:false,error:e.stdout?String(e.stdout).trim():'Bounded decompressor failed'};}
  }
  report.layers.push(layer);
 }
}catch(e){report.errors.push(e.message);}
fs.writeFileSync(path.join(out,'analysis.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
