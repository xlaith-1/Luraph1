# Structural capture integration — experimental, not a source decompiler

`instrument147.mjs` connects raw-source structural discovery to the recorder and
status-checked versioned evidence importer. It does not recover application Lua,
unpack protected input, choose an application entry point, or deploy bot changes.

## Offline preparation

```sh
node tools/luraph/instrument147-cli.mjs raw-interpreter.lua NEW-directory
```

This command **does not execute Lua**. It writes an instrumented module and a
capture-plan JSON file. It refuses an existing output directory. Input is limited
to 2 MiB, the prepared source to 32 MiB, and accepted frame sites to 64.
Use raw, byte-preserved source, not `normalize_for_analysis.py` output.
The parser supports a Lua 5.3 syntax subset; unsupported Luau syntax is rejected.

Discovery resolves lexical identifiers and requires a numeric comparison
 dispatcher, a local/captured PC, and a stable opcode-array alias originating in
an indexed factory parameter. Names and prototype slot numbers are discovered,
not fixed to the development sample. Multiple candidate loops in one function
are rejected. This is structural evidence, not proof that a function is a VM.

Patches only insert code at original source boundaries. A recorder upvalue avoids
publishing hooks as globals. Parenthesized returns, multiple return values, nil
positions, and original top-level varargs are retained in the tested cases.
Tail-call/debug/stack behavior changes; equivalence is not certified.

## Trusted harness API

The generated module evaluates to `function(recorder) -> originalChunkWrapper`.
An isolated trusted harness may load it and supply a recorder created using
`trace147-recorder.lua`. Invoke the returned chunk with its original arguments.
Its return value is whatever the original chunk returns; do not assume it is an
application entry point. Calling an arbitrary returned closure is **not** safe
boundary discovery. The caller remains responsible for OS isolation, no network
or credentials, runtime/CPU/memory limits, and error/timeout checkpointing.

Additional recorder methods used by generated hooks:

- `enterPrototype(siteId, object)` assigns a site-and-reference frame identity.
  Prototype tables remain opaque references in operands; this does not infer
  child-prototype relationships or retroactively reclassify earlier references.
- `checkCodeArray(array)` rejects non-table or metatable-backed opcode arrays
  before the original indexed opcode read.
- `stepArrays(frame, pc, opcode, arrayMap)` captures raw indexed operand values
  from plain tables, including explicit nil. Inaccessible or reassigned aliases
  are not inferred. This is an opcode-boundary snapshot, not proof of later reads.
- `returns(frame, ...)` exits a frame and forwards all original return positions.

Main-thread and coroutine identities are tracked separately. As with the original
recorder, caught exceptions in instrumented children can leave stale frame stacks;
subsequent inconsistent events fail closed. Uncaught errors can leave incomplete
frames. Uninstrumented functions remain invisible. Neither partial chronology nor
valid JSON establishes complete control flow. Recorder instrumentation is not a
security boundary against a hostile input deliberately interfering with it.

Always persist both emitted `events.jsonl` and the JSON returned by `finish()`.
Then use `trace147-cli.mjs` with `producerStatus` in the manifest. If a process
is killed before status is written, do not silently import its prefix as a normal
successful recording.

## Actual validation

- 20 integration tests; full Node suite **202 passed, zero skipped**.
- Lua 5.4 and LuaJIT run synthetic originals and structurally instrumented copies,
  then import captured events with the producer-status check.
- Three renamed/reindexed layouts; self-modification retains multiple versions;
  nested calls produce resume edges; two yielding coroutines remain separate;
  parenthesized/binary/multiple/nil returns are checked.
- Operand and opcode metatables fail closed without invoking their `__index`
  methods through the added capture hooks. Their baselines are checked separately.
- A saved development interpreter was statically recognized at 26 frame sites
  and its generated module compiled with LuaJIT. This did **not** execute the
  protected interpreter and is **not** evidence of application recovery.

Not completed: general unpack/runtime integration, safe automatic application
boundary selection, version-aware semantic CFG/lifting, readable application
reconstruction, production worker integration, or holdout validation.
