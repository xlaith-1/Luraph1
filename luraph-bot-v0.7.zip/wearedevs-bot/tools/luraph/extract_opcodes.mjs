import fs from 'node:fs';import {body,constant,fold,walk} from '../../worker/lua.mjs';
const ast=JSON.parse(fs.readFileSync(process.argv[2]));let handler;
walk(ast,n=>{if(n.type==='RepeatStatement'&&n.body[0]?.type==='LocalStatement'&&n.body[0].variables[0]?.name==='D')handler=n.body[1];});
function prune(nodes){return nodes.flatMap(n=>{
 if(n.type==='IfStatement'){
  const clauses=[];
  for(const c of n.clauses){const k=c.condition?constant(c.condition):{ok:true,value:true};if(k.ok){if(k.value!==false&&k.value!==null){if(!clauses.length)return prune(c.body);clauses.push({type:'ElseClause',body:prune(c.body)});break;}}else clauses.push({...c,body:prune(c.body)});}
  return clauses.length?[{...n,clauses}]:[];
 }
 for(const [k,v]of Object.entries(n)){if(k==='body'&&Array.isArray(v))n[k]=prune(v);}
 return [n];
});}
const out=[];
for(let op=0;op<=160;op++){
 const n=structuredClone(handler);walk(n,x=>{if(x.type==='Identifier'&&x.name==='D'){for(const k of Object.keys(x))delete x[k];Object.assign(x,{type:'NumericLiteral',value:op,raw:String(op)});}});fold(n);
 const nodes=prune([n]);out.push({opcode:op,body:nodes,source:body(nodes)});
}
fs.writeFileSync(process.argv[3],JSON.stringify(out,null,2));
for(const i of [10,29,64,82,96,154,156])console.log('\nOPCODE',i,'\n',out[i].source);
