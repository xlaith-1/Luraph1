import {digest147} from './provenance147.mjs';
// Typed, non-executing instruction IR. This preserves VM effects, lexical
// bindings and mutable operand reads. It is NOT recovered application source.
function children(n,fn){for(const [k,v]of Object.entries(n)){if(['range','comments'].includes(k))continue;if(Array.isArray(v))v.forEach(x=>{if(x&&typeof x==='object')fn(x)});else if(v&&typeof v==='object')fn(v);}}
class Bindings {
 constructor(parent=null){this.parent=parent;this.names=new Map();}
 get(name){return this.names.get(name)??this.parent?.get(name);}
 set(name,value){this.names.set(name,value);}
}
export class InstructionLowerer {
 constructor(description,selectedFrame,{frameMode=false}={}){
  if(!description.read||!description.frame||!description.iteration)throw Error('Incomplete frame/iteration description');
  this.d=description;this.unmodeledPreambleEffects=false;this.counter=0;this.symbols=[];this.warnings=new Set();this.root=new Bindings();
  for(const [name,slot]of Object.entries(description.slotAliases))this.bind(this.root,name,{role:'prototype-slot',slot});
  this.frameMode=frameMode;this.dispatchBoundaries=[];this.dispatchContexts=[];
  if(frameMode)return;
  this.context=this.findContext(selectedFrame);
  if(!this.context)throw Error('Unique dispatcher lexical context was not found');
  for(let e=this.context;e;e=e.parent)for(const symbol of e.names.values())Object.assign(this.symbols.find(x=>x.id===symbol.id),symbol);
  this.pcSymbol=this.reference(this.context,description.read.programCounter);this.pcSymbol.role='pc';
 }
 bind(env,name,extra={}){const symbol={id:++this.counter,name,role:'temporary',...extra};env.set(name,symbol);this.symbols.push(symbol);return symbol;}
 reference(env,name){return env.get(name)??this.bind(this.root,name,{role:'captured-unknown'});}
 isLoop(n){return ['RepeatStatement','WhileStatement'].includes(n.type)&&n.body.some(s=>['LocalStatement','AssignmentStatement'].includes(s.type)&&s.variables.some((v,i)=>v.name===this.d.opcodeVariable&&s.init[i]?.type==='IndexExpression'&&s.init[i].base.name===this.d.read.opcodeArray&&s.init[i].index.name===this.d.read.programCounter));}
 findContext(frame){
  const found=[];
  const snapshot=env=>{
   if(!env)return null;
   const copy=new Bindings(snapshot(env.parent));
   for(const [name,symbol]of env.names)copy.set(name,{...symbol});
   return copy;
  };
  const enterFunction=(node,parent,main=false)=>{
   const env=new Bindings(parent);for(const p of node.parameters)if(p.type==='Identifier')this.bind(env,p.name);
   scan(node.body,env,main);
  };
  const scan=(nodes,parent,main=false)=>{
   const env=new Bindings(parent);
   const invalidateSeeds=()=>{for(let e=env;e;e=e.parent)for(const symbol of e.names.values())if(symbol.initialSeed)symbol.initialSeed={known:false};};
   for(const n of nodes){
    if(this.isLoop(n)){found.push(snapshot(env));continue;}
    if(!['LocalStatement','FunctionDeclaration'].includes(n.type)){this.unmodeledPreambleEffects=true;invalidateSeeds();}
    if(n.type==='FunctionDeclaration'){if(n.identifier)this.bind(env,n.identifier.name);enterFunction(n,env);continue;}
    // Initializers use the old lexical environment, before new locals shadow it.
    const visit=x=>{if(x.type==='FunctionDeclaration'){enterFunction(x,env);return;}children(x,visit);};
    if(n.type==='LocalStatement'){
     // Calls, indexing/metamethods and other nonliteral initialization can
     // invalidate preceding captured cells. Do not invent their effects.
     if(n.init.some(x=>!['NumericLiteral','StringLiteral','BooleanLiteral','NilLiteral','Identifier','FunctionDeclaration'].includes(x.type)&&!(x.type==='TableConstructorExpression'&&x.fields.length===0))){this.unmodeledPreambleEffects=true;invalidateSeeds();}
     n.init.forEach(visit);
     n.variables.forEach((v,i)=>{
      const role=v.name===this.d.frame.registerArray&&main&&n===frame.body[0]?{role:'register-file'}:v.name===this.d.read.programCounter?{role:'pc'}:{};
      const init=n.init[i],last=n.init.at(-1),mayExpand=last&&['CallExpression','TableCallExpression','StringCallExpression','VarargLiteral'].includes(last.type)&&!last.inParens;
      const seed=init&&['NumericLiteral','StringLiteral','BooleanLiteral','NilLiteral'].includes(init.type)?{known:true,value:init.type==='NilLiteral'?null:init.value}:!init&&!mayExpand?{known:true,value:null}:{known:false};
      this.bind(env,v.name,{...role,initialSeed:seed});
     });
    }else if(n.type==='IfStatement'){
     for(const c of n.clauses){if(c.condition)visit(c.condition);scan(c.body,env,false);}
    }else if(n.type==='DoStatement')scan(n.body,env,false);
    else children(n,visit);
   }
  };
  enterFunction(frame,this.root,true);
  return found.length===1?found[0]:null;
 }
 expr(n,env){
  const x=this.exprRaw(n,env);
  return n.inParens&&['call','varargs'].includes(x.kind)?{kind:'single-result',value:x}:x;
 }
 exprRaw(n,env){
  const e=x=>this.expr(x,env);
  switch(n.type){
   case 'NumericLiteral':case 'StringLiteral':case 'BooleanLiteral':return {kind:'literal',value:n.value};
   case 'NilLiteral':return {kind:'literal',value:null};
   case 'Identifier':return {kind:'symbol',symbol:this.reference(env,n.name)};
   case 'VarargLiteral':return {kind:'varargs'};
   case 'UnaryExpression':return {kind:'unary',operator:n.operator,value:e(n.argument)};
   case 'BinaryExpression':case 'LogicalExpression':return {kind:n.type==='LogicalExpression'?'logical':'binary',operator:n.operator,left:e(n.left),right:e(n.right)};
   case 'MemberExpression':case 'IndexExpression':{
    const base=e(n.base),index=n.type==='MemberExpression'?{kind:'literal',value:n.identifier.name}:e(n.index);
    if(base.kind==='symbol'&&base.symbol.role==='prototype-slot')return {kind:'operand-read',slot:base.symbol.slot,baseSymbol:base.symbol,index};
    if(base.kind==='symbol'&&base.symbol.role==='register-file')return {kind:'register-read',baseSymbol:base.symbol,index};
    return {kind:'index',base,index};
   }
   case 'CallExpression':case 'TableCallExpression':case 'StringCallExpression':{
    const args=n.type==='CallExpression'?n.arguments.map(e):[e(n.type==='TableCallExpression'?n.arguments:n.argument)];
    if(n.base.type==='MemberExpression'&&n.base.indexer===':')return {kind:'call',method:true,receiver:e(n.base.base),methodName:n.base.identifier.name,args};
    return {kind:'call',method:false,callee:e(n.base),args};
   }
   case 'TableConstructorExpression':return {kind:'table',fields:n.fields.map(f=>f.type==='TableValue'?{array:true,value:e(f.value)}:{array:false,key:f.type==='TableKeyString'?{kind:'literal',value:f.key.name}:e(f.key),value:e(f.value)})};
   case 'FunctionDeclaration':{
    const inner=new Bindings(env),parameters=n.parameters.map(p=>p.type==='VarargLiteral'?{varargs:true}:this.bind(inner,p.name));
    return {kind:'closure',parameters,body:this.block(n.body,inner),requiresInterproceduralRecovery:true};
   }
   default:throw Error('Unlowered expression '+n.type);
  }
 }
 target(n,env){const result=this.exprRaw(n,env);if(!['symbol','index','operand-read','register-read'].includes(result.kind))throw Error('Invalid IR assignment target');return result;}
 block(nodes,parent,reuse=false){
  const env=reuse?parent:new Bindings(parent),out=[];
  for(const n of nodes){const e=x=>this.expr(x,env),b=x=>this.block(x,env);
   if(this.frameMode&&this.isLoop(n)){
    const boundary={kind:'vm-dispatch-boundary',loopType:n.type,
     pcSymbol:this.reference(env,this.d.read.programCounter),
     opcodeArraySymbol:this.reference(env,this.d.read.opcodeArray),
     registerSymbol:this.reference(env,this.d.frame.registerArray),
     condition:e(n.condition),requiresInstructionModel:true};
    const snapshot=scope=>{if(!scope)return null;const copy=new Bindings(snapshot(scope.parent));for(const [name,symbol]of scope.names)copy.set(name,symbol);return copy;};
    this.dispatchContexts.push(snapshot(env));
    this.dispatchBoundaries.push(boundary);out.push(boundary);continue;
   }
   switch(n.type){
    case 'LocalStatement':{const values=n.init.map(e),targets=n.variables.map(v=>this.bind(env,v.name));out.push({kind:'local',targets,values,resultAdjustment:'Lua expression list'});break;}
    case 'AssignmentStatement':out.push({kind:'assign',targets:n.variables.map(v=>this.target(v,env)),values:n.init.map(e),evaluationOrder:'targets, values, stores',resultAdjustment:'Lua expression list'});break;
    case 'CompoundAssignmentStatement':out.push({kind:'compound',target:this.target(n.variable,env),operator:n.operator,value:e(n.value),singleTargetEvaluation:true});break;
    case 'CallStatement':if(n.expression.base.type==='Identifier'&&n.expression.base.name==='__analysis_continue')out.push({kind:'continue'});else out.push({kind:'call-statement',call:e(n.expression)});break;
    case 'ReturnStatement':out.push({kind:'return',values:n.arguments.map(e),resultAdjustment:'Lua expression list'});break;
    case 'BreakStatement':out.push({kind:'break'});break;
    case 'DoStatement':out.push({kind:'scope',body:b(n.body)});break;
    case 'IfStatement':out.push({kind:'if',clauses:n.clauses.map(c=>({condition:c.condition?e(c.condition):null,body:b(c.body)}))});break;
    case 'ForNumericStatement':{
     const start=e(n.start),end=e(n.end),step=n.step?e(n.step):{kind:'literal',value:1};const inner=new Bindings(env),variable=this.bind(inner,n.variable.name);
     out.push({kind:'numeric-for',variable,start,end,step,body:this.block(n.body,inner)});break;
    }
    case 'ForGenericStatement':{
     const iterators=n.iterators.map(e),inner=new Bindings(env),variables=n.variables.map(v=>this.bind(inner,v.name));
     out.push({kind:'generic-for',variables,iterators,body:this.block(n.body,inner)});break;
    }
    case 'WhileStatement':out.push({kind:'while',condition:e(n.condition),body:b(n.body)});break;
    case 'RepeatStatement':{
     const inner=new Bindings(env),body=this.block(n.body,inner,true);out.push({kind:'repeat',body,condition:this.expr(n.condition,inner)});break;
    }
    case 'FunctionDeclaration':{
     if(n.isLocal){const symbol=this.bind(env,n.identifier.name);out.push({kind:'assign',declaration:true,targets:[{kind:'symbol',symbol}],values:[e(n)]});}
     else out.push({kind:'assign',targets:[this.target(n.identifier,env)],values:[e(n)]});break;
    }
    default:throw Error('Unlowered statement '+n.type);
   }
  }
  return out;
 }
 lower(handlers){
  const simpleOpcodeFetch=handlers.every(h=>{
   const n=h.iterationBody?.[0],x=n?.init?.[0];return ['LocalStatement','AssignmentStatement'].includes(n?.type)&&n.variables.length===1&&n.init.length===1&&n.variables[0].name===this.d.opcodeVariable&&x.type==='IndexExpression'&&x.base.name===this.d.read.opcodeArray&&x.index.name===this.d.read.programCounter;
  });
  if(!simpleOpcodeFetch)this.warnings.add('Nontrivial opcode-fetch prefix requires further lowering');
  const instructions=handlers.map(h=>{if(!h.iterationBody)throw Error('Missing whole-iteration AST');return {opcode:h.opcode,body:this.block(h.iterationBody,this.context)};});
  return {schema:1,kind:'vm-instruction-ir',fullRecoveryVerified:false,simpleOpcodeFetch,unmodeledPreambleEffects:this.unmodeledPreambleEffects,entryPc:this.pcSymbol.initialSeed?.known&&Number.isSafeInteger(this.pcSymbol.initialSeed.value)?this.pcSymbol.initialSeed.value:null,instructions,symbols:this.symbols,warnings:[...this.warnings],limitations:['Operand reads remain mutable; decoded values are not substituted as immutable literals.','Calls and closure bodies are represented, never invoked.','Instruction lowering alone does not recover application source.']};
 }
}


// Whole frame setup/continuation IR uses ordinary lexical lowering, not guessed
// preamble seeds. Dispatch loops are explicit holes, never executed or certified.
export function lowerFrame147(description,frame,{includeInstructions=false}={}){
 const engine=new InstructionLowerer(description,frame,{frameMode:true});
 const root=engine.expr(frame,engine.root);
 // Dependencies are symbol identities, not name matches. Nested closures retain
 // references to outer cells; no captured value or invocation is assumed here.
 const annotate=closure=>{
  const declared=new Set(closure.parameters.filter(p=>!p.varargs).map(p=>p.id)),used=new Map();let complete=true;
  const use=s=>{if(s?.id)used.set(s.id,s);};
  const visit=n=>{
   if(!n||typeof n!=='object')return;
   if(n.kind==='closure'){annotate(n);if(!n.captureSymbolsComplete)complete=false;n.captureSymbols.forEach(use);return;}
   if(n.kind==='local')n.targets.forEach(s=>declared.add(s.id));
   if(n.kind==='assign'&&n.declaration)n.targets.forEach(t=>declared.add(t.symbol.id));
   if(n.kind==='numeric-for')declared.add(n.variable.id);
   if(n.kind==='generic-for')n.variables.forEach(s=>declared.add(s.id));
   if(n.kind==='symbol')use(n.symbol);
   if(n.baseSymbol)use(n.baseSymbol);
   if(n.kind==='vm-dispatch-boundary'){complete=false;use(n.pcSymbol);use(n.opcodeArraySymbol);use(n.registerSymbol);}
   for(const value of Object.values(n))if(Array.isArray(value))value.forEach(visit);else if(value&&typeof value==='object')visit(value);
  };
  closure.body.forEach(visit);
  closure.captureSymbols=[...used.values()].filter(s=>!declared.has(s.id));
  closure.captureSymbolsComplete=complete;
 };
 annotate(root);
 if(engine.dispatchBoundaries.length!==1)throw Error('Expected one lexical frame dispatcher boundary');
 let instructionIR,symbolNamespace;
 if(includeInstructions){
  engine.context=engine.dispatchContexts[0];engine.frameMode=false;
  engine.pcSymbol=engine.dispatchBoundaries[0].pcSymbol;engine.pcSymbol.role='pc';
  engine.dispatchBoundaries[0].registerSymbol.role='register-file';
  engine.unmodeledPreambleEffects=true; // Only an explicit state bridge may enter.
  instructionIR=engine.lower(description.handlers);
  symbolNamespace=digest147({version:'linked147-state-v1',frame,read:description.read,slots:description.slotAliases,frameDescription:description.frame,handlers:description.handlers});
  instructionIR.symbolNamespace=symbolNamespace;
 }
 return {schema:1,kind:'vm-frame-setup-ir',fullRecoveryVerified:false,programCallsExecuted:false,
  frame:root,symbols:engine.symbols,dispatchBoundaries:engine.dispatchBoundaries,...(instructionIR?{instructionIR,symbolNamespace,sharedSymbolNamespace:true}:{}),
  limitations:['Dispatcher bodies are explicit holes, not recovered code; capture sets crossing those holes are incomplete.',
   'Calls, argument packing, environment reads and protected-call effects remain unmodeled.',
   'This representation does not authorize fresh-entry tracing or certify application source.']};
}
