-- Portable capture-event recorder (Lua 5.1+/LuaJIT; no filesystem or VM discovery).
-- Load in the trusted harness. Supply a bounded sink; do not expose to input code.
local type, next, rawget, select, pcall, error = type, next, rawget, select, pcall, error
local rawequal, ipairs = rawequal, ipairs
local mathType = math.type
local getmetatable = getmetatable
local running = coroutine and coroutine.running
local unpack = table.unpack or unpack
local byte, format, concat, sort = string.byte, string.format, table.concat, table.sort
local sub, find = string.sub, string.find
local huge = math.huge
local function pack(...) return { n = select('#', ...), ... } end
local function quote(s)
    local parts = {'"'}
    for i = 1, #s do
        local b = byte(s, i)
        if b == 34 then parts[#parts+1] = '\\"'
        elseif b == 92 then parts[#parts+1] = '\\\\'
        elseif b >= 32 and b < 127 then parts[#parts+1] = sub(s,i,i)
        else parts[#parts+1] = format('\\u%04x', b) end
    end
    parts[#parts+1] = '"'
    return concat(parts)
end
local function natural(n)
    return type(n) == 'number' and n >= 0 and n <= 9007199254740991 and n % 1 == 0
end
local function identifier(s)
    return type(s) == 'string' and #s > 0 and #s <= 128 and not find(s,'[^A-Za-z0-9_%.:/%-]')
end
local function number(n) return format('%.17g', n) end
local function object(fields)
    local keys, parts = {}, {}
    for k in next, fields do keys[#keys+1] = k end
    sort(keys)
    for _,k in ipairs(keys) do parts[#parts+1] = quote(k)..':'..fields[k] end
    return '{'..concat(parts,',')..'}'
end
local NIL = {}
local M = {NIL=NIL}
function M.new(options)
    if type(options)~='table' or not identifier(options.sessionId) or type(options.emit)~='function' then error('Invalid recorder configuration',2) end
    local session, sink = options.sessionId, options.emit
    local limits = {maxEvents=1000000,maxBytes=16777216,maxEventBytes=65536,maxFrames=100000,maxReferences=100000,maxStringBytes=16384,maxOperands=256,maxDepth=256,maxThreads=1024}
    for k,v in next, limits do
        if options[k]~=nil then v=options[k] end
        if not natural(v) or v<1 then error('Invalid recorder limit',2) end
        limits[k]=v
    end
    local seq, bytes, frameCount, refCount, threadCount = 0,0,0,0,0
    local failed, closed, writing = nil,false,false
    local stacks, frames, prototypes, references, observedReferences = {},{},{},{},{}
    local recorder = {}
    local function fail(reason) failed=reason;error(reason,0) end
    local function active()
        if failed or closed then error('Recorder closed or failed',0) end
        if writing then fail('Reentrant event sink') end
    end
    local function validId(value) if not identifier(value) then fail('Invalid recorder identifier') end;return value end
    local function stack(thread)
        validId(thread)
        if not stacks[thread] then
            if threadCount>=limits.maxThreads then fail('Thread limit') end
            stacks[thread]={};threadCount=threadCount+1
        end
        return stacks[thread]
    end
    local function emit(fields)
        active()
        if seq>=limits.maxEvents then fail('Event limit') end
        fields.sessionId=quote(session);fields.seq=number(seq)
        local line=object(fields)..'\n'
        if #line>limits.maxEventBytes or bytes+#line>limits.maxBytes then fail('Event byte limit') end
        writing=true
        local ok=pcall(sink,line)
        writing=false
        if not ok or failed then fail('Event sink failed') end
        seq=seq+1;bytes=bytes+#line
    end
    local function value(v)
        local kind=type(v)
        if kind=='nil' or rawequal(v,NIL) then return '{"type":"nil"}' end
        if kind=='boolean' then return '{"type":"boolean","value":'..(v and 'true' or 'false')..'}' end
        if kind=='number' then
            if mathType and mathType(v)=='integer' and (v>9007199254740991 or v< -9007199254740991) then
                return '{"type":"integer64","decimal":'..quote(format('%d',v))..'}'
            end
            local text
            if v~=v then text='"nan"' elseif v==huge then text='"inf"' elseif v==-huge then text='"-inf"'
            elseif v==0 and 1/v==-huge then text='"-0"' else text=number(v) end
            return '{"type":"number","value":'..text..'}'
        end
        if kind=='string' then
            if #v>limits.maxStringBytes then fail('String byte limit') end
            local hex={};for i=1,#v do hex[i]=format('%02x',byte(v,i)) end
            return '{"type":"bytes","hex":'..quote(concat(hex))..'}'
        end
        local proto=prototypes[v]
        if proto then return '{"type":"prototype","id":'..quote(proto)..'}' end
        observedReferences[v]=true
        local ref=references[v]
        if not ref then
            if refCount>=limits.maxReferences then fail('Reference limit') end
            refCount=refCount+1;ref='r'..number(refCount);references[v]=ref
        end
        -- Never traverse a target object or invoke tostring/__pairs/__index.
        return '{"type":"reference","kind":'..quote(kind)..',"id":'..quote(ref)..'}'
    end
    function recorder:registerPrototype(target, prototypeId)
        active();validId(prototypeId)
        if type(target)~='table' then fail('Prototype must be a table') end
        if prototypes[target] and prototypes[target]~=prototypeId then fail('Prototype identity changed') end
        if observedReferences[target] and not prototypes[target] then fail('Late prototype registration') end
        -- Share the reference bound, including registered prototype identities.
        if not references[target] then value(target) end
        prototypes[target]=prototypeId
    end
    function recorder:enterPrototype(siteId,target)
        active();validId(siteId)
        if type(target)~='table' then fail('Prototype object unavailable') end
        value(target)
        local thread,isMain
        if running then thread,isMain=running() end
        local threadId='main'
        if thread and not isMain then value(thread);threadId='thread-'..references[thread] end
        return self:enter(threadId,siteId..':'..references[target])
    end
    function recorder:checkCodeArray(array)
        active()
        if type(array)~='table' or getmetatable(array)~=nil then fail('Opcode array is not a plain table') end
    end
    function recorder:stepArrays(handle,pc,opcode,arrays)
        active()
        if type(arrays)~='table' then fail('Operand array map required') end
        local operands={}
        for key,array in next,arrays do
            if type(array)~='table' or getmetatable(array)~=nil then fail('Operand array is not a plain table') end
            local v=rawget(array,pc);operands[key]=v==nil and NIL or v
        end
        return self:step(handle,pc,opcode,operands)
    end
    function recorder:returns(handle,...)
        self:exit(handle)
        return ...
    end
    function recorder:enter(threadId,prototypeId)
        active();validId(prototypeId);local s=stack(threadId)
        if frameCount>=limits.maxFrames or #s>=limits.maxDepth then fail('Frame limit') end
        local handle={};local id='f'..number(frameCount+1);local parent=s[#s]
        emit({kind=quote('enter'),threadId=quote(threadId),frameId=quote(id),prototypeId=quote(prototypeId),parentFrameId=parent and quote(frames[parent].id) or 'null'})
        frameCount=frameCount+1;frames[handle]={id=id,thread=threadId,prototype=prototypeId};s[#s+1]=handle
        return handle
    end
    function recorder:current(threadId)
        active();local s=stack(threadId);return s[#s]
    end
    local function currentFrame(handle)
        local f=frames[handle]
        if not f or stacks[f.thread][#stacks[f.thread]]~=handle then fail('Not the active frame') end
        return f
    end
    function recorder:step(handle,pc,opcode,operands)
        active();local f=currentFrame(handle)
        if not natural(pc) or not natural(opcode) or type(operands)~='table' then fail('Invalid instruction event') end
        local fields,count={},0
        for k in next, operands do
            count=count+1;if count>limits.maxOperands then fail('Operand count limit') end
            validId(k);fields[k]=value(rawget(operands,k))
        end
        emit({kind=quote('step'),threadId=quote(f.thread),frameId=quote(f.id),prototypeId=quote(f.prototype),pc=number(pc),opcode=number(opcode),operands=object(fields)})
    end
    function recorder:exit(handle,status)
        active();local f=currentFrame(handle)
        if status and status~='return' and status~='error' then fail('Invalid frame status') end
        emit({kind=quote('exit'),threadId=quote(f.thread),frameId=quote(f.id),status=quote(status or 'return')})
        local s=stacks[f.thread];s[#s]=nil;frames[handle]=nil
    end
    function recorder:gap(threadId)
        active();stack(threadId);emit({kind=quote('gap'),threadId=quote(threadId)})
    end
    function recorder:withFrame(threadId,prototypeId,fn,...)
        if type(fn)~='function' then fail('Expected instrumented function') end
        local handle=self:enter(threadId,prototypeId)
        local results=pack(pcall(fn,...))
        if not failed then self:exit(handle,results[1] and 'return' or 'error') end
        if not results[1] then error(results[2],0) end
        if failed then error(failed,0) end
        return unpack(results,2,results.n)
    end
    function recorder:finish(reason)
        if writing then fail('Reentrant event sink') end
        reason=reason or 'producer-ended';validId(reason)
        closed=true
        local incomplete=0;for _ in next, frames do incomplete=incomplete+1 end
        local result={sessionId=session,events=seq,bytes=bytes,frames=frameCount,references=refCount,incompleteFrames=incomplete,valid=failed==nil,error=failed,stopReason=reason}
        local encoded=object({sessionId=quote(session),events=number(seq),bytes=number(bytes),frames=number(frameCount),references=number(refCount),incompleteFrames=number(incomplete),valid=failed and 'false' or 'true',error=failed and quote(failed) or 'null',stopReason=quote(reason)})
        return result, encoded..'\n'
    end
    return recorder
end
return M
