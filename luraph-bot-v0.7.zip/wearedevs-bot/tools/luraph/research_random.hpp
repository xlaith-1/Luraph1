// Offline experimental PCG model. Not certified Roblox equivalence.
#include <cstdint>
#include <cmath>
struct ResearchRandom { uint64_t state; };
static uint32_t randomWord(ResearchRandom* r){uint64_t old=r->state;r->state=old*6364136223846793005ULL+105;uint32_t x=uint32_t(((old>>18)^old)>>27),rot=old>>59;return (x>>rot)|(x<<((-int32_t(rot))&31));}
static ResearchRandom* checkRandom(lua_State* L){luaL_checktype(L,1,LUA_TUSERDATA);if(lua_userdatatag(L,1)!=1)luaL_argerror(L,1,"Random expected");return (ResearchRandom*)lua_touserdata(L,1);}
static double randomReal(ResearchRandom* r){uint32_t lo=randomWord(r),hi=randomWord(r);return std::ldexp(double(lo|(uint64_t(hi)<<32)),-64);}
static void pushRandom(lua_State* L,uint64_t state){auto* r=(ResearchRandom*)lua_newuserdatatagged(L,sizeof(ResearchRandom),1);r->state=state;lua_getfield(L,LUA_REGISTRYINDEX,"researchRandomMetatable");lua_setmetatable(L,-2);}
static int randomNew(lua_State* L){double seed=luaL_optnumber(L,1,0);if(!std::isfinite(seed)||std::abs(seed)>9007199254740991.0)luaL_argerror(L,1,"seed out of research range");ResearchRandom r{0};randomWord(&r);r.state+=uint64_t(int64_t(seed));randomWord(&r);pushRandom(L,r.state);return 1;}
static int randomNextNumber(lua_State* L){auto* r=checkRandom(L);double a=luaL_optnumber(L,2,0),b=luaL_optnumber(L,3,1);luaL_argcheck(L,a<=b,3,"empty interval");lua_pushnumber(L,a+(b-a)*randomReal(r));return 1;}
static int randomNextInteger(lua_State* L){auto* r=checkRandom(L);int a=luaL_checkinteger(L,2),b=luaL_checkinteger(L,3);luaL_argcheck(L,a<=b,3,"empty interval");uint64_t span=uint64_t(int64_t(b)-int64_t(a))+1;lua_pushnumber(L,double(int64_t(a)+int64_t((span*randomWord(r))>>32)));return 1;}
static int randomClone(lua_State* L){auto* r=checkRandom(L);pushRandom(L,r->state);return 1;}
static int randomUnitVector(lua_State* L){checkRandom(L);luaL_error(L,"UNIMPLEMENTED_RESEARCH_API:Random.NextUnitVector");}
static int randomShuffle(lua_State* L){checkRandom(L);luaL_error(L,"UNIMPLEMENTED_RESEARCH_API:Random.Shuffle");}
static void registerRandom(lua_State* L){lua_newtable(L);lua_pushstring(L,"Random");lua_setfield(L,-2,"__type");lua_pushstring(L,"The metatable is locked");lua_setfield(L,-2,"__metatable");lua_newtable(L);
#define R_METHOD(fn,name) lua_pushcfunction(L,fn,name);lua_setfield(L,-2,name)
R_METHOD(randomNextNumber,"NextNumber");R_METHOD(randomNextInteger,"NextInteger");R_METHOD(randomClone,"Clone");R_METHOD(randomUnitVector,"NextUnitVector");R_METHOD(randomShuffle,"Shuffle");
#undef R_METHOD
lua_setfield(L,-2,"__index");lua_setfield(L,LUA_REGISTRYINDEX,"researchRandomMetatable");lua_pushcfunction(L,randomNew,"new");lua_setglobal(L,"__research_random_new");}
