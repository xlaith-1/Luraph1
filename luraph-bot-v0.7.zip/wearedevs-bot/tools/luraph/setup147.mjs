import {digest147} from './provenance147.mjs';
// Abstract straight-line frame setup. No native or uploaded callback executes.
import {analyzeHelper147} from './helper147.mjs';
const U=reason=>({kind:'unknown',reason});
class Frontier extends Error{}
export function analyzeSetup147(graph,bindings,helpers,frameIR,{args=null,maxOperations=2000}={}){
 if(!Number.isInteger(maxOperations)||maxOperations<1||maxOperations>100000)throw Error('Setup operation limit');
 if(args!==null&&(!Array.isArray(args)||args.length>1024||args.some(x=>x!==null&&!['number','string','boolean'].includes(typeof x)||typeof x==='number'&&!Number.isFinite(x))))throw Error('Setup arguments must be finite scalars');
 const tables=new Map(graph.tables.map(t=>[t.id,new Map(t.entries)]));
 const captured=new Map(bindings.bindings.filter(b=>b.resolved).map(b=>[b.name,b.value]));
 const helperByKey=new Map(helpers.helpers.map(h=>[JSON.stringify([h.table,h.key]),h]));
 const locals=new Map(),events=[];let operations=0,allocations=0,currentStatement=null,currentIndex=-1,suspension=null;
 const tuple=(prefix=[],unknownTail=false)=>({prefix,unknownTail});
 const first=t=>t.prefix.length?t.prefix[0]:t.unknownTail?U('multiple-result'):null;
 const tick=()=>{if(++operations>maxOperations)throw new Frontier('setup-operation-budget');};
 for(const s of frameIR.frame.captureSymbols)locals.set(s.id,captured.has(s.name)?captured.get(s.name):U('unresolved-capture:'+s.name));
 let fixed=0,variadic=false;
 for(const p of frameIR.frame.parameters){if(p.varargs){variadic=true;break;}locals.set(p.id,args===null?U('incoming-argument'):args[fixed]??null);fixed++;}
 const varargs=variadic?(args===null?tuple([],true):tuple(args.slice(fixed))):tuple();
 const join=values=>{const unique=[...new Map(values.map(v=>[JSON.stringify(v),v])).values()];return unique.length===1?unique[0]:{kind:'choice',values:unique};};
 const list=nodes=>{
  const prefix=[];let tail=false;
  for(let i=0;i<nodes.length;i++){const r=expr(nodes[i]);if(i===nodes.length-1){prefix.push(...r.prefix);tail=r.unknownTail;}else prefix.push(first(r));}
  return tuple(prefix,tail);
 };
 const scalarArgs=t=>!t.unknownTail&&t.prefix.every(v=>v===null||['number','string','boolean'].includes(typeof v));
 const expr=n=>{
  tick();
  switch(n.kind){
   case 'literal':return tuple([n.value]);
   case 'symbol':return tuple([locals.has(n.symbol.id)?locals.get(n.symbol.id):U('unbound-symbol:'+n.symbol.id)]);
   case 'varargs':return varargs;
   case 'single-result':return tuple([first(expr(n.value))]);
   case 'closure':return tuple([{kind:'uninvoked-closure',ir:n}]);
   case 'index':case 'operand-read':{
    const base=n.kind==='index'?first(expr(n.base)):locals.get(n.baseSymbol.id),key=first(expr(n.index));
    if(!base?.table||key!==null&&!['number','string','boolean'].includes(typeof key))throw new Frontier('unresolved-setup-index');
    const table=tables.get(base.table);if(!table)throw new Frontier('missing-captured-table');
    const value=table.has(key)?table.get(key):null;
    return tuple([value?.closure?{kind:'helper-reference',table:base.table,key}:value]);
   }
   case 'table':{
    if(n.fields.some(f=>!f.array))throw new Frontier('keyed-setup-table-not-modeled');
    return tuple([{kind:'fresh-table',allocation:++allocations,values:list(n.fields.map(f=>f.value)),nilEntriesAbsent:true}]);
   }
   case 'call':{
    if(n.method)throw new Frontier('method-setup-call-not-modeled');
    const callee=first(expr(n.callee)),actual=list(n.args);
    if(callee?.native==='table.create'){
     const count=actual.prefix[0];if(actual.unknownTail||!Number.isSafeInteger(count)||count<0||count>1000000||actual.prefix.length>2)throw new Frontier('table-create-arguments-not-modeled');
     const value={kind:'fresh-table',allocation:++allocations,capacity:count,fill:actual.prefix.length>1?actual.prefix[1]:null};
     events.push({kind:'modeled-native',native:'table.create',capacity:count});return tuple([value]);
    }
    if(callee?.native==='getfenv'){
     if(actual.unknownTail||actual.prefix.length)throw new Frontier('getfenv-arguments-not-modeled');
     events.push({kind:'modeled-native',native:'getfenv',result:'opaque-environment'});return tuple([{kind:'opaque-environment'}]);
    }
    if(callee?.native==='pcall'){
     events.push({kind:'protected-call-frontier',callbackIsClosure:actual.prefix[0]?.kind==='uninvoked-closure'});
     if(currentStatement?.kind==='local'&&currentStatement.values.length===1&&currentStatement.values[0]===n&&actual.prefix[0]?.kind==='uninvoked-closure'){
      suspension={kind:'protected-local-assignment',callback:actual.prefix[0].ir,
       arguments:tuple(actual.prefix.slice(1),actual.unknownTail),targets:currentStatement.targets,
       continuation:frameIR.frame.body.slice(currentIndex+1),captureMode:'symbol-identities-at-suspension'};
     }
     throw new Frontier('protected-call-continuation-not-modeled');
    }
    if(callee?.kind==='helper-reference'){
     const helper=helperByKey.get(JSON.stringify([callee.table,callee.key]));if(!helper)throw new Frontier('helper-body-unavailable');
     // Non-scalar inputs are conservatively widened to an entirely unknown list.
     const result=analyzeHelper147(graph,helper,{args:scalarArgs(actual)?actual.prefix:null,maxOperations:Math.max(1,Math.min(1000,maxOperations-operations)),maxPaths:16});
     operations+=result.operations;if(operations>maxOperations)throw new Frontier('setup-operation-budget');
     if(result.status!=='abstract-outcomes')throw new Frontier('helper-blocked:'+result.reason);
     events.push({kind:'modeled-helper',table:callee.table,key:callee.key,outcomes:result.outcomes.length,correlations:'widened-per-result'});
     const lengths=result.outcomes.map(o=>o.values.prefix.length),length=Math.min(...lengths);
     const unknownTail=result.outcomes.some(o=>o.values.unknownTail)||lengths.some(n=>n!==length);
     return tuple(Array.from({length},(_,i)=>join(result.outcomes.map(o=>i<o.values.prefix.length?o.values.prefix[i]:o.values.unknownTail?U('multiple-result'):null))),unknownTail);
    }
    throw new Frontier('unapproved-setup-call');
   }
   default:throw new Frontier('setup-expression-not-modeled:'+n.kind);
  }
 };
 let stop='setup-body-end';
 try{
  for(const [index,n] of frameIR.frame.body.entries()){currentStatement=n;currentIndex=index;tick();
   if(n.kind==='vm-dispatch-boundary'){stop='dispatcher-boundary-not-entered';break;}
   if(n.kind!=='local')throw new Frontier('setup-statement-not-modeled:'+n.kind);
   const values=list(n.values);
   n.targets.forEach((s,i)=>locals.set(s.id,i<values.prefix.length?values.prefix[i]:values.unknownTail?U('multiple-result'):null));
   events.push({kind:'local-bindings',symbols:n.targets.map(s=>({id:s.id,name:s.name}))});
  }
 }catch(error){if(!(error instanceof Frontier))throw error;stop=error.message;}
 return {schema:1,kind:'bounded-abstract-frame-setup',symbolNamespace:frameIR.symbolNamespace??null,graphDigest:digest147(graph),fullRecoveryVerified:false,programCallsExecuted:false,stop,operations,events,suspension,
  bindings:[...locals].map(([id,value])=>({id,value})),limitations:['No dispatcher or protected callback is entered.','Helper paths are widened per result; cross-result correlations are not retained.','Captured table reads use the same-run initial plain-table graph; no predecessor mutation is modeled.','Opaque environments are not synthetic game/API results.']};
}
