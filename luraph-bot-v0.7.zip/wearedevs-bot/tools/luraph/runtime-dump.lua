-- Trusted harness. Run only inside the worker's OS sandbox.
local modulePath,input,output,bytecode=arg[1],arg[2],arg[3],arg[4]
if jit then jit.off();jit.flush() end
local Recorder=dofile(modulePath)
local file=assert(io.open(output,'wb'))
local rawnext,rawget,type,pcall,error=next,rawget,type,pcall,error
local sub,format,byte=string.sub,string.format,string.byte
local refs,queue,seen,announced={}, {}, {}, {};local serial,total,records,graphRecords,functions=0,0,0,0,0
local graphStopped=false
local function quote(s)
 local out={'"'};for i=1,#s do local b=byte(s,i);out[#out+1]=b>=32 and b<127 and b~=34 and b~=92 and string.char(b) or format('\\u%04x',b) end
 out[#out+1]='"';return table.concat(out)
end
local function json(v)
 if type(v)=='string' then return quote(v) end
 if type(v)=='number' then return format('%.17g',v) end
 if type(v)=='boolean' then return v and 'true' or 'false' end
 if v==nil then return 'null' end
 local parts={};for k,x in rawnext,v do parts[#parts+1]=quote(k)..':'..json(x) end
 return '{'..table.concat(parts,',')..'}'
end
local function line(text)
 if total+#text>4194304 or records>=30000 then error('dump-limit',0) end
 assert(file:write(text));assert(file:flush());total=total+#text;records=records+1
end
local function emit(v)line(json(v)..'\n')end
local function value(v)
 local t=type(v)
 if t=='nil' then return {type='nil'} end
 if t=='string' then return {type='string',value=sub(v,1,4096),truncated=#v>4096} end
 if t=='boolean' then return {type=t,value=v} end
 if t=='number' then
  if math.type and math.type(v)=='integer' then return {type='integer',value=format('%d',v)} end
  return {type=t,value=v~=v and 'nan' or v==math.huge and 'inf' or v==-math.huge and '-inf' or v==0 and 1/v<0 and '-0' or format('%.17g',v)}
 end
 local id=refs[v];if not id then
  if serial>=10000 then return {type=t,truncated=true} end
  serial=serial+1;id='object'..serial;refs[v]=id
  if t=='table' and not graphStopped then queue[#queue+1]=v end
  if t=='function' and functions<32 then
   functions=functions+1;local ok,blob=pcall(string.dump,v);local hex={}
   if ok and #blob<=16384 then for i=1,#blob do hex[#hex+1]=format('%02x',byte(blob,i)) end end
   emit({kind='function-bytecode',id=id,available=ok and #blob<=16384,bytecodeHex=table.concat(hex),note='Runtime-specific bytecode; upvalues are not reconstructed.'})
  end
 end
 return {type=t,ref=id}
end
local function snapshot(site,root)
 local ref=value(root);local identity=site..':'..(ref.ref or 'unknown')
 if not announced[identity] then announced[identity]=true;emit({kind='prototype',site=site,object=ref})end
 if graphStopped then return end
 local index=1
 while index<=#queue do
  local target=queue[index];index=index+1
  if not seen[target] then
   seen[target]=true;local count=0
   emit({kind='table-start',id=refs[target],hasMetatable=getmetatable(target)~=nil})
   for k,v in rawnext,target do
    graphRecords=graphRecords+1;if graphRecords>8000 then graphStopped=true;queue={};emit({kind='graph-truncated',reason='initial-graph-budget'});return end
    count=count+1;if count>2048 then emit({kind='table-truncated',id=refs[target]});break end
    emit({kind='table-entry',id=refs[target],key=value(k),value=value(v)})
   end
  end
 end
 queue={}
end
local recorder=Recorder.new{sessionId='runtime-dump',emit=line,maxEvents=20000,maxBytes=2097152,maxStringBytes=4096}
local enter=recorder.enterPrototype
function recorder:enterPrototype(site,prototype)snapshot(site,prototype);return enter(self,site,prototype)end
local function copy(t)local out={};for k,v in rawnext,t do out[k]=v end;return out end
local env={assert=assert,error=error,ipairs=ipairs,next=next,pairs=pairs,pcall=pcall,xpcall=xpcall,select=select,tonumber=tonumber,tostring=tostring,type=type,unpack=table.unpack or unpack,rawequal=rawequal,rawget=rawget,rawset=rawset,getmetatable=getmetatable,setmetatable=setmetatable,_VERSION=_VERSION}
env.math=copy(math);env.string=copy(string);env.string.dump=nil;env.table=copy(table);env.coroutine=copy(coroutine)
local hasBit,bit=pcall(require,'bit');if hasBit then env.bit=copy(bit);env.bit32=copy(bit) end
env._G=env;env.getfenv=function()return env end
local nativeSetfenv=setfenv
env.setfenv=function(fn,newenv)assert(type(fn)=='function' and newenv==env,'unsupported environment change');if nativeSetfenv then return nativeSetfenv(fn,env)end;return fn end
env.table.unpack=table.unpack or unpack
env.table.pack=function(...)return {n=select('#',...),...}end
env.table.create=function(n,v)assert(type(n)=='number' and n%1==0 and n>=0 and n<=100000,'table.create bounds');local t={};if v~=nil then for i=1,n do t[i]=v end end;return t end
local function log(...)
 for i=1,select('#',...) do emit({kind='printed-value',position=i,value=value(select(i,...))}) end
end
env.print=log;env.warn=log
-- Immutable byte-string buffer subset. No filesystem, require, FFI, network,
-- Roblox APIs or process capabilities are available in the target environment.
local function readUnsigned(s,offset,width)
 assert(type(s)=='string' and type(offset)=='number' and offset%1==0 and offset>=0 and offset+width<=#s,'buffer read bounds')
 local result=0;for i=width,1,-1 do result=result*256+byte(s,offset+i)end;return result
end
env.buffer={fromstring=function(s)assert(type(s)=='string');return s end,tostring=function(s)assert(type(s)=='string');return s end,len=function(s)return #s end,readstring=function(s,o,n)readUnsigned(s,o,0);assert(n>=0 and n%1==0 and o+n<=#s);return sub(s,o+1,o+n)end}
for _,width in ipairs({1,2,4}) do
 local w=width;env.buffer['readu'..w*8]=function(s,o)return readUnsigned(s,o,w)end
 env.buffer['readi'..w*8]=function(s,o)local n=readUnsigned(s,o,w);return n>=2^(w*8-1) and n-2^(w*8) or n end
end
local payload
if bytecode then local f=assert(io.open(bytecode,'rb'));payload=f:read('*a');f:close() end
local ticks=0;debug.sethook(function()ticks=ticks+1;if ticks>50000 then error('native-instruction-budget',0) end end,'',10000)
local ok,reason=pcall(function()
 local chunk,err
 if setfenv then chunk,err=loadfile(input);if chunk then setfenv(chunk,env)end else chunk,err=loadfile(input,'t',env)end
 assert(chunk,err)
 local wrapped=chunk()(recorder)
 if payload then wrapped(payload) else wrapped() end
end)
debug.sethook()
pcall(function()local status=recorder:finish(ok and 'returned' or 'runtime-stopped');emit({kind='runtime-status',ok=ok,reason=ok and 'returned' or type(reason)=='string' and sub(reason,1,1024) or 'non-string-error',recorderValid=status.valid,incompleteFrames=status.incompleteFrames})end)
file:close()
