// Versioned trace evidence, not an execution engine or recovery certificate.
import {createHash} from 'node:crypto';
const hash=s=>createHash('sha256').update(s).digest('hex');
function id(s){if(typeof s!=='string'||!s.length||s.length>128)throw Error('Invalid identifier');return s;}
function integer(n){if(!Number.isSafeInteger(n)||n<0)throw Error('Expected nonnegative safe integer');return n;}
function canonical(v,depth=0){
  if(depth>16)throw Error('Operand nesting limit');
  if(v===null||typeof v==='boolean'||typeof v==='string')return JSON.stringify(v);
  if(typeof v==='number'){if(!Number.isFinite(v))throw Error('Nonfinite number needs a typed token');return Object.is(v,-0)?'-0':String(v);}
  if(Array.isArray(v)){
    if(v.length>65536)throw Error('Operand array limit');
    const values=[];
    for(let i=0;i<v.length;i++){const d=Object.getOwnPropertyDescriptor(v,String(i));if(!d||!Object.hasOwn(d,'value'))throw Error('Sparse/accessor operand array');values.push(canonical(d.value,depth+1));}
    return '['+values.join(',')+']';
  }
  if(typeof v!=='object'||!v||![Object.prototype,null].includes(Object.getPrototypeOf(v)))throw Error('Invalid operand value');
  return '{'+Object.keys(v).sort().map(k=>{
    const d=Object.getOwnPropertyDescriptor(v,k);if(!d||!Object.hasOwn(d,'value'))throw Error('Operand accessors forbidden');
    return JSON.stringify(k)+':'+canonical(d.value,depth+1);
  }).join(',')+'}';
}
export class VersionedTrace147 {
  constructor(identity,limits={}){
    if(!identity||!/^[a-f0-9]{64}$/.test(identity.sourceSha256))throw Error('Source SHA256 required');
    this.identity=Object.freeze({sourceSha256:identity.sourceSha256,symbolNamespace:id(identity.symbolNamespace),sessionId:id(identity.sessionId),executionProfile:id(identity.executionProfile)});
    this.limits={events:1000000,sites:100000,versions:100000,frames:100000,edges:200000,payloadBytes:16*1024*1024,...limits};
    for(const n of Object.values(this.limits))if(!Number.isSafeInteger(n)||n<1)throw Error('Invalid trace limit');
    this.sites=new Map();this.edges=new Map();this.frames=new Map();this.usedFrames=new Set();this.threads=new Map();
    this.records=0;this.steps=0;this.observations=0;this.versionCount=0;this.payloadBytes=0;this.lastSeq=-1;this.failure=null;this.closed=false;
  }
  add(event){
    if(this.closed||this.failure)throw Error('Trace is closed or failed');
    try{this._add(event);}catch(e){this.failure=e.message;throw e;}
  }
  _add(e){
    if(!e||e.sessionId!==this.identity.sessionId)throw Error('Mixed trace session');
    integer(e.seq);if(e.seq<=this.lastSeq)throw Error('Sequence must increase');
    if(e.seq!==this.lastSeq+1&&e.kind!=='gap')throw Error('Sequence gap requires an explicit gap event');
    if(this.records>=this.limits.events)throw Error('Event limit');
    this.lastSeq=e.seq;this.records++;
    if(e.kind==='observation'){this._version(e);this.observations++;return;}
    const thread=id(e.threadId);
    if(!this.threads.has(thread)){
      if(this.threads.size>=this.limits.frames)throw Error('Thread limit');
      this.threads.set(thread,[]);
    }
    const stack=this.threads.get(thread);
    if(e.kind==='gap'){
      for(const frame of stack){frame.last=null;frame.resumed=false;}
      return;
    }
    const frameId=id(e.frameId);
    if(e.kind==='enter'){
      if(this.usedFrames.has(frameId))throw Error('Frame identifier reused');
      if(this.usedFrames.size>=this.limits.frames)throw Error('Frame limit');
      const prototypeId=id(e.prototypeId),parent=stack.at(-1);
      if(Object.hasOwn(e,'parentFrameId')&&e.parentFrameId!==(parent?.frameId??null))throw Error('Parent frame mismatch');
      const frame={frameId,prototypeId,threadId:thread,last:null,resumed:false};
      this.usedFrames.add(frameId);this.frames.set(frameId,frame);stack.push(frame);return;
    }
    const frame=stack.at(-1);
    if(!frame||frame.frameId!==frameId)throw Error('Event is not for the active frame');
    if(e.kind==='exit'){
      stack.pop();this.frames.delete(frameId);
      if(stack.length)stack.at(-1).resumed=true;
      return;
    }
    if(e.kind!=='step')throw Error('Unknown event kind');
    if(e.prototypeId!==frame.prototypeId)throw Error('Prototype/frame mismatch');
    const version=this._version(e);
    if(frame.last){
      const relation=frame.resumed?'resume':'step';
      const key=JSON.stringify([thread,frame.prototypeId,frame.last,version,relation]);
      if(!this.edges.has(key)){
        if(this.edges.size>=this.limits.edges)throw Error('Edge limit');
        this.edges.set(key,{threadId:thread,prototypeId:frame.prototypeId,from:frame.last,to:version,relation,observations:0});
      }
      this.edges.get(key).observations++;
    }
    frame.last=version;frame.resumed=false;this.steps++;
  }
  _version(e){
    const prototypeId=id(e.prototypeId),pc=integer(e.pc),opcode=integer(e.opcode);
    if(!Object.hasOwn(e,'operands')||!e.operands||Array.isArray(e.operands)||typeof e.operands!=='object')throw Error('Operand map required');
    const text=canonical({opcode,operands:e.operands});
    if(Buffer.byteLength(text)>65536)throw Error('Instruction payload limit');
    const key=JSON.stringify([prototypeId,pc]);
    let site=this.sites.get(key);
    if(!site){
      if(this.sites.size>=this.limits.sites)throw Error('Site limit');
      site={prototypeId,pc,versions:new Map()};this.sites.set(key,site);
    }
    const digest=hash(text);
    if(!site.versions.has(digest)){
      const bytes=Buffer.byteLength(text);
      if(this.versionCount>=this.limits.versions||this.payloadBytes+bytes>this.limits.payloadBytes)throw Error('Version storage limit');
      const versionId=hash(canonical([this.identity.sourceSha256,this.identity.symbolNamespace,prototypeId,pc,digest]));
      site.versions.set(digest,{versionId,payload:JSON.parse(text),firstRecord:e.seq,lastRecord:e.seq,records:0});
      this.versionCount++;this.payloadBytes+=bytes;
    }
    const v=site.versions.get(digest);v.lastRecord=e.seq;v.records++;
    return v.versionId;
  }
  finish(stopReason='producer-ended'){
    id(stopReason);this.closed=true;
    const sites=[...this.sites.values()].map(s=>({prototypeId:s.prototypeId,pc:s.pc,versions:[...s.versions.values()]}));
    return {schema:1,kind:'versioned-instruction-evidence',identity:this.identity,stopReason,
      valid:this.failure===null,error:this.failure,records:this.records,executedStepRecords:this.steps,unorderedObservations:this.observations,
      instructionSites:sites.length,instructionVersions:this.versionCount,multiVersionSites:sites.filter(s=>s.versions.length>1).length,
      incompleteFrames:[...this.frames.keys()],sites,edges:this.failure?[]:[...this.edges.values()],
      completeControlFlow:false,fullRecoveryVerified:false,
      limitations:['Only observed values are represented; unseen paths remain unknown.',
        'Multiple versions do not establish when or why a write occurred.',
        'Observation-only records create no execution edges or call relationships.',
        'Step edges are same-frame observations, not a complete static CFG; resume edges cross a call gap.',
        'No PC increment convention is assumed. Invalid sessions suppress all derived edges.']};
  }
}

// Legacy typed-IR rows lack call/return events. Import as observations ONLY.
export function typedIRObservation147(line,sessionId,seq){
  if(typeof line!=='string'||line.length>65536)throw Error('IR line limit');
  if(!line||line.startsWith('META\t')||line.startsWith('P\t'))return null;
  const fields=line.split('\t');if(fields.length!==10||fields[0]!=='I')throw Error('Invalid typed instruction row');
  function natural(s){if(!/^(0|[1-9][0-9]*)$/.test(s))throw Error('Invalid natural');return integer(Number(s));}
  function token(s){
    if(s==='N')return {type:'nil'};
    if(/^B[01]$/.test(s))return {type:'boolean',value:s==='B1'};
    if(s.startsWith('D')){
      const raw=s.slice(1);
      if(['nan','inf','-inf'].includes(raw))return {type:'number',value:raw};
      if(!/^-?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(raw)||!Number.isFinite(Number(raw)))throw Error('Invalid numeric token');
      return {type:'number',value:Object.is(Number(raw),-0)?'-0':Number(raw)};
    }
    if(/^S(?:[a-fA-F0-9]{2})*$/.test(s))return {type:'bytes',hex:s.slice(1).toLowerCase()};
    if(/^P\d+$/.test(s))return {type:'prototype',id:String(natural(s.slice(1)))};
    if(s.startsWith('T{')&&s.endsWith('}')||/^X[A-Za-z]+$/.test(s))return {type:'opaque',token:s};
    throw Error('Unsupported typed token');
  }
  if(!/^D(?:0|[1-9][0-9]*)$/.test(fields[4]))throw Error('Invalid opcode token');
  const names=['e','p','o','h','underscore','b'],positions=[3,5,6,7,8,9];
  const operands=Object.fromEntries(names.map((n,i)=>[n,token(fields[positions[i]])]));
  return {sessionId,seq,kind:'observation',prototypeId:String(natural(fields[1])),pc:natural(fields[2]),opcode:natural(fields[4].slice(1)),operands};
}
