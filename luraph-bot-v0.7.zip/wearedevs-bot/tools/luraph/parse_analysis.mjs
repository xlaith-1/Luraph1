// AST only; never execute normalized analysis source.
import fs from 'node:fs';
import lp from 'luaparse';
const ast=lp.parse(fs.readFileSync(process.argv[2],'utf8'),{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
fs.writeFileSync(process.argv[3],JSON.stringify(ast));
