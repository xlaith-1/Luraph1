// Internal research CLI. Input must be the syntax-adapted analysis AST source.
// Usage: node evaluate147.mjs NORMALIZED.lua DATA.bin|--inline NEW_OUTPUT_DIR
// This is NOT a bot source-recovery route and never writes recovered.lua.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {StaticDataEvaluator} from './static-data-eval.mjs';
import {InstructionLowerer,lowerFrame147} from './ir147.mjs';
import {extractHandlers} from './dispatch147.mjs';
const [input,dataFile,output,profile]=process.argv.slice(2);
if(profile&&!['--integer-bit','--integer-bit-no-ffi'].includes(profile))throw Error('Unknown research compatibility profile');
if(!input||!dataFile||!output)throw Error('Expected normalized input, data file or --inline, and new output directory');
if(fs.statSync(input).size>8*1024*1024)throw Error('Analysis source size limit');
if(dataFile!=='--inline'&&fs.statSync(dataFile).size>8*1024*1024)throw Error('Data size limit');
fs.mkdirSync(output);
const e=new StaticDataEvaluator({maxSteps:800000000,maxMilliseconds:120000,integerBitLibrary:!!profile,ffiUnavailable:profile==='--integer-bit-no-ffi'});
const start=Date.now();let result={status:'blocked'},error=null,description=null,helperMetadataError=null;
try{
 result=e.run(fs.readFileSync(input,'utf8'),dataFile==='--inline'?undefined:profile?fs.readFileSync(dataFile).toString('latin1'):fs.readFileSync(dataFile));
 if(result.status==='vm-boundary'){
  const selected=e.selectFrame(result);
  fs.writeFileSync(path.join(output,'selected-frame.ast.json'),JSON.stringify(selected));
  description=extractHandlers(result.closure.node,null,selected);
  const frameIR=lowerFrame147(description,selected),instructionIR=new InstructionLowerer(description,selected).lower(description.handlers);
  const names=[...new Set([...frameIR.frame.captureSymbols,...instructionIR.symbols.filter(s=>['prototype-slot','captured-unknown'].includes(s.role))].map(s=>s.name))];
  fs.writeFileSync(path.join(output,'frame-bindings.json'),JSON.stringify(e.snapshotFrameBindings(names)));
  try{fs.writeFileSync(path.join(output,'captured-helpers.json'),JSON.stringify(e.snapshotFrameHelpers(names)));}catch(exc){helperMetadataError=exc.message;}
  fs.writeFileSync(path.join(output,'factory.ast.json'),JSON.stringify(result.closure.node));
  fs.writeFileSync(path.join(output,'dispatch.ast.json'),JSON.stringify(description));
 }
}catch(exc){error=exc.message;}
const snapshot=e.snapshot(result),encoded=JSON.stringify(snapshot);
if(Buffer.byteLength(encoded)>16*1024*1024)error='Decoded graph exceeds research output limit';
else fs.writeFileSync(path.join(output,'decoded-graph.json'),encoded);
const report={schema:1,engine:'luraph147-data-research/0.1.0',status:error?'blocked':result.status,
 analysisSourceSha256:crypto.createHash('sha256').update(fs.readFileSync(input)).digest('hex'),
 compatibilityProfile:profile??'default',inputDataRepresentation:dataFile==='--inline'?'inline':profile?'byte-string':'buffer',fullRecoveryVerified:false,luaRuntimeUsed:false,payloadExecutionAllowed:false,astEvaluation:'bounded pure-data subset',
 factoryBoundaryRecognized:result.status==='vm-boundary',selectedFrameNotInvoked:true,error,helperMetadataError,steps:e.steps,milliseconds:Date.now()-start,
 allocatedTables:e.tables.length,bufferReads:snapshot.bufferReads,dispatcher:description?{opcodeVariable:description.opcodeVariable,read:description.read,frame:description.frame,specializedOpcodeValues:description.handlers.length,selectedFrameOnly:description.selectedFrameOnly,iterationExtracted:!!description.iteration}:null,
 limitations:['Decoded bootstrap records and handler ASTs are NOT application source.','VM boundary detection is structural; it is not a proof of complete source recovery.','Unknown native calls and library members stop analysis; no network, game APIs, loadstring or Lua runtime is available.','Not integrated into the Discord full-source route.']};
fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2));
console.log(JSON.stringify(report));
