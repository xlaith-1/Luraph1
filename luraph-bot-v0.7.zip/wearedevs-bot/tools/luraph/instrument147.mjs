// Structural, insertion-only instrumentation. No code execution or goto rewriting.
import lp from './vendor/luaparse.cjs';
import {createHash} from 'node:crypto';
const sha=s=>createHash('sha256').update(Buffer.from(s,'latin1')).digest('hex');
const ident=n=>n?.type==='Identifier';
const numeric=n=>n?.type==='NumericLiteral'&&Number.isSafeInteger(n.value)&&n.value>=0;
class Scope {constructor(parent=null){this.parent=parent;this.names=new Map();this.head=null;}get(n){return this.names.get(n)??this.parent?.get(n);}}
export function instrument147(source,{maxBytes=2*1024*1024,maxSites=64,minComparisons=3}={}){
 if(typeof source!=='string'||source.length>maxBytes||/[^\x00-\xff]/.test(source))throw Error('Input size limit');
 const ast=lp.parse(source,{luaVersion:'5.3',ranges:true,encodingMode:'pseudo-latin1'});
 const after=new WeakMap();
 const snapshot=env=>{const heads=[];for(let e=env;e;e=e.parent)heads.push(e.head);return {get(name){for(const head of heads)for(let p=head;p;p=p.previous)if(p.name===name)return p.symbol;}};};
 const refs=new WeakMap(),owner=new WeakMap(),functionScopes=new WeakMap(),symbols=[],functions=[],loops=[];
 const global=new Scope();let serial=0;
 const bind=(env,name,fn,origin=null)=>{const s={id:++serial,name,fn,origin,writes:0};env.names.set(name,s);env.head={name,symbol:s,previous:env.head};symbols.push(s);return s;};
 const resolve=(env,name)=>env.get(name)??bind(global,name,null);
 function walk(n,env,fn){
  if(!n||typeof n!=='object')return;
  owner.set(n,fn);
  if(n.type==='Identifier'){refs.set(n,resolve(env,n.name));return;}
  if(n.type==='FunctionDeclaration'){
   if(n.identifier&&ident(n.identifier)){
    if(n.isLocal)refs.set(n.identifier,bind(env,n.identifier.name,fn));
    else resolve(env,n.identifier.name).writes++;
   }
   const scope=new Scope(env);functions.push(n);functionScopes.set(n,scope);
   for(const p of n.parameters)if(ident(p))refs.set(p,bind(scope,p.name,n,{parameter:true}));
   block(n.body,scope,n);return;
  }
  if(n.type==='LocalStatement'){
   for(const x of n.init)walk(x,env,fn);
   n.variables.forEach((v,i)=>refs.set(v,bind(env,v.name,fn,n.init[i]??null)));return;
  }
  if(n.type==='AssignmentStatement'){
   n.init.forEach(x=>walk(x,env,fn));
   n.variables.forEach(v=>{walk(v,env,fn);if(ident(v))refs.get(v).writes++;});return;
  }
  if(n.type==='CompoundAssignmentStatement'){walk(n.variable,env,fn);walk(n.value,env,fn);if(ident(n.variable))refs.get(n.variable).writes++;return;}
  if(n.type==='IfStatement'){for(const c of n.clauses){walk(c.condition,env,fn);block(c.body,new Scope(env),fn);}return;}
  if(n.type==='DoStatement'){block(n.body,new Scope(env),fn);return;}
  if(n.type==='WhileStatement'||n.type==='RepeatStatement'){
   const scope=new Scope(env);loops.push(n);
   if(n.type==='WhileStatement')walk(n.condition,env,fn);
   block(n.body,scope,fn);
   if(n.type==='RepeatStatement')walk(n.condition,scope,fn);
   return;
  }
  if(n.type==='ForNumericStatement'){
   for(const x of [n.start,n.end,n.step])walk(x,env,fn);
   const scope=new Scope(env);refs.set(n.variable,bind(scope,n.variable.name,fn));block(n.body,scope,fn);return;
  }
  if(n.type==='ForGenericStatement'){
   n.iterators.forEach(x=>walk(x,env,fn));const scope=new Scope(env);
   n.variables.forEach(v=>refs.set(v,bind(scope,v.name,fn)));block(n.body,scope,fn);return;
  }
  for(const [key,v] of Object.entries(n)){
   if(['range','comments','identifier'].includes(key))continue;
   if(Array.isArray(v))v.forEach(x=>walk(x,env,fn));else if(v&&typeof v==='object')walk(v,env,fn);
  }
 }
 function block(body,env,fn){for(const n of body){walk(n,env,fn);after.set(n,snapshot(env));}}
 block(ast.body,new Scope(global),null);
 function ownedWalk(n,fn,visit){
  if(!n||typeof n!=='object'||n.type==='FunctionDeclaration'&&n!==fn)return;
  if(n.type)visit(n);
  for(const [k,v] of Object.entries(n)){
   if(['range','comments'].includes(k))continue;
   if(Array.isArray(v))v.forEach(x=>ownedWalk(x,fn,visit));else if(v&&typeof v==='object')ownedWalk(v,fn,visit);
  }
 }
 const candidates=[],rejections=[];
 for(const loop of loops){
  const fn=owner.get(loop);if(!fn)continue;
  for(const fetch of loop.body){
   if(!['LocalStatement','AssignmentStatement'].includes(fetch.type))continue;
   fetch.variables.forEach((v,i)=>{
    const read=fetch.init[i];
    if(!ident(v)||read?.type!=='IndexExpression'||!ident(read.base)||!ident(read.index))return;
    const op=refs.get(v),array=refs.get(read.base),pc=refs.get(read.index);if(!op?.fn||!array||!pc?.fn)return;
    let comparisons=0;
    ownedWalk(loop,fn,n=>{if(n.type==='BinaryExpression'&&['==','~=','<','<=','>','>='].includes(n.operator)&&((refs.get(n.left)===op&&numeric(n.right))||(refs.get(n.right)===op&&numeric(n.left))))comparisons++;});
    if(comparisons<minComparisons)return;
    const origin=array.origin;
    if(array.writes||origin?.type!=='IndexExpression'||!ident(origin.base)||!numeric(origin.index)){rejections.push({offset:fetch.range[0],reason:'unstable-or-unresolved-opcode-array'});return;}
    const proto=refs.get(origin.base);
    if(!proto||proto.writes||!proto.origin?.parameter){rejections.push({offset:fetch.range[0],reason:'unstable-or-unresolved-prototype'});return;}
    const visible=functionScopes.get(fn);
    if(visible.get(proto.name)!==proto){rejections.push({offset:fetch.range[0],reason:'prototype-shadowed-at-entry'});return;}
    if(after.get(fetch).get(pc.name)!==pc){rejections.push({offset:fetch.range[0],reason:'pc-shadowed-at-fetch'});return;}
    const operands=new Map();
    ownedWalk(fn,fn,n=>{
     if(n.type!=='IndexExpression'||refs.get(n.index)!==pc||!ident(n.base))return;
     const binding=refs.get(n.base),o=binding?.origin;
     if(after.get(fetch).get(binding?.name)!==binding||binding===array||binding?.writes||o?.type!=='IndexExpression'||!numeric(o.index)||refs.get(o.base)!==proto)return;
     operands.set(binding.id,{name:binding.name,slot:o.index.value,binding:binding.id});
    });
    candidates.push({fn,loop,fetch,op,array,pc,proto,operands:[...operands.values()],comparisons});
   });
  }
 }
 // A function with multiple candidate loops needs a richer frame model. Reject,
 // rather than placing conflicting frame handles or assuming one dispatcher wins.
 const counts=new Map();for(const c of candidates)counts.set(c.fn,(counts.get(c.fn)??0)+1);
 const accepted=candidates.filter(c=>{if(counts.get(c.fn)!==1){rejections.push({offset:c.fetch.range[0],reason:'ambiguous-dispatch-loops'});return false;}return true;});
 if(!accepted.length)throw Error('No unambiguous supported dispatcher found');
 if(accepted.length>maxSites)throw Error('Capture-site limit');
 let prefix='__lph_trace_'+sha(source).slice(0,10);
 while(source.includes(prefix))prefix+='x';
 const inserts=[];const insert=(position,text)=>inserts.push({position,text,order:inserts.length});
 const metadata=[];
 for(const c of accepted){
  const tag='site'+c.fn.range[0],frame=prefix+'_f'+c.fn.range[0];
  insert(c.fn.body[0].range[0],`local ${frame}=${prefix}:enterPrototype("${tag}",${c.proto.name}); `);
  const arrays=c.operands.map(a=>`["binding${a.binding}_slot${a.slot}"]=(${a.name} or false)`).join(',');
  insert(c.fetch.range[0],`${prefix}:checkCodeArray(${c.array.name}); `);
  insert(c.fetch.range[1],`; ${prefix}:stepArrays(${frame},${c.pc.name},${c.op.name},{${arrays}}) `);
  ownedWalk(c.fn,c.fn,n=>{
   if(n.type!=='ReturnStatement')return;
   if(n.arguments.length){
    insert(n.range[0]+6,` ${prefix}:returns(${frame},`);
    const end=n.range[1]-(source[n.range[1]-1]===';'?1:0);
    insert(end,')');
   }else insert(n.range[0]+6,` ${prefix}:returns(${frame})`);
  });
  if(c.fn.body.at(-1)?.type!=='ReturnStatement'){
   const fragment=source.slice(c.fn.range[0],c.fn.range[1]);const m=/end\s*\)*$/.exec(fragment);
   if(!m)throw Error('Function boundary could not be preserved');
   insert(c.fn.range[0]+m.index,` ${prefix}:exit(${frame}); `);
  }
  metadata.push({siteId:tag,prototypeVariable:c.proto.name,opcodeVariable:c.op.name,opcodeArray:c.array.name,opcodeSlot:c.array.origin.index.value,pcVariable:c.pc.name,operands:c.operands,comparisons:c.comparisons,functionRange:c.fn.range,fetchRange:c.fetch.range});
 }
 let instrumented=source;
 inserts.sort((a,b)=>b.position-a.position||b.order-a.order);
 for(const patch of inserts)instrumented=instrumented.slice(0,patch.position)+patch.text+instrumented.slice(patch.position);
 // The harness supplies the recorder as an upvalue; original varargs are intact.
 const wrapped=`return function(${prefix}) return function(...)\n${instrumented}\nend end\n`;
 lp.parse(wrapped,{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
 return {source:wrapped,report:{schema:1,sourceSha256:sha(source),instrumentedSha256:sha(wrapped),sites:metadata,rejections,patchStrategy:'insertions-only',fullRecoveryVerified:false,limitations:['Only supported structurally identified frames are instrumented.','Opcode-boundary snapshots do not cover fused/deferred reads.','Caught exceptions and uninstrumented calls can leave incomplete frame evidence.','Instrumentation changes debug/stack observations; runtime equivalence is not certified.']}};
}
