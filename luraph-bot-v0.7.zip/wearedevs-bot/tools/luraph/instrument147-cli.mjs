#!/usr/bin/env node
// Preparation only. This CLI never runs the input or starts a Lua interpreter.
import fs from 'node:fs';
import path from 'node:path';
import {instrument147} from './instrument147.mjs';
const [input,output,...extra]=process.argv.slice(2);
if(!input||!output||extra.length)throw Error('Usage: node instrument147-cli.mjs raw-interpreter.lua NEW-directory');
const stat=fs.statSync(input);if(!stat.isFile()||stat.size>2*1024*1024)throw Error('Input size/type limit');
if(fs.existsSync(output))throw Error('Output directory must not already exist');
const built=instrument147(fs.readFileSync(input,'latin1'));
if(Buffer.byteLength(built.source,'latin1')>32*1024*1024)throw Error('Instrumented output limit');
fs.mkdirSync(output,{recursive:true,mode:0o700});
fs.writeFileSync(path.join(output,'instrumented.lua'),built.source,{encoding:'latin1',flag:'wx',mode:0o600});
fs.writeFileSync(path.join(output,'capture-plan.json'),JSON.stringify(built.report,null,2)+'\n',{flag:'wx',mode:0o600});
console.log(JSON.stringify({prepared:true,executed:false,sites:built.report.sites.length,output:path.resolve(output),applicationSourceRecovered:false}));
