# Versioned instruction evidence stage

## Purpose

`trace147.mjs` is a reusable offline pipeline component. It tracks instruction
versions without assuming stable opcode numbers, operand names, PC origins, or a
particular sample's prototype IDs. It does not discover VM boundaries, execute
Lua, lift instructions, or recover source by itself.

This addresses a concrete failure mode: a VM can modify opcode and operand arrays
after an initial capture. Keeping only the initial or final array can misrepresent
the instructions that actually ran. This stage retains distinct observed versions.

## API and event contract

```js
import {VersionedTrace147} from './trace147.mjs';
const trace = new VersionedTrace147({
  sourceSha256: 'a'.repeat(64), // actual input digest in real use
  symbolNamespace: 'decoder-layout-identity',
  sessionId: 'unique-run-id',
  executionProfile: 'describe-the-capture-environment'
});
trace.add({sessionId:'unique-run-id',seq:0,kind:'enter',
  threadId:'main',frameId:'f1',prototypeId:'p0'});
trace.add({sessionId:'unique-run-id',seq:1,kind:'step',
  threadId:'main',frameId:'f1',prototypeId:'p0',
  pc:0,opcode:17,operands:{left:1,right:2}});
trace.add({sessionId:'unique-run-id',seq:2,kind:'exit',
  threadId:'main',frameId:'f1'});
const evidence = trace.finish('producer-ended');
```

- Sequence numbers start at zero and are consecutive. A producer must explicitly
  emit `gap` to mark dropped records; only a gap may jump the sequence number.
- Frame IDs are globally unique within a session. Reentrant calls need new IDs,
  even when they call the same prototype. Threads have independent stacks.
- `enter` pushes a frame; `step` must target the top frame; `exit` pops it.
  Optional `parentFrameId` is checked against the actual stack.
- `gap` requires a thread ID and invalidates pending edges in that thread's frames.
- A parent step after a child returns produces a `resume` relation, not a direct
  instruction jump. Other consecutive same-frame steps produce `step` relations.
- `observation` carries prototypeId, pc, opcode and operands without any frame.
  It records a value variant but cannot create execution edges.
- Operand maps accept finite numbers, strings, booleans, null, arrays and plain
  objects. Encode byte strings and nonfinite numbers with explicit typed objects.
  Sparse/accessor arrays and object accessors are rejected. Cycles/deep objects
  hit the nesting bound. Strings in operands are data and are never evaluated.

The producer must record operands at the correct read boundary. One pre-opcode
snapshot may not capture a fused instruction that increments its PC and reads
more operands inside the same handler. Such cases require finer producer events
or explicit additional operand-read evidence; this stage does not infer them.

## Offline CLI

```sh
node tools/luraph/trace147-cli.mjs manifest.json evidence.json
```

Example manifest:

```json
{
  "identity": {
    "sourceSha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    "symbolNamespace": "replace-with-your-decoder-layout",
    "sessionId": "run-1",
    "executionProfile": "saved-evidence-only"
  },
  "inputs": [
    {"format": "typed-ir-observations", "path": "initial.tsv"},
    {"format": "typed-ir-observations", "path": "observed-versions.tsv"}
  ],
  "stopReason": "imported-partial-evidence"
}
```

Paths are relative to the manifest. `events-jsonl` instead imports explicit events
with the sequence/session fields shown above. This CLI is an offline local tool,
not an upload endpoint: do not expose arbitrary manifest paths through Discord.

The legacy typed-IR adapter reads ten-column `I` rows. `META` and `P` lines are
not instructions. It preserves byte strings as hex, prototype references as IDs,
and opaque values as opaque tokens. It does **not** treat prototype declarations
as validation of prototype ownership or infer frame lifetimes from old ENTER logs.
An unordered/deduplicated legacy file cannot reconstruct execution history.

## Guarantees and limits

- Versions are scoped by source digest, symbol namespace, prototype, and PC.
  These identity checks prevent accidental mixing; they do not prove that a
  producer honestly traced that source or establish semantic equivalence.
- Re-observing an earlier version retains it rather than overwriting history.
- `records` are counts of imported observations, not necessarily execution counts.
- Multiple versions establish differing observed values, not the exact write time,
  whether a modification is permanent, or whether all possible values were seen.
- No post-dispatch PC increment convention is guessed. Actual observed PCs define
  trace relations; static CFG construction must separately model the dispatcher.
- Event/version/site/frame/edge counts and payload storage are bounded. The CLI
  also bounds file, line, total input and output sizes.
- A validation failure quarantines the session: `valid:false`, a reason, retained
  partial evidence, and no derived edges. A budget-ended valid trace can retain
  incomplete frames without pretending it covers every path.
- `completeControlFlow` and `fullRecoveryVerified` remain false.

## Validation in this iteration

18 new tests cover three synthetic instruction layouts, operand/opcode mutations,
recursion, repeated calls, interleaved threads, gaps, partial traces, mixed sessions,
malformed tokens, limits and the CLI. These are component tests, not evidence of
new end-to-end recovery across different obfuscators.

Regression import of existing saved capture data (no new execution):

- 21,442 imported instruction records;
- 16,110 instruction locations;
- 16,530 distinct versions;
- 420 multi-version locations;
- zero edges, correctly, because the legacy evidence lacks full frame events.

## Integration status

Research component only. No Discord routing or production engine behavior changed.
A portable capture-event producer is now available; see [RECORDER147.md](RECORDER147.md).
It emits this contract from explicit hooks. Limited structural hook selection is now tested with the producer/importer; see
`INSTRUMENT147.md`. General runtime integration and a version-aware semantic
control-flow consumer are still unfinished. Untouched holdouts were not inspected.

The CLI now accepts an optional `producerStatus` JSON path for event-only imports.
It validates session/event counts and quarantines recorder failures; see RECORDER147.md.
