// Research-only abstract helper evaluation. No Lua/native/uploaded call executes.
// Deliberately narrow: declarations, literal/index expressions, conditionals,
// return lists, vararg table packing and identity-resolved select('#', ...).
const unknown=reason=>({kind:'unknown',reason});
const isUnknown=x=>x?.kind==='unknown';
const truth=x=>isUnknown(x)?null:x!==null&&x!==false;
class Blocked extends Error {}
export function analyzeHelper147(graph,helper,{args=null,maxOperations=1000,maxPaths=16}={}){
 if(!Number.isInteger(maxOperations)||maxOperations<1||maxOperations>100000||!Number.isInteger(maxPaths)||maxPaths<1||maxPaths>128)throw Error('Helper budget limits');
 if(args!==null&&(!Array.isArray(args)||args.length>1024||args.some(x=>x!==null&&!['string','number','boolean'].includes(typeof x)||typeof x==='number'&&!Number.isFinite(x))))throw Error('Helper arguments must be finite scalar values');
 let operations=0,branches=1;const tables=new Map(graph.tables.map(t=>[t.id,new Map(t.entries)]));
 const captures=new Map(helper.captures.filter(c=>c.resolved).map(c=>[c.name,c.value]));
 const tick=()=>{if(++operations>maxOperations)throw new Blocked('operation-budget');};
 const tuple=(prefix=[],tail=false)=>({prefix,unknownTail:tail});
 const first=t=>t.prefix.length?t.prefix[0]:t.unknownTail?unknown('unknown-multiple-result'):null;
 const read=(base,key)=>{
  if(isUnknown(base)||isUnknown(key))return unknown('unresolved-index');
  if(base&&Object.hasOwn(base,'table')){const table=tables.get(base.table);if(!table)throw new Blocked('missing-captured-table');return table.has(key)?table.get(key):null;}
  throw new Blocked('index-base-not-modeled');
 };
 const list=(nodes,state)=>{
  const values=[];let tail=false;
  for(let i=0;i<nodes.length;i++){const t=expr(nodes[i],state);if(i===nodes.length-1){values.push(...t.prefix);tail=t.unknownTail;}else values.push(first(t));}
  return tuple(values,tail);
 };
 const expr=(n,state)=>{
  tick();let result;
  switch(n.type){
   case 'StringLiteral':if(typeof n.value!=='string')throw new Blocked('string-value-not-decoded');result=tuple([n.value]);break;
   case 'NumericLiteral':case 'BooleanLiteral':result=tuple([n.value]);break;
   case 'NilLiteral':result=tuple([null]);break;
   case 'Identifier':result=tuple([state.locals.has(n.name)?state.locals.get(n.name):captures.has(n.name)?captures.get(n.name):unknown('unresolved-name:'+n.name)]);break;
   case 'VarargLiteral':result=state.varargs;break;
   case 'IndexExpression':result=tuple([read(first(expr(n.base,state)),first(expr(n.index,state)))]);break;
   case 'BinaryExpression':{
    const a=first(expr(n.left,state)),b=first(expr(n.right,state));
    if(!['==','~='].includes(n.operator))throw new Blocked('binary-operator-not-modeled');
    if(isUnknown(a)||isUnknown(b))result=tuple([unknown('comparison')]);
    else if(a&&typeof a==='object'||b&&typeof b==='object')throw new Blocked('reference-comparison-not-modeled');
    else result=tuple([n.operator==='=='?a===b:a!==b]);break;
   }
   case 'CallExpression':{
    const callee=first(expr(n.base,state)),arguments_=list(n.arguments,state);
    if(callee?.native!=='select'||arguments_.prefix[0]!=='#')throw new Blocked('unapproved-call');
    result=tuple([arguments_.unknownTail?unknown('argument-count'):arguments_.prefix.length-1]);break;
   }
   case 'TableConstructorExpression':{
    if(n.fields.some(f=>f.type!=='TableValue'))throw new Blocked('keyed-table-constructor-not-modeled');
    result=tuple([{kind:'fresh-array-table',values:list(n.fields.map(f=>f.value),state),nilEntriesAbsent:true}]);break;
   }
   default:throw new Blocked('expression-not-modeled:'+n.type);
  }
  return n.inParens?tuple([first(result)]):result;
 };
 const clone=s=>({...s,locals:new Map(s.locals),conditions:[...s.conditions]});
 const block=(nodes,states)=>{
  for(const n of nodes){const next=[];
   for(const state of states){tick();if(state.returned){next.push(state);continue;}
    if(n.type==='LocalStatement'){
     const values=list(n.init,state);
     n.variables.forEach((v,i)=>state.locals.set(v.name,i<values.prefix.length?values.prefix[i]:values.unknownTail?unknown('unknown-multiple-result'):null));next.push(state);
    }else if(n.type==='ReturnStatement'){state.returned=list(n.arguments,state);next.push(state);}
    else if(n.type==='IfStatement'){
     let remaining=[state];
     for(const c of n.clauses){const fallthrough=[];
      for(const s of remaining){const value=c.condition?first(expr(c.condition,s)):true,condition=truth(value);
       if(condition!==false){const yes=clone(s);if(condition===null){if(++branches>maxPaths)throw new Blocked('path-budget');yes.conditions.push({condition:c.condition,truth:true});}
        const outer=new Map(s.locals);const results=block(c.body,[yes]);
        // Branch-local declarations do not leak; assignments are unsupported.
        for(const r of results){r.locals=new Map(outer);next.push(r);}
       }
       if(condition!==true){const no=clone(s);if(condition===null)no.conditions.push({condition:c.condition,truth:false});fallthrough.push(no);}
      }
      remaining=fallthrough;
     }
     next.push(...remaining);
    }else throw new Blocked('statement-not-modeled:'+n.type);
   }
   states=next;
  }
  return states;
 };
 const initial={locals:new Map(),varargs:args===null?tuple([],true):tuple([...args]),conditions:[]};
 const report={schema:1,kind:'abstract-helper-result',fullRecoveryVerified:false,programCallsExecuted:false};
 try{
  let index=0,hasVarargs=false;
  for(const p of helper.node.parameters){if(p.type==='VarargLiteral'){hasVarargs=true;break;}if(p.type!=='Identifier')throw new Blocked('parameter-not-modeled');initial.locals.set(p.name,args===null?unknown('argument'):args[index]??null);index++;}
  initial.varargs=hasVarargs?(args===null?tuple([],true):tuple(args.slice(index))):tuple();
  const states=block(helper.node.body,[initial]);
  return {...report,status:'abstract-outcomes',operations,outcomes:states.map(s=>({conditions:s.conditions,values:s.returned??tuple()})),limitations:['Only a narrow scalar/packing subset is modeled.','Unknown branches are retained without predicate refinement.','Decoded table reads assume the saved plain-table snapshot; mutations are not propagated.']};
 }catch(error){if(!(error instanceof Blocked))throw error;return {...report,status:'blocked',reason:error.message,operations,outcomes:[]};}
}
