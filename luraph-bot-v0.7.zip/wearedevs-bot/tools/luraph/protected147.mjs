// Structural/abstract pcall suspension. This does not run a callback or dispatcher.
const U=reason=>({kind:'unknown',reason});
export function prepareProtected147(setup,{maxOperations=1000}={}){
 if(!Number.isInteger(maxOperations)||maxOperations<1||maxOperations>100000)throw Error('Protected setup budget');
 const base={schema:1,kind:'abstract-protected-call-plan',symbolNamespace:setup.symbolNamespace??null,graphDigest:setup.graphDigest??null,fullRecoveryVerified:false,programCallsExecuted:false,instructionEntryAuthorized:false};
 const suspension=setup.suspension;
 if(setup.stop!=='protected-call-continuation-not-modeled'||suspension?.kind!=='protected-local-assignment')return {...base,status:'blocked',reason:'unsupported-protected-suspension'};
 const bindings=new Map(setup.bindings.map(b=>[b.id,b.value]));
 const args=suspension.arguments;let index=0,operations=0,boundary=null;
 const get=(tuple,i)=>i<tuple.prefix.length?tuple.prefix[i]:tuple.unknownTail?U('unknown-multiple-result'):null;
 let varargs={prefix:[],unknownTail:false};
 for(const parameter of suspension.callback.parameters){
  if(parameter.varargs){varargs={prefix:args.prefix.slice(index),unknownTail:args.unknownTail};break;}
  bindings.set(parameter.id,get(args,index++));
 }
 const scalar=n=>{
  if(++operations>maxOperations)throw Error('protected-prologue-budget');
  if(n.kind==='literal')return n.value;
  if(n.kind==='symbol')return bindings.has(n.symbol.id)?bindings.get(n.symbol.id):U('unbound-callback-symbol');
  if(n.kind==='single-result'&&n.value.kind==='varargs')return get(varargs,0);
  throw Error('callback-prologue-expression-not-modeled:'+n.kind);
 };
 try{
  for(const n of suspension.callback.body){
   if(++operations>maxOperations)throw Error('protected-prologue-budget');
   if(n.kind==='vm-dispatch-boundary'){boundary=n;break;}
   if(n.kind!=='local')throw Error('callback-prologue-statement-not-modeled:'+n.kind);
   const values=[];let tail=false;
   for(let i=0;i<n.values.length;i++){
    const value=n.values[i];
    if(value.kind==='varargs'){
     if(i===n.values.length-1){values.push(...varargs.prefix);tail=varargs.unknownTail;}else values.push(get(varargs,0));
    }else values.push(scalar(value));
   }
   const tuple={prefix:values,unknownTail:tail};n.targets.forEach((s,i)=>bindings.set(s.id,get(tuple,i)));
  }
 }catch(error){return {...base,status:'blocked',reason:error.message,operations};}
 if(!boundary)return {...base,status:'blocked',reason:'callback-dispatch-boundary-unavailable',operations};
 return {...base,status:'callback-dispatch-boundary-not-entered',operations,boundary,
  bindings:[...bindings].map(([id,value])=>({id,value})),targets:suspension.targets,continuation:suspension.continuation,
  outcomeRules:{normalReturn:'true followed by the entire callback return tuple',luaError:'false followed by one error value',unknownEffects:'remain blocked, not converted into a Lua error'},
  limitations:['No callback return or error is assumed; both are conditional continuations.',
   'Callback prologue supports only literal/local/vararg bindings.',
   'Dispatcher instructions and cross-IR symbol linking are not implemented here.']};
}

// Apply an explicitly supplied hypothetical callback outcome. This is only tuple
// adjustment, not execution or evidence that this outcome actually occurs.
export function bindProtectedOutcome147(plan,outcome){
 if(plan.status!=='callback-dispatch-boundary-not-entered')throw Error('No protected continuation plan');
 let tuple;
 if(outcome.kind==='return'){
  if(!Array.isArray(outcome.values?.prefix)||typeof outcome.values.unknownTail!=='boolean'||outcome.values.prefix.length>1024)throw Error('Invalid callback tuple');
  tuple={prefix:[true,...outcome.values.prefix],unknownTail:outcome.values.unknownTail};
 }else if(outcome.kind==='lua-error'){if(!Object.hasOwn(outcome,'value')||outcome.value===undefined)throw Error('Explicit Lua error value required');tuple={prefix:[false,outcome.value],unknownTail:false};}
 else throw Error('Unmodeled analysis effects cannot be converted to callback errors');
 return {kind:'hypothetical-protected-result-bindings',fullRecoveryVerified:false,hypothetical:true,
  bindings:plan.targets.map((s,i)=>({id:s.id,value:i<tuple.prefix.length?tuple.prefix[i]:tuple.unknownTail?U('unknown-callback-return'):null})),continuation:plan.continuation};
}
