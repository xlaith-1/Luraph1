import {digest147} from './provenance147.mjs';
// Provisional INITIAL-IMAGE control-flow analysis of typed VM instruction IR.
// This is not whole-program equivalence: predecessor writes, callbacks, opaque
// call effects and inter-instruction temporary values are not yet propagated.
// No calls from the uploaded program are executed.
const U=Symbol('unknown'),REG=Object.freeze({registerFile:true});
const truth=x=>x===U?U:x!==null&&x!==false;
const clone=s=>({...s,locals:new Map(s.locals),registers:new Map(s.registers),memory:new Map([...s.memory].map(([k,v])=>[k,new Map(v)])),unknownTables:new Set(s.unknownTables),hazards:new Set(s.hazards),control:null});
const numeric=x=>typeof x==='number'&&Number.isFinite(x);
function binary(op,a,b){
 if(a===U||b===U)return U;
 if(op==='==')return a===b;
 if(op==='~='){const x=binary('==',a,b);return x===U?U:!x;}
 if(['<','<=','>','>='].includes(op)){
  if(typeof a!==typeof b||!['number','string'].includes(typeof a))return U;
  return op==='<'?a<b:op==='<='?a<=b:op==='>'?a>b:a>=b;
 }
 if(!numeric(a)||!numeric(b))return U;
 switch(op){case '+':return a+b;case '-':return a-b;case '*':return a*b;case '/':return b===0?U:a/b;case '//':return b===0?U:Math.floor(a/b);case '%':return b===0?U:a-Math.floor(a/b)*b;case '^':return a**b;default:return U;}
}
export class InitialImageCFG {
 constructor(graph,description,ir,{maxPaths=64,maxIterations=128,maxOperations=20000,maxTotalOperations=20000000}={}){
  this.graphDigest=digest147(graph);this.refs=new Map();this.localId=0;
  this.tables=new Map(graph.tables.map(t=>[t.id,new Map(t.entries.map(([k,v])=>[k&&typeof k==='object'&&Number.isInteger(k.table)?this.ref(k.table):k,v]))]));
  this.prototype=this.tables.get(graph.args?.[0]?.table);if(!this.prototype)throw Error('Missing entry prototype');
  this.d=description;this.ir=ir;this.handlers=new Map(ir.instructions.map(i=>[i.opcode,i]));
  this.options={maxPaths,maxIterations,maxOperations,maxTotalOperations};this.totalOperations=0;
  this.opcodes=this.tables.get(this.prototype.get(description.read.opcodeSlot)?.table);
  if(!this.opcodes)throw Error('Missing opcode array');
 }
 ref(id){if(!this.refs.has(id))this.refs.set(id,Object.freeze({table:id}));return this.refs.get(id);}
 value(raw){if(raw===undefined)return null;if(raw&&typeof raw==='object')return Number.isInteger(raw.table)?this.ref(raw.table):U;return raw;}
 stop(s,reason){s.hazards.add(reason);s.control='unresolved';}
 read(base,index,s){
  if(index===U)return U;
  if(base===REG)return s.registers.has(index)?s.registers.get(index):s.registersInitiallyNil?null:U;
  if(base&&Number.isInteger(base.table)){
   if(s.memoryInvalidated)return U;
   const writes=s.memory.get(base.table);if(writes?.has(index))return writes.get(index);
   if(s.unknownTables.has(base.table))return U;
   return this.value(this.tables.get(base.table)?.get(index));
  }
  return U;
 }
 length(ref,s){
  if(s.memoryInvalidated||s.unknownTables.has(ref.table))return U;
  const entries=new Map(this.tables.get(ref.table)??[]);
  for(const [k,v]of s.memory.get(ref.table)??[])entries.set(k,v);
  const keys=[];for(const [k,v]of entries){if(Number.isInteger(k)&&k>0&&v!==null){if(v===U)return U;keys.push(k);}}
  if(!keys.length)return 0;const max=Math.max(...keys);return max===keys.length?max:U;
 }
 expr(e,s){
  if(++this.totalOperations>this.options.maxTotalOperations){this.stop(s,'analysis-operation-budget');return U;}
  if(++this.operations>this.options.maxOperations){this.stop(s,'instruction-operation-budget');return U;}
  switch(e.kind){
   case 'literal':return e.value;
   case 'symbol':{
    const v=e.symbol;
    if(v.role==='pc')return s.pc;
    if(s.locals.has(v.id))return s.locals.get(v.id);
    if(v.role==='register-file')return REG;
    if(v.role==='prototype-slot')return this.value(this.prototype.get(v.slot));
    return U;
   }
   case 'operand-read':return this.read(e.baseSymbol?this.expr({kind:'symbol',symbol:e.baseSymbol},s):this.value(this.prototype.get(e.slot)),this.expr(e.index,s),s);
   case 'register-read':return this.read(e.baseSymbol?this.expr({kind:'symbol',symbol:e.baseSymbol},s):REG,this.expr(e.index,s),s);
   case 'index':return this.read(this.expr(e.base,s),this.expr(e.index,s),s);
   case 'single-result':return this.expr(e.value,s);
   case 'unary':{const a=this.expr(e.value,s);if(e.operator==='not'){const t=truth(a);return t===U?U:!t;}if(e.operator==='-'&&numeric(a))return -a;if(e.operator==='#'&&typeof a==='string')return a.length;if(e.operator==='#'&&a&&Number.isInteger(a.table))return this.length(a,s);return U;}
   case 'binary':return binary(e.operator,this.expr(e.left,s),this.expr(e.right,s));
   case 'logical':{
    const a=this.expr(e.left,s),t=truth(a);if(t===U){this.markCalls(e.right,s);return U;}
    return e.operator==='and'?(t?this.expr(e.right,s):a):(t?a:this.expr(e.right,s));
   }
   case 'call':{
    // Preserve order in the IR but do not invoke a callee. Unknown calls may
    // change escaped VM tables, so subsequent operand reads cannot be folded.
    s.hazards.add('call-effects-and-results-unmodeled');s.memoryInvalidated=true;return U;
   }
   case 'closure':s.hazards.add('nested-closure-recovery-required');return U;
   case 'table':{
    if(--this.localId< -100000){this.stop(s,'local-table-allocation-budget');return U;}
    const ref=this.ref(this.localId);let index=1;
    for(const field of e.fields){const key=field.array?index++:this.expr(field.key,s),value=this.expr(field.value,s);this.store({base:ref,key},value,s);}
    const last=e.fields.at(-1);if(last?.array&&['call','varargs'].includes(last.value.kind)){s.unknownTables.add(ref.table);s.hazards.add('table-constructor-multiple-results-unmodeled');}
    return ref;
   }
   case 'varargs':return U;
   default:this.stop(s,'unmodeled-expression-'+e.kind);return U;
  }
 }
 markCalls(e,s){if(!e||typeof e!=='object')return;if(e.kind==='closure')return;if(e.kind==='call'){s.hazards.add('conditional-call-effects-unmodeled');s.memoryInvalidated=true;return;}for(const v of Object.values(e)){if(Array.isArray(v))v.forEach(x=>this.markCalls(x,s));else this.markCalls(v,s);}}
 address(target,s){
  if(target.kind==='symbol')return {symbol:target.symbol};
  if(target.kind==='operand-read')return {base:target.baseSymbol?this.expr({kind:'symbol',symbol:target.baseSymbol},s):this.value(this.prototype.get(target.slot)),key:this.expr(target.index,s)};
  if(target.kind==='register-read')return {base:target.baseSymbol?this.expr({kind:'symbol',symbol:target.baseSymbol},s):REG,key:this.expr(target.index,s)};
  if(target.kind==='index')return {base:this.expr(target.base,s),key:this.expr(target.index,s)};
  this.stop(s,'unmodeled-target');return {};
 }
 getAddress(a,s){return a.symbol?this.expr({kind:'symbol',symbol:a.symbol},s):this.read(a.base,a.key,s);}
 store(a,v,s){
  if(a.symbol){if(a.symbol.role==='pc')s.pc=v;else s.locals.set(a.symbol.id,v);return;}
  if(a.base===REG){if(a.key===U){s.hazards.add('unknown-register-write');s.registers.clear();s.registersInitiallyNil=false;}else s.registers.set(a.key,v);return;}
  if(a.base&&Number.isInteger(a.base.table)){
   if(a.base.table>0)s.hazards.add('decoded-table-write-requires-cross-instruction-propagation');
   if(a.key===U){s.unknownTables.add(a.base.table);s.memory.delete(a.base.table);s.hazards.add('unknown-table-key-write');return;}
   if(!s.memory.has(a.base.table))s.memory.set(a.base.table,new Map());s.memory.get(a.base.table).set(a.key,v);return;
  }
  s.hazards.add('write-through-unresolved-alias');s.memoryInvalidated=true;
 }
 values(expressions,count,s){
  const values=expressions.map(e=>this.expr(e,s));
  const tail=expressions.at(-1),multiple=tail&&['call','varargs'].includes(tail.kind);
  return Array.from({length:count},(_,i)=>i<values.length?values[i]:multiple?U:null);
 }
 block(nodes,states){
  let current=states;
  for(const n of nodes){
   current=current.flatMap(s=>s.control?[s]:this.statement(n,s));
   if(current.length>this.options.maxPaths){for(const s of current.slice(0,this.options.maxPaths))this.stop(s,'instruction-path-budget');return current.slice(0,this.options.maxPaths);}
  }
  return current;
 }
 branch(clauses,index,s){
  if(index>=clauses.length)return [s];const c=clauses[index];
  if(c.condition===null)return this.block(c.body,[s]);
  const t=truth(this.expr(c.condition,s));if(s.control==='unresolved')return [s];
  if(t===true)return this.block(c.body,[s]);if(t===false)return this.branch(clauses,index+1,s);
  const yes=clone(s),no=clone(s);return [...this.block(c.body,[yes]),...this.branch(clauses,index+1,no)];
 }
 loop(n,s){
  let active=[s],done=[];
  for(let iteration=0;iteration<this.options.maxIterations;iteration++){
   const next=[];
   for(const state of active){
    if(n.kind==='while'){
     const t=truth(this.expr(n.condition,state));if(t===false){done.push(state);continue;}
     if(t===U){this.stop(state,'unknown-while-condition');done.push(state);continue;}
    }
    for(const r of this.block(n.body,[state])){
     if(r.control==='return'||r.control==='unresolved'){done.push(r);continue;}
     if(r.control==='break'){r.control=null;done.push(r);continue;}
     if(r.control==='continue')r.control=null;
     if(n.kind==='repeat'){
      const t=truth(this.expr(n.condition,r));if(t===true){done.push(r);continue;}
      if(t===U){this.stop(r,'unknown-repeat-condition');done.push(r);continue;}
     }
     next.push(r);
    }
   }
   if(!next.length)return done;
   if(next.length>this.options.maxPaths){next.forEach(r=>this.stop(r,'loop-path-budget'));return [...done,...next.slice(0,this.options.maxPaths)];}
   active=next;
  }
  active.forEach(r=>this.stop(r,'loop-iteration-budget'));return [...done,...active];
 }
 statement(n,s){
  switch(n.kind){
   case 'scope':return this.block(n.body,[s]);
   case 'local':{const v=this.values(n.values,n.targets.length,s);n.targets.forEach((t,i)=>s.locals.set(t.id,v[i]));break;}
   case 'assign':{
    const addresses=n.targets.map(t=>this.address(t,s));let alias=false;
    for(let i=0;i<addresses.length;i++)for(let j=0;j<i;j++){
     const a=addresses[i],b=addresses[j];
     if(a.symbol&&b.symbol&&a.symbol.id===b.symbol.id||!a.symbol&&!b.symbol&&a.base===b.base&&(a.key===b.key||a.key===U||b.key===U))alias=true;
    }
    if(alias){this.stop(s,'aliased-simultaneous-assignment');break;}
    const values=this.values(n.values,addresses.length,s);addresses.forEach((a,i)=>this.store(a,values[i],s));break;
   }
   case 'compound':{const a=this.address(n.target,s),old=this.getAddress(a,s),value=this.expr(n.value,s);this.store(a,binary(n.operator,old,value),s);break;}
   case 'if':return this.branch(n.clauses,0,s);
   case 'call-statement':this.expr(n.call,s);break;
   case 'return':n.values.forEach(v=>this.expr(v,s));if(s.control!=='unresolved')s.control='return';break;
   case 'break':s.control='break';break;
   case 'continue':s.control='continue';break;
   case 'while':case 'repeat':return this.loop(n,s);
   case 'numeric-for':{
    const start=this.expr(n.start,s),end=this.expr(n.end,s),step=this.expr(n.step,s);
    if(![start,end,step].every(numeric)||step===0){this.stop(s,'unknown-numeric-loop-range');break;}
    let states=[s],done=[],count=0;
    for(let i=start;step>0?i<=end:i>=end;i+=step){
     if(++count>this.options.maxIterations){states.forEach(r=>this.stop(r,'numeric-loop-budget'));return [...done,...states];}
     states.forEach(r=>r.locals.set(n.variable.id,i));const result=this.block(n.body,states);states=[];
     for(const r of result){if(r.control==='break'){r.control=null;done.push(r);}else if(r.control==='return'||r.control==='unresolved')done.push(r);else{r.control=null;states.push(r);}}
     if(!states.length)break;
    }
    return [...done,...states];
   }
   case 'generic-for':this.stop(s,'generic-iteration-model-required');break;
   default:this.stop(s,'unmodeled-statement-'+n.kind);
  }
  return [s];
 }
 analyzeInstruction(pc){
  if(!this.ir.simpleOpcodeFetch)return {pc,successors:[],unresolved:['nontrivial-opcode-fetch-prefix'],returns:false};
  const opcode=this.opcodes.get(pc),handler=this.handlers.get(opcode);
  if(!handler)return {pc,opcode,successors:[],unresolved:['opcode-not-specialized'],returns:false};
  this.operations=0;
  const initial={pc,locals:new Map(),registers:new Map(),memory:new Map(),unknownTables:new Set(),hazards:new Set(),memoryInvalidated:false,control:null};
  const paths=this.block(handler.body,[initial]),edges=new Set(),hazards=new Set();let returns=false;
  for(const s of paths){s.hazards.forEach(h=>hazards.add(h));if(s.control==='return')returns=true;
   else if(s.control==='unresolved')continue;
   else if(s.control==='break')hazards.add('frame-loop-exit-needs-wrapper-analysis');
   else if(Number.isSafeInteger(s.pc)&&this.opcodes.has(s.pc))edges.add(s.pc);
   else hazards.add('dynamic-or-out-of-range-program-counter');
  }
  return {pc,opcode,successors:[...edges].sort((a,b)=>a-b),returns,unresolved:[...hazards].sort(),paths:paths.length};
 }
 traceEntry({maxInstructions=1000}={}){
  if(!Number.isInteger(maxInstructions)||maxInstructions<1||maxInstructions>10000)throw Error('Trace instruction limit');
  let state={pc:this.ir.entryPc??U,locals:new Map(),registers:new Map(),registersInitiallyNil:true,memory:new Map(),unknownTables:new Set(),hazards:new Set(),memoryInvalidated:false,control:null};
  for(const symbol of this.ir.symbols)if(symbol.role==='temporary'&&symbol.initialSeed?.known)state.locals.set(symbol.id,symbol.initialSeed.value);
  return this.traceState(state,maxInstructions,false);
 }
 traceState(state,maxInstructions,prepared){
  const trace=[];let stop=this.ir.entryPc===null?'unknown-initial-program-counter':'instruction-budget';
  for(let i=0;i<maxInstructions;i++){
   this.operations=0;
   if(!this.ir.simpleOpcodeFetch){stop='nontrivial-opcode-fetch-prefix';break;}
   if(!Number.isSafeInteger(state.pc)||!this.opcodes.has(state.pc)){stop=this.ir.entryPc===null&&trace.length===0?'unknown-initial-program-counter':'dynamic-or-out-of-range-program-counter';break;}
   if(this.ir.unmodeledPreambleEffects&&!prepared){stop='unmodeled-preamble-effects';break;}
   const pc=state.pc,opcode=this.read(this.ref(this.prototype.get(this.d.read.opcodeSlot).table),pc,state),handler=this.handlers.get(opcode);
   if(!handler){stop='unknown-or-modified-opcode';break;}
   const paths=this.block(handler.body,[state]),hazards=[...new Set(paths.flatMap(p=>[...p.hazards]))];
   trace.push({pc,opcode,paths:paths.length,hazards,possibleSuccessors:[...new Set(paths.filter(p=>!p.control&&Number.isSafeInteger(p.pc)).map(p=>p.pc))]});
   const blockers=hazards.filter(h=>h!=='decoded-table-write-requires-cross-instruction-propagation');
   if(blockers.length){stop=blockers[0];break;}
   if(paths.length!==1){stop='symbolic-branch-frontier';break;}
   state=paths[0];if(state.control==='return'){stop='entry-return';break;}
   if(state.control){stop='frame-control-'+state.control;break;}
  }
  return {status:'bounded-abstract-entry-prefix',fullRecoveryVerified:false,programCallsExecuted:false,stop,trace,
   assumptions:prepared?['State imported from a matching linked namespace and decoded graph.','Choices, environments and unsupported values widen to unknown; calls are not invoked.']:['Fresh VM activation with nil-initialized registers and statically known preamble literals.','Nonliteral preamble values, incoming arguments and environment values remain unknown.'],
   limitations:['This is a bounded prefix, not application source or equivalence verification.','Calls and unknown effects terminate the trace; no uploaded call is invoked.']};
 }
 analyze(){
  const instructions=[...this.opcodes.keys()].sort((a,b)=>a-b).map(pc=>this.analyzeInstruction(pc));
  const nodes=new Map(instructions.map(n=>[n.pc,n])),seen=new Set(),todo=this.ir.entryPc===null?[]:[this.ir.entryPc];
  while(todo.length){const pc=todo.pop();if(seen.has(pc)||!nodes.has(pc))continue;seen.add(pc);todo.push(...nodes.get(pc).successors);}
  return {schema:1,status:'initial-image-cfg-only',fullRecoveryVerified:false,programCallsExecuted:false,
   instructionCount:instructions.length,provisionallyReachable:[...seen].sort((a,b)=>a-b),instructions,
   unresolvedInstructionCount:instructions.filter(i=>i.unresolved.length).length,
   limitations:['Edges describe the initial decoded image, not a verified whole-program CFG.','Predecessor mutations and temporary/register states are not propagated between instructions.','Calls, exception paths, closures and remaining protected stages require further recovery.','Provisionally unreachable instructions are NOT proven dead.']};
 }
}
