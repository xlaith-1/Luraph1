// Derive tag widths from observed bootstrap parser writes, not references or
// plaintext guesses. This validates the constant section before a full replay.
export function readVaruint(buffer,position){
 let value=0;for(let shift=0;shift<35;shift+=7){if(position>=buffer.length)return null;const byte=buffer[position++];value+=(byte&127)*2**shift;if(byte<128)return Number.isSafeInteger(value)?{value,end:position}:null;}return null;
}
export function learnPoolLayout(blob,pool){
 const first=readVaruint(blob,0),writes=pool.primitiveWrites;
 if(!first||!Array.isArray(writes)||writes.length!==pool.length())return null;
 // Reviewed readers store a nil sentinel at index zero, absent in Lua tables.
 let cursor=first.end+1;const tags={};
 for(let i=0;i<writes.length;i++){
  const w=writes[i],value=pool.get(i+1);
  if(w.key!==i+1||w.buffer!==blob||w.end<=cursor||w.end>blob.length)return null;
  const tag=blob[cursor],width=w.end-cursor-1;
  let spec;
  if(typeof value==='string'){
   const len=readVaruint(blob,cursor+1);
   if(!len||len.value!==value.length||len.end+len.value!==w.end||blob.subarray(len.end,w.end).toString('latin1')!==value)return null;
   spec={kind:'string'};
  }else if(typeof value==='boolean'&&width===0)spec={kind:'boolean',width:0};
  else if(typeof value==='number'&&[1,2,4,8].includes(width))spec={kind:'number',width};
  else return null;
  if(tags[tag]&&JSON.stringify(tags[tag])!==JSON.stringify(spec))return null;
  tags[tag]=spec;cursor=w.end;
 }
 return {tags,countBias:first.value-pool.length(),bootstrapConstants:pool.length(),bootstrapPoolEnd:cursor,evidence:'Observed primitive writes and byte spans of the captured bootstrap parser'};
}
export function validatePoolAt(blob,offset,layout){
 const h=readVaruint(blob,offset);if(!h)return null;const count=h.value-layout.countBias;
 if(!Number.isInteger(count)||count<1||count>100000||h.end>=blob.length||layout.tags[blob[h.end]])return null;
 let p=h.end+1,stringCount=0;
 for(let index=1;index<=count;index++){
  if(p>=blob.length)return null;
  const tag=blob[p++],spec=layout.tags[tag];if(!spec)return null;
  if(spec.kind==='string'){
   const n=readVaruint(blob,p);if(!n||n.value>16*1024*1024||n.end+n.value>blob.length)return null;
   stringCount++;p=n.end+n.value;
  }else{p+=spec.width;if(p>blob.length)return null;}
 }
 return {offset,count,end:p,stringCount};
}
export function periodicApplicationCandidates(blob,keyHex,readEnd,layout,poolStart,{minStringEnd=poolStart,deadline=Date.now()+30000}={}){
 if(!layout||!/^[0-9a-f]{16}$/i.test(keyHex))return null;
 const key=Buffer.from(keyHex,'hex'),decoded=Buffer.alloc(blob.length);
 for(let i=0;i<blob.length;i++)decoded[i]=blob[i]^key[i%8];
 const candidates=[];
 for(let offset=readEnd;offset<=Math.min(readEnd+4096,poolStart,decoded.length-8);offset++){
  if(Date.now()>deadline)throw Error('Serialized pool validation deadline');
  const candidate=validatePoolAt(decoded,offset,layout);
  // A complete typed pool must include the independently inferred string run.
  if(candidate&&candidate.stringCount>=100&&candidate.end>=minStringEnd){candidates.push(candidate);if(candidates.length===2)break;}
 }
 // A unique structurally valid constant section is required, not "first hit".
 return {decoded,candidates};
}
