# Readable-source recovery: closed literal-prototype VM subset

This path is **integrated into `worker/luraph-cli.mjs`**, not just a trace exporter.
For supported input, it removes the interpreter and emits application statements,
expressions, calls, returns, and structured `if` branches. It does not use a sample
hash or an opcode-to-source lookup table.

## Run it

From the project directory, after installing the documented dependencies:

```sh
node worker/luraph-cli.mjs input.lua result
```

Successful subset recovery writes:

- `result/standalone.candidate.lua` — readable standalone Lua, not a VM listing.
- `result/report.json` — `partial-source`, with `fullRecoveryVerified: false`.
- `result/luraph.recovery.json` — static recovery counts and limitations.

The existing `?luraph` attachment route selects the candidate before VM/string
fallbacks. This source integration was tested through the real Bubblewrap worker;
**the live Discord bot has not been redeployed or tested in this update**.
Existing exact-profile recovery and string-dump import keep their priority.
Unsupported inputs continue through the existing fallback rather than receiving
an invented function. A failed new analysis never leaves a stale candidate from
a previous job in the same result directory.

## Scope

The input must contain one closed factory with a directly returned vararg VM
frame, called with a literal prototype table. A local factory declaration or an
inline factory expression is supported. Top-level side effects, encrypted tables,
general bootstrap code, and arbitrary wrapper chains are not supported here.
This is **not a claim of general Luraph 14.7/14.8 support**.

The engine resolves a structural opcode/PC/array pattern and symbolically follows
the actual handler AST. It preserves shared PC increments and propagates private
VM table writes between instructions, including a modified opcode at a revisited
PC. Data-dependent branches become structured Lua branches if every analyzed
continuation is supported and terminates within the analysis budget.

Supported cases include private register arrays, constants, bounded concrete
indices, scalar arithmetic, argument handling, simultaneous assignments with
non-aliasing targets, external function/method calls, and multiple/nil/binary
returns. External calls are emitted but **never invoked by the recovery engine**.
Internal VM tables cannot escape through such calls or returns.

Returned reusable closures must not modify persistent factory tables or cells.
One-shot self-modifying wrappers are supported; silently resetting persistent
state on each call would be wrong, so the reusable mutable case is rejected.

Unsupported constructs fail the whole candidate rather than erasing effects:
unknown loops/gotos, recursive factory references, explicit `_ENV` use, escaping
VM tables, dynamic internal-table indices, general expandable table constructors,
unknown short-circuit expressions, duplicate constructor keys, and aliased
simultaneous stores. Existing
initial-image CFG analysis also now rejects aliased simultaneous stores instead
of assuming a left-to-right store order.

Lua arithmetic expressions are retained even when their concrete values guide
control analysis. This avoids replacing Lua floating-point expressions with
integer literals. Generated identifiers avoid names appearing in the input.
The generated local-variable count is conservatively limited.

Defaults: 512 KiB input, 512 instructions per path, 16 dynamic branch splits,
100,000 static analysis operations, and 1 MiB generated output. Runtime calls in
the emitted application retain their original risks and can still fail or hang.
The engine does not certify debug, stack, timing, environment equivalence, or
unseen obfuscator formats.

## Validation for this update

- **245 Node tests passed, zero skips.**
- **64 Python tests: 56 passed, 8 skipped.** Seven skipped tests require other
  built engines; one requires the unavailable IronBrew/.NET runtime. The missing
  runtime is not a successful engine test.
- 19 synthetic programs were run both as original VMs and recovered Lua on
  **Lua 5.4 and LuaJIT**: 38 differential tests. Three additional source-recovery
  tests check rejection, limits, and input-dependent output.
- Cases include renamed/reindexed layouts, non-one entry PCs, data branches,
  self-modifying revisited sites, binary/nil/multiple results, repeated closure
  calls, lexical/name collisions, native metamethods, and method lookup order.
- A worker CLI test checks candidate selection, partial status, fallback skipping,
  and stale-output cleanup. Two Python tests exercise the real isolated worker
  and minimal dependency mounts without forwarding a synthetic token.
- No protected input was executed, no holdout was inspected, and no real encrypted
  application recovery is newly claimed. These are synthetic differential tests,
  not 19 real-world Luraph recoveries.

## Remaining main blocker

General protected-input unpacking and bootstrap/capture integration still need to
provide a trustworthy application prototype and its executable frame semantics.
This new path can recover readable logic when that closed literal representation
is already present; it does not solve that upstream blocker by itself.
