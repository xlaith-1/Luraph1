// Data-only diagnostic. Statistical hints never authorize decoding or output.
export function analyzeRemainder(blob,start){
 if(!Buffer.isBuffer(blob)||!Number.isInteger(start)||start<0||start>blob.length)throw Error('Invalid remainder range');
 const trailingBytes=blob.length-start;
 const result={bootstrapEnd:start,trailingBytes,applicationEncoding:'unconfirmed'};
 if(trailingBytes<8192)return result;
 // Compare disjoint windows, not a sample-specific offset or key.
 const length=Math.min(65536,Math.floor(trailingBytes/3));
 const offsets=[start+Math.floor(trailingBytes/3),blob.length-length];
 for(const period of [2,4,8,16]){
  const windows=offsets.map(begin=>{
   const buckets=Array.from({length:period},()=>new Uint32Array(256));
   for(let i=begin;i<begin+length;i++)buckets[i%period][blob[i]]++;
   return buckets.map(counts=>{let mode=0,total=0;for(let i=0;i<256;i++){total+=counts[i];if(counts[i]>counts[mode])mode=i;}return {mode,share:counts[mode]/total};});
  });
  if(windows[0].some((v,i)=>v.mode!==windows[1][i].mode||v.share<0.12||windows[1][i].share<0.12))continue;
  const modes=windows[0].map(v=>v.mode);
  if(new Set(modes).size<period/2)continue;
  result.periodicBytePattern={period,minimumModeShare:Math.min(...windows.flat().map(v=>v.share)),note:'Repeated byte modes in independent windows; possible periodic masking, not a verified decryption key.'};
  break;
 }
 return result;
}
