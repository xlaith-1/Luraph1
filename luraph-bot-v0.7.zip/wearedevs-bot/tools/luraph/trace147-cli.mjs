#!/usr/bin/env node
// Offline evidence import only; never executes Lua or sends network requests.
import fs from 'node:fs';
import path from 'node:path';
import {VersionedTrace147,typedIRObservation147} from './trace147.mjs';
const [manifestPath,outputPath]=process.argv.slice(2);
if(!manifestPath||!outputPath)throw Error('Usage: node trace147-cli.mjs manifest.json output.json');
function readBounded(p,limit){const stat=fs.statSync(p);if(!stat.isFile()||stat.size>limit)throw Error('Input size/type limit');return fs.readFileSync(p,'utf8');}
const manifest=JSON.parse(readBounded(manifestPath,65536));
if(!Array.isArray(manifest.inputs)||!manifest.inputs.length||manifest.inputs.length>16)throw Error('Expected 1–16 input files');
const tracker=new VersionedTrace147(manifest.identity);
let bytes=0,seq=0,error=null,producerStatus=null;
try{
  for(const input of manifest.inputs){
    if(!['typed-ir-observations','events-jsonl'].includes(input.format))throw Error('Unknown input format');
    const filename=path.resolve(path.dirname(manifestPath),input.path);
    const text=readBounded(filename,16*1024*1024);bytes+=Buffer.byteLength(text);
    if(bytes>32*1024*1024)throw Error('Total input limit');
    for(const line of text.split(/\r?\n/)){
      if(!line.trim())continue;
      if(Buffer.byteLength(line)>65536)throw Error('Input line limit');
      if(input.format==='events-jsonl'){
        const event=JSON.parse(line);tracker.add(event);seq=event.seq+1;
      }else{
        const event=typedIRObservation147(line,manifest.identity.sessionId,seq);
        if(event){tracker.add(event);seq++;}
      }
    }
  }
  if(manifest.producerStatus){
    if(typeof manifest.producerStatus!=='string'||manifest.inputs.some(i=>i.format!=='events-jsonl'))throw Error('Producer status requires a pure event stream');
    producerStatus=JSON.parse(readBounded(path.resolve(path.dirname(manifestPath),manifest.producerStatus),65536));
    if(producerStatus.sessionId!==manifest.identity.sessionId||typeof producerStatus.valid!=='boolean'||!Number.isSafeInteger(producerStatus.events)||producerStatus.events!==tracker.records)throw Error('Producer status/session/count mismatch');
    if(!producerStatus.valid)throw Error('Producer reported a recording failure');
  }
}catch(e){error=e.message;}
const artifact=tracker.finish(error?'import-error':(manifest.stopReason??producerStatus?.stopReason??'producer-ended'));
artifact.producerStatusSupplied=producerStatus!==null;
if(error){artifact.valid=false;artifact.error=error;artifact.edges=[];}
artifact.inputs=manifest.inputs.map(i=>({format:i.format,name:path.basename(i.path)}));
const encoded=JSON.stringify(artifact,null,2)+'\n';
if(Buffer.byteLength(encoded)>64*1024*1024)throw Error('Output limit');
fs.mkdirSync(path.dirname(path.resolve(outputPath)),{recursive:true});
const temporary=outputPath+'.'+process.pid+'.tmp';
fs.writeFileSync(temporary,encoded,{flag:'wx',mode:0o600});fs.renameSync(temporary,outputPath);
console.log(JSON.stringify({valid:artifact.valid,records:artifact.records,sites:artifact.instructionSites,versions:artifact.instructionVersions,multiVersionSites:artifact.multiVersionSites,edges:artifact.edges.length,error:artifact.error}));
if(!artifact.valid)process.exitCode=1;
