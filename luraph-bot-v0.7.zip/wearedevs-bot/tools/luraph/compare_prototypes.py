import json,math
from pathlib import Path
import sys
RESULTS=Path(sys.argv[1])
raw=json.loads((RESULTS/'original-prototypes-graph.json').read_text());nodes={}
def build(x):
 if not isinstance(x,dict):return x
 if 'number' in x:return float(x['number'])
 if 'ref' in x:return ('ref',x['ref'])
 if 'entries' in x:
  obj={};nodes[x['id']]=obj
  for k,v in x['entries']:obj[build(k)]=build(v)
  return ('ref',x['id'])
 return x
root=build(raw)
def deref(x):return nodes[x[1]] if isinstance(x,tuple) and x[0]=='ref' else x
root=deref(root);records=json.load(open(RESULTS/'prototypes.json')); constants=json.load(open(RESULTS/'constants.json'))
protos={}
for ident,t in nodes.items():
 if all(k in t for k in [1,2,3,4,5,6,7,8,9,10,11]) and isinstance(t[1],float):
  ops=deref(t[10]);
  if not isinstance(ops,dict):continue
  matches=[p for p in records['prototypes'] if len(p['instructions'])==len(ops) and all(o['opcode']==ops.get(o['pc']) for o in p['instructions'])]
  if len(matches)==1:protos[matches[0]['id']]=(ident,t)
for p in records['prototypes']:
 if p['id'] not in protos:continue
 _,t=protos[p['id']]
 for o in p['instructions']:
  for a,slot in zip(o['operands'],[9,8,11]):
   if a['tag']==5:
    ref=deref(t[slot]).get(o['pc']);ident=ref[1]
    if a['value'] in protos:assert protos[a['value']][0]==ident
    else:protos[a['value']]=(ident,nodes[ident])
assert len(protos)==55,len(protos)
checks=0
for p in records['prototypes']:
 ident,t=protos[p['id']]
 assert t[1]==p['registers'];assert t[3]==p['flag'];checks+=2
 cap=deref(t[6]);assert len(cap)==len(p['captures']);checks+=1
 for j,c in enumerate(p['captures'],1):assert deref(cap[j])=={2:c['index'],3:c['kind']};checks+=1
 assert deref(t[2])=={int(k):v for k,v in p['lines'].items()};checks+=1
 for o in p['instructions']:
  pc=o['pc']
  for operand,slot,cslot in zip(o['operands'],[5,4,7],[9,8,11]):
   tag,v=operand['tag'],operand['value'];expected=pc+v if tag==0 else pc-v if tag==7 else v
   assert deref(t[slot]).get(pc)==expected,(p['id'],pc,slot,deref(t[slot]).get(pc),expected);checks+=1
   if tag==3:
    want=constants[v-1]['value'];actual=deref(t[cslot]).get(pc)
    assert actual==want or isinstance(want,float) and math.isnan(want) and math.isnan(actual),(p['id'],pc,cslot,actual,want);checks+=1
   elif tag==5:
    assert deref(t[cslot]).get(pc)==('ref',protos[v][0]),(p['id'],pc,cslot,v);checks+=1
assert root['prototype']==('ref',protos[records['entry']][0]);checks+=1
print('PASS',len(protos),'prototypes;',checks,'field comparisons')
(RESULTS/'prototype-validation.json').write_text(json.dumps({'prototypesMatched':len(protos),'fieldComparisons':checks,'originalDeserializerExecutedOffline':True,'payloadExecuted':False,'networkAvailable':False,'filesystemAvailableToLua':False},indent=2))
