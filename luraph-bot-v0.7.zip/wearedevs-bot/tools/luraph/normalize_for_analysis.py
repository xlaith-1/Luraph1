"""Research-only syntax adapter. Output is NOT equivalent executable source:
continue becomes a marker call solely to retain AST branch positions.
Never return this artifact as recovered source or execute it.
"""
from pathlib import Path
import re,json,sys
s=Path(sys.argv[1]).read_text('latin1');parts=[];i=0
while i<len(s):
 if s.startswith('--',i):
  m=re.match(r'--\[(=*)\[',s[i:])
  if m:
   end=s.index(']'+m[1]+']',i+len(m[0]))+len(m[1])+2
  else:
   end=s.find('\n',i);end=len(s) if end<0 else end
  parts.append(' ');i=end;continue
 m=re.match(r'\[(=*)\[',s[i:])
 if m:
  close=s.index(']'+m[1]+']',i+len(m[0]));end=close+len(m[1])+2
  text=s[i+len(m[0]):close].replace('\r\n','\n').replace('\r','\n')
  if text.startswith('\n'):text=text[1:]
  parts.append('"'+''.join('\\%03d'%ord(v) for v in text)+'"');i=end;continue
 if s[i] in '\"\'':
  q=s[i];i+=1;b=bytearray()
  while s[i]!=q:
   c=s[i];i+=1
   if c!='\\':b.extend(c.encode('latin1'));continue
   c=s[i];i+=1
   if c=='z':
    while i<len(s) and s[i].isspace():i+=1
   elif c=='x':b.append(int(s[i:i+2],16));i+=2
   elif c=='u':
    assert s[i]=='{';j=s.index('}',i);b.extend(chr(int(s[i+1:j],16)).encode('utf8'));i=j+1
   elif c.isdigit():
    m=re.match('[0-9]{0,2}',s[i:])[0];i+=len(m);b.append(int(c+m))
   else:b.extend({'a':b'\a','b':b'\b','f':b'\f','n':b'\n','r':b'\r','t':b'\t','v':b'\v'}.get(c,c.encode('latin1')))
  i+=1;parts.append('"'+''.join('\\%03d'%v for v in b)+'"');continue
 m=re.match(r'(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|[0-9][0-9_]*(?:\.[0-9_]+)?(?:[eE][+-]?[0-9_]+)?)',s[i:])
 if m:
  val=m[0].replace('_','');parts.append(str(int(val,0)) if val.lower().startswith(('0x','0b')) else val);i+=len(m[0]);continue
 m=re.match('[A-Za-z_][A-Za-z_0-9]*',s[i:])
 if m:
  if m[0]=='__analysis_continue':raise ValueError('Reserved analysis marker appears in original code')
  parts.append('__analysis_continue()' if m[0]=='continue' else m[0]);i+=len(m[0]);continue
 parts.append(s[i]);i+=1
s=''.join(parts)
if '--preserve-compound' not in sys.argv[3:]:
 s=re.sub(r'\b([A-Za-z_]\w*)\s*([+*/%-])=([^;]+);',lambda m:m[1]+'='+m[1]+m[2]+'('+m[3]+');',s)
s=re.sub(r'\bbreak\s*;', 'break ', s)
Path(sys.argv[2]).write_text(s)
