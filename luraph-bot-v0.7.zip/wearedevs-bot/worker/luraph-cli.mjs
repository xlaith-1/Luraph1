#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {analyzeLuraph} from './luraph.mjs';
import {importStringDump} from './luraph-string-dump.mjs';
import {recoverLiteral147} from '../tools/luraph/recover-literal147.mjs';
try {
  const [input,out,python]=process.argv.slice(2);
  if(!input||!out)throw Error('Usage: node worker/luraph-cli.mjs input.lua output-directory');
  const stat=fs.statSync(input);if(!stat.isFile()||stat.size>524288)throw Error('Invalid input size/type');
  const bytes=fs.readFileSync(input);
  const source=bytes.toString('latin1');
  fs.mkdirSync(out,{recursive:true});
  for(const name of ['recovered.lua','standalone.candidate.lua','luraph.constants.json','luraph.prototypes.json','luraph.recovery.json','report.json','strings.inventory.lua','strings.cleaned.txt','strings.json','unpacked.vm.lua','unpacked.bytecode.bin','unpack.report.json'])fs.rmSync(path.join(out,name),{force:true});
  const imported=importStringDump(bytes);
  let result;
  try{result=imported??analyzeLuraph(source)}catch{result={report:{status:'unsupported'},artifacts:{}}}
  if(!imported&&!result.artifacts['recovered.lua']&&!result.artifacts['standalone.candidate.lua']){
    const recovered=recoverLiteral147(source);
    if(recovered.source){
      const report={...recovered.report,status:'partial-source',structuredSourceRecovered:true,
        executedUploadedCode:false,fullRecoveryVerified:false,
        notes:['Closed literal-prototype VM subset reconstructed statically; not general Luraph support.'],
        sourceFile:'standalone.candidate.lua'};
      result={report,artifacts:{...result.artifacts,
        'standalone.candidate.lua':recovered.source,
        'luraph.recovery.json':JSON.stringify(recovered.report,null,2),
        'report.json':JSON.stringify(report,null,2)}};
    }
  }
  const {report,artifacts}=result;
  if(imported)process.stderr.write('LURAPH_ARTIFACT_STRINGS_ONLY\n');
  for(const [name,text] of Object.entries(artifacts))fs.writeFileSync(path.join(out,name),text,{mode:0o600});
  if(!imported && python && !['recovered.lua','standalone.candidate.lua'].some(n=>fs.existsSync(path.join(out,n)))) {
    try {
      execFileSync(python,['/opt/engines/luraph-unpack.py',input,out],{stdio:['ignore','pipe','pipe'],maxBuffer:262144,timeout:Math.max(1000,(Number(process.env.ENGINE_TIMEOUT_SECONDS)||900)*1000-1000)});
    } catch { process.stderr.write('LURAPH_STATIC_UNPACK_UNSUPPORTED\n'); }
  }
  process.stdout.write(JSON.stringify({ok:true,status:report.status,artifacts:Object.keys(artifacts)}));
}catch(e){process.stderr.write(JSON.stringify({ok:false,error:String(e.message).slice(0,300)}));process.exitCode=1;}
