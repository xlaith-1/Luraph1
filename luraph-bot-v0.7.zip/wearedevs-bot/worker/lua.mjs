import luaparse from 'luaparse';
export function parse(source) { return luaparse.parse(source, {luaVersion:'5.1', encodingMode:'pseudo-latin1', ranges:true, comments:false}); }
export function walk(node, fn) {
  if (!node || typeof node !== 'object') return;
  if (node.type) fn(node);
  for (const [k,v] of Object.entries(node)) { if (k === 'range') continue; if(Array.isArray(v)) v.forEach(x=>walk(x,fn)); else if(v && typeof v==='object') walk(v,fn); }
}
export function quote(value) {
  let s='"'; for(const c of value) {const n=c.charCodeAt(0); s += n===34?'\\"':n===92?'\\\\':n<32||n>126?'\\'+String(n).padStart(3,'0'):c;} return s+'"';
}
export function literal(v) {
  if(v===null || v===undefined) return {type:'NilLiteral',value:null};
  if(typeof v==='string') return {type:'StringLiteral',value:v};
  if(typeof v==='boolean') return {type:'BooleanLiteral',value:v};
  if(typeof v==='number' && Number.isFinite(v)) return {type:'NumericLiteral',value:v};
  throw Error('Not a literal');
}
const KEYWORDS=new Set(['and','break','do','else','elseif','end','false','for','function','if','in','local','nil','not','or','repeat','return','then','true','until','while']);
function prefix(n){return ['Identifier','IndexExpression','MemberExpression','CallExpression'].includes(n.type)?expr(n):'('+expr(n)+')';}
export function expr(n) {
  if(!n) return 'nil';
  switch(n.type) {
    case 'Identifier': return n.name;
    case 'NumericLiteral': return String(n.value);
    case 'StringLiteral': return quote(n.value);
    case 'BooleanLiteral': return n.value?'true':'false';
    case 'NilLiteral': return 'nil';
    case 'VarargLiteral': return '...';
    case 'UnaryExpression': return '('+n.operator+(n.operator==='not'?' ':'')+expr(n.argument)+')';
    case 'BinaryExpression': case 'LogicalExpression': return '('+expr(n.left)+' '+n.operator+' '+expr(n.right)+')';
    case 'IndexExpression': return prefix(n.base)+(n.index.type==='StringLiteral'&&/^[A-Za-z_]\w*$/.test(n.index.value)&&!KEYWORDS.has(n.index.value)?'.'+n.index.value:'['+expr(n.index)+']');
    case 'MemberExpression': return prefix(n.base)+n.indexer+n.identifier.name;
    case 'CallExpression': return prefix(n.base)+'('+n.arguments.map(expr).join(', ')+')';
    case 'StringCallExpression': return '('+expr(n.base)+')('+expr(n.argument)+')';
    case 'TableCallExpression': return '('+expr(n.base)+')('+expr(n.arguments)+')';
    case 'TableConstructorExpression': return '{'+n.fields.map(f=>f.type==='TableValue'?expr(f.value):f.type==='TableKeyString'?f.key.name+' = '+expr(f.value):'['+expr(f.key)+'] = '+expr(f.value)).join(', ')+'}';
    case 'FunctionDeclaration': return 'function('+n.parameters.map(expr).join(', ')+')\n'+body(n.body,1)+'\nend';
    default: throw Error('Unsupported Lua expression: '+n.type);
  }
}
function functionName(n){return n.type==='Identifier'?n.name:functionName(n.base)+n.indexer+n.identifier.name;}
export function stmt(n,depth=0) {
  const pad='    '.repeat(depth), sub=b=>body(b,depth+1), e=n=>expr(n).replace(/\n/g,'\n'+pad); let s;
  switch(n.type) {
    case 'LocalStatement': s='local '+n.variables.map(expr).join(', ')+(n.init.length?' = '+n.init.map(e).join(', '):''); break;
    case 'AssignmentStatement': s=n.variables.map(expr).join(', ')+' = '+n.init.map(e).join(', '); break;
    case 'CallStatement': s=e(n.expression);break;
    case 'ReturnStatement': s='return'+(n.arguments.length?' '+n.arguments.map(e).join(', '):'');break;
    case 'BreakStatement': s='break';break;
    case 'DoStatement': s='do\n'+sub(n.body)+'\n'+pad+'end';break;
    case 'WhileStatement': s='while '+e(n.condition)+' do\n'+sub(n.body)+'\n'+pad+'end';break;
    case 'RepeatStatement': s='repeat\n'+sub(n.body)+'\n'+pad+'until '+e(n.condition);break;
    case 'ForNumericStatement': s='for '+expr(n.variable)+' = '+expr(n.start)+', '+expr(n.end)+(n.step?', '+expr(n.step):'')+' do\n'+sub(n.body)+'\n'+pad+'end';break;
    case 'ForGenericStatement': s='for '+n.variables.map(expr).join(', ')+' in '+n.iterators.map(expr).join(', ')+' do\n'+sub(n.body)+'\n'+pad+'end';break;
    case 'IfStatement': s=n.clauses.map((c,i)=>(i?pad:'')+(c.type==='ElseClause'?'else':(i?'elseif ':'if ')+e(c.condition)+' then')+'\n'+sub(c.body)).join('\n')+'\n'+pad+'end';break;
    case 'FunctionDeclaration': s=(n.isLocal?'local ':'')+'function '+functionName(n.identifier)+'('+n.parameters.map(expr).join(', ')+')\n'+sub(n.body)+'\n'+pad+'end';break;
    default: throw Error('Unsupported Lua statement: '+n.type);
  }
  // Semicolons prevent a following parenthesized call being parsed as a continuation.
  if(['LocalStatement','AssignmentStatement','CallStatement'].includes(n.type)) s+=';';
  return pad+s;
}
export function body(nodes,depth=0) { return nodes.map(n=>stmt(n,depth)).join('\n'); }
export const truth=v=>v!==false && v!==null && v!==undefined;
export function binary(op,a,b) {
  switch(op){case '+':return a+b;case '-':return a-b;case '*':return a*b;case '/':return a/b;case '%':return ((a%b)+b)%b;case '^':return a**b;case '..':return String(a)+String(b);case '<':return a<b;case '>':return a>b;case '<=':return a<=b;case '>=':return a>=b;case '==':return a===b;case '~=':return a!==b;case 'and':return truth(a)?b:a;case 'or':return truth(a)?a:b;default:throw Error('Unsupported operator');}
}
export function constant(n) {
  if(!n) return {ok:false};
  if(['NumericLiteral','StringLiteral','BooleanLiteral','NilLiteral'].includes(n.type)) return {ok:true,value:n.value};
  if(n.type==='UnaryExpression') {const a=constant(n.argument); if(a.ok){if(n.operator==='-'&&typeof a.value==='number')return {ok:true,value:-a.value};if(n.operator==='not')return {ok:true,value:!truth(a.value)};if(n.operator==='#'&&typeof a.value==='string')return {ok:true,value:a.value.length};}}
  if(['BinaryExpression','LogicalExpression'].includes(n.type)){const a=constant(n.left),b=constant(n.right);if(a.ok&&b.ok){const numeric=['+','-','*','/','%','^'];if(numeric.includes(n.operator)&&!(typeof a.value==='number'&&typeof b.value==='number'))return {ok:false};if(['<','>','<=','>='].includes(n.operator)&&(typeof a.value!==typeof b.value||!['string','number'].includes(typeof a.value)))return {ok:false};if(n.operator==='..'&&![a.value,b.value].every(v=>['string','number'].includes(typeof v)))return {ok:false};const v=binary(n.operator,a.value,b.value);if(typeof v==='number'&&(!Number.isFinite(v)||Math.abs(v)>Number.MAX_SAFE_INTEGER))return {ok:false};return {ok:true,value:v};}}
  return {ok:false};
}
export function fold(ast) {let count=0;walk(ast,n=>{if(['UnaryExpression','BinaryExpression','LogicalExpression'].includes(n.type)){const v=constant(n);if(v.ok){for(const k of Object.keys(n))delete n[k];Object.assign(n,literal(v.value));count++;}}});return count;}
