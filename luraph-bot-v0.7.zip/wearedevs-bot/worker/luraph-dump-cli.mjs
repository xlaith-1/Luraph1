#!/usr/bin/env node
// Runtime dumping route, not original-source reconstruction.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {importStringDump} from './luraph-string-dump.mjs';
import {SAMPLE_SHA256,recoverReviewedCandidate} from './luraph-reviewed-aaf25cc.mjs';
import {instrument147} from '../tools/luraph/instrument147.mjs';
const tools=fileURLToPath(new URL('../tools/luraph/',import.meta.url));
function quote(s){return '"'+[...s].map(c=>{const n=c.charCodeAt(0);return n>=32&&n<127&&n!==34&&n!==92?c:'\\'+String(n).padStart(3,'0');}).join('')+'"';}
function lua(v,depth=0){
 if(depth>20)throw Error('Dump nesting limit');
 if(v==null)return 'nil';if(typeof v==='string')return quote(v);if(typeof v==='number'||typeof v==='boolean')return String(v);
 if(v?.type==='bytes'&&typeof v.hex==='string'&&/^(?:[0-9a-f]{2})*$/.test(v.hex))v={type:'string',value:Buffer.from(v.hex,'hex').toString('latin1')};
 if(Array.isArray(v))return '{'+v.map(x=>lua(x,depth+1)).join(', ')+'}';
 return '{'+Object.entries(v).map(([k,x])=>'['+quote(k)+'] = '+lua(x,depth+1)).join(', ')+'}';
}
function readable(source){
 const ast=lp.parse(source,{luaVersion:'5.3',ranges:true,encodingMode:'pseudo-latin1'}),points=new Map();
 function mark(pos,depth){points.set(pos,Math.min(depth,points.get(pos)??depth));}
 function walk(n,depth=0){if(!n||typeof n!=='object')return;
  for(const [k,v] of Object.entries(n)){
   if(['range','comments'].includes(k))continue;
   if(k==='body'&&Array.isArray(v)){for(const statement of v){mark(statement.range[0],depth);walk(statement,depth+1);}}
   else if(Array.isArray(v))v.forEach(x=>walk(x,depth));else if(v&&typeof v==='object')walk(v,depth);
  }
  if(['FunctionDeclaration','IfStatement','DoStatement','WhileStatement','ForNumericStatement','ForGenericStatement'].includes(n.type)&&n.range&&source.slice(n.range[1]-3,n.range[1])==='end')mark(n.range[1]-3,Math.max(0,depth-1));
 }
 walk(ast);let result=source;for(const [pos,depth]of [...points].sort((a,b)=>b[0]-a[0]))result=result.slice(0,pos)+'\n'+'  '.repeat(Math.min(depth,30))+result.slice(pos);
 const check=lp.parse(result,{luaVersion:'5.3',ranges:true,encodingMode:'pseudo-latin1'});
 const normalized=x=>JSON.stringify(x,(k,v)=>['range','comments'].includes(k)?undefined:v);
 if(normalized(check)!==normalized(ast))throw Error('Formatter AST changed');return result;
}
const [input,out,python]=process.argv.slice(2);
try{
 if(!input||!out||!fs.statSync(input).isFile()||fs.statSync(input).size>524288)throw Error('Invalid input');
 fs.mkdirSync(out,{recursive:true});
 const report={status:'partial-analysis',engine:'luraph-runtime-dumper/0.1',fullRecoveryVerified:false,thirdPartyUpload:false,runtimeAttempted:false,records:0,notes:[]};
 const start=Date.now(),deadline=start+Math.min(1800,Math.max(1,Number(process.env.ENGINE_TIMEOUT_SECONDS)||900))*1000;
 const files=['application.candidate.lua','application.evidence.json','analysis-only.lua','report.json','luraph.dump.lua','readable.vm.lua','runtime.records.jsonl','runtime.instrumented.lua','runtime.capture-plan.json','runtime.report.json','unpacked.vm.lua','unpacked.bytecode.bin','unpack.report.json','strings.inventory.lua','strings.json','strings.cleaned.txt'];
 for(const name of files)fs.rmSync(path.join(out,name),{force:true});
 const inputBytes=fs.readFileSync(input);report.inputSha256=createHash('sha256').update(inputBytes).digest('hex');
 const imported=importStringDump(inputBytes);
 if(imported){for(const [name,text]of Object.entries(imported.artifacts))fs.writeFileSync(path.join(out,name),text,{mode:0o600});process.stderr.write('LURAPH_ARTIFACT_STRINGS_ONLY\n');process.stdout.write(JSON.stringify({ok:true,status:'strings-only',artifacts:Object.keys(imported.artifacts)}));process.exit(0);}
 if(report.inputSha256===SAMPLE_SHA256){
  const analysis=path.join(out,'analysis-only.lua');
  execFileSync(python||'python3',[path.join(tools,'normalize_for_analysis.py'),input,analysis,'--preserve-compound'],{timeout:10000,maxBuffer:262144,stdio:['ignore','pipe','pipe']});
  const candidate=recoverReviewedCandidate(inputBytes,fs.readFileSync(analysis,'utf8'));
  fs.rmSync(analysis,{force:true});
  fs.writeFileSync(path.join(out,'application.candidate.lua'),candidate.source,{mode:0o600});
  fs.writeFileSync(path.join(out,'application.evidence.json'),JSON.stringify(candidate.report,null,2),{mode:0o600});
  fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(candidate.report,null,2),{mode:0o600});
  fs.writeFileSync(path.join(out,'luraph.dump.lua'),'-- Captured application prototype and candidate-analysis evidence.\n-- NOT a native runtime dump or verified source reconstruction.\nreturn '+lua({report:candidate.report,capture:candidate.capture})+'\n',{mode:0o600});
  process.stdout.write(JSON.stringify({ok:true,status:'application-candidate',fullRecoveryVerified:false,artifacts:['application.candidate.lua','luraph.dump.lua','application.evidence.json']}));process.exit(0);
 }
 let source=inputBytes.toString('latin1'),bytecode;
 if(python){try{
  execFileSync(python,['/opt/engines/luraph-unpack.py',input,out],{timeout:Math.max(1000,deadline-Date.now()-5000),maxBuffer:262144,stdio:['ignore','pipe','pipe']});
  const vm=path.join(out,'unpacked.vm.lua');if(fs.existsSync(vm)&&fs.statSync(vm).size<=2*1024*1024){source=fs.readFileSync(vm,'latin1');bytecode=path.join(out,'unpacked.bytecode.bin');if(!fs.existsSync(bytecode))bytecode=undefined;}
 }catch{report.notes.push('Static unpacking unavailable; trying the supplied Lua directly.');}}
 const runtimeSource=source;
 try{source=readable(source);report.formatted=true;}catch{report.formatted=false;report.notes.push('Formatting unavailable; original input will not be returned as readable output.');}

 // Write a valid checkpoint before any runtime attempt.
 const target=path.join(out,'luraph.dump.lua');
 const save=rows=>{fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));if(!rows.length){fs.rmSync(target,{force:true});return;}const text='-- LURAPH RUNTIME DUMP: partial captured data, not original source.\n-- See readable.vm.lua for the interpreter. No capture-coverage guarantee.\nreturn {\n  report = '+lua(report)+',\n  records = {\n'+rows.join('\n')+'\n  }\n}\n';const temp=target+'.tmp';fs.writeFileSync(temp,text,{mode:0o600});fs.renameSync(temp,target);};
 save([]);
 try{
  const instrumented=instrument147(runtimeSource);
  fs.writeFileSync(path.join(out,'runtime.instrumented.lua'),instrumented.source,{encoding:'latin1',mode:0o600});
  fs.writeFileSync(path.join(out,'runtime.capture-plan.json'),JSON.stringify(instrumented.report,null,2));
  report.captureSites=instrumented.report.sites.length;report.preparedVmSha256=instrumented.report.sourceSha256;report.layouts=instrumented.report.sites;
  if(process.env.LURAPH_ISOLATED!=='1')throw Error('Runtime disabled: invoke through the isolated bot worker.');
  report.runtimeAttempted=true;save([]);
  const runtime=fs.existsSync('/usr/bin/luajit')?'/usr/bin/luajit':'/usr/bin/lua5.4';
  try{execFileSync(runtime,[path.join(tools,'runtime-dump.lua'),path.join(tools,'trace147-recorder.lua'),path.join(out,'runtime.instrumented.lua'),path.join(out,'runtime.records.jsonl'),...(bytecode?[bytecode]:[])],{timeout:Math.max(1000,deadline-Date.now()-3000),killSignal:'SIGKILL',maxBuffer:262144,stdio:['ignore','pipe','pipe']});}
  catch{report.notes.push('Runtime stopped, timed out, or rejected this syntax. Available flushed records retained.');}
 }catch(e){report.notes.push(String(e.message).slice(0,250));}
 const raw=path.join(out,'runtime.records.jsonl'),rows=[];let bytes=0;report.capturedRecords=0;
 if(fs.existsSync(raw)&&fs.statSync(raw).size<=4194304){
  for(const line of fs.readFileSync(raw,'utf8').split('\n')){
   if(!line)continue;
   try{const record=JSON.parse(line);const row='    '+lua(record)+',';if(bytes+row.length>5*1024*1024){report.notes.push('Readable dump size limit; remaining records omitted.');break;}bytes+=row.length;rows.push(row);report.records++;if(['prototype','function-bytecode','step','printed-value','enter'].includes(record.kind))report.capturedRecords++;if(record.kind==='runtime-status')report.runtimeStatus=record;}
   catch{report.notes.push('An incomplete record was omitted.');break;}
  }
 }
 report.captureStatus=report.capturedRecords?'partial-runtime-dump':'no-captured-data';
 if(report.capturedRecords&&report.formatted)fs.writeFileSync(path.join(out,'readable.vm.lua'),'-- VM / UNPACKED LUA: not reconstructed application source.\n'+source,{encoding:'latin1',mode:0o600});
 if(!report.capturedRecords){report.status='unsupported';report.notes.push('No functions, constants or instructions captured. Original input and empty dump are not deliverables.');}
 if(!report.runtimeStatus)report.notes.push('No terminal runtime status; capture completeness is unknown.');
 save(report.capturedRecords?rows:[]);fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2));fs.writeFileSync(path.join(out,'runtime.report.json'),JSON.stringify(report,null,2));
 if(!report.capturedRecords){process.stderr.write('LURAPH_NO_CAPTURE\n');process.exitCode=2;}
 process.stdout.write(JSON.stringify({ok:!!report.capturedRecords,status:report.status,artifacts:report.capturedRecords?['luraph.dump.lua',...(report.formatted?['readable.vm.lua']:[])]:[],records:report.records,capturedRecords:report.capturedRecords}));
}catch(e){process.stderr.write(JSON.stringify({ok:false,error:String(e.message).slice(0,250)}));process.exitCode=1;}
