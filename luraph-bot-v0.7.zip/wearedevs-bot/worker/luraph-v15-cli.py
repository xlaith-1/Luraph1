"""Fixed, OS-isolated adapter for the supplied Luraph v15 devirtualizer.
Unlike the constant route, this engine executes instrumented input in a fake
Roblox environment. Never call it outside the networkless Bubblewrap worker.
"""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ENGINE = Path('/opt/engines/luraph-v15')


def main():
    if os.environ.get('LURAPH_ISOLATED') != '1' or not ENGINE.is_dir():
        raise RuntimeError('V15_ISOLATION_REQUIRED')
    if len(sys.argv) != 3:
        raise ValueError('V15_INVALID_ARGUMENTS')
    source_path, output_dir = map(Path, sys.argv[1:])
    if source_path.resolve() != Path('/job/input.lua') or output_dir.resolve() != Path('/job/result'):
        raise ValueError('V15_INVALID_PATHS')
    if not source_path.is_file() or source_path.stat().st_size > 8388608:
        raise ValueError('V15_INPUT_LIMIT')
    output_dir.mkdir(exist_ok=True)
    for name in ('v15.application.lua', 'v15.trace.lua', 'report.json'):
        (output_dir / name).unlink(missing_ok=True)
    raw = source_path.read_bytes()
    source = raw.decode('latin-1')
    report = dict(engine='luraph-v15-adapter/0.7', status='detecting',
                  inputSha256=hashlib.sha256(raw).hexdigest(),
                  fullRecoveryVerified=False, instrumentedInputExecuted=False,
                  networkAccess=False, thirdPartyUpload=False)

    def save():
        tmp = output_dir / 'report.json.tmp'
        tmp.write_text(json.dumps(report, indent=2))
        tmp.replace(output_dir / 'report.json')

    save()
    sys.path.insert(0, str(ENGINE))
    from obfuscators.luraph_v15 import LuraphV15, restore_header_newline
    from obfuscators.luraph_v15 import vmmap
    from obfuscators.base import Job
    from deob import parser
    plugin = LuraphV15()
    confidence = plugin.detect(source)
    report['detectionConfidence'] = confidence
    if confidence < .5:
        raise ValueError('V15_UNSUPPORTED_INPUT')
    # A version banner alone never authorizes dynamic execution.
    fixed = restore_header_newline(source)
    analysis_path = output_dir / 'normalized-input.lua'
    analysis_path.write_bytes(fixed.encode('latin-1'))
    tree = vmmap.load_ast(str(analysis_path))
    makers, dispatchers = vmmap.maker_info(tree), vmmap.find_dispatchers(tree)
    report.update(vmMakers=len(makers), dispatchers=len(dispatchers))
    if not makers or not dispatchers:
        save()
        raise ValueError('V15_UNSUPPORTED_STRUCTURE')
    report['status'] = 'structure-validated'
    save()
    seconds = min(1800, max(5, int(os.environ.get('ENGINE_TIMEOUT_SECONDS', '900'))))
    args = parser().parse_args([str(source_path), '--obfuscator', 'luraph_v15',
                               '--no-pypy', '--timeout', str(min(90, seconds)),
                               '--budget', str(min(30, max(1, seconds - 2)))])
    # There is no user-controlled --cfg, --studio, runtime executable or URL.
    work = output_dir / 'v15-work'
    work.mkdir(exist_ok=True)
    published = set()

    def publish(path):
        path = Path(path)
        kind = 'application' if path.name.endswith('.devirt.luau') else 'trace'
        data = path.read_bytes()
        if not data.strip() or len(data) > 5 * 1024 * 1024 or b'\x00' in data:
            return False
        if data.strip() in (raw.strip(), fixed.encode('latin-1').strip()):
            return False
        try:
            ast = vmmap.load_ast(str(path))
            if not ast.get('body'):
                return False
            # Reject VM-only output; this command returns lifted code or traces.
            if vmmap.find_dispatchers(ast):
                return False
            checked = subprocess.run([str(ENGINE / 'runtime/luau-compile'), '--null', str(path)],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=20)
            if checked.returncode:
                return False
        except (SyntaxError, ValueError, subprocess.TimeoutExpired):
            return False
        header = ('-- PARTIAL ' + ('devirtualized application candidate' if kind == 'application' else 'observed-behaviour trace') + '. Not verified complete or equivalent.\n'
                  '-- Instrumented input ran in a fake Roblox environment inside a networkless OS sandbox.\n')
        final = output_dir / ('v15.' + kind + '.lua')
        tmp = final.with_suffix('.tmp')
        tmp.write_bytes(header.encode() + data)
        tmp.replace(final)
        published.add(kind)
        report.update(status='partial-output', syntaxChecked=True,
                      availableArtifacts=sorted(published), fullRecoveryVerified=False)
        save()
        return True

    class CheckpointJob(Job):
        def write(self, path, text, encoding='utf-8'):
            result = super().write(path, text, encoding)
            if path == self.trace_path or path.endswith('.devirt.luau'):
                publish(path)
            return result

    job = CheckpointJob(str(source_path), source, args, str(work / 'capture.deobf.luau'), False, plugin.label)
    report.update(status='running-isolated-capture', instrumentedInputExecuted=True)
    save()
    try:
        result = plugin.deobfuscate(job)
        if result and not publish(result):
            # Upstream may deliberately choose trace over a broken lift.
            if str(result) == job.trace_path:
                (output_dir / 'v15.application.lua').unlink(missing_ok=True)
            raise ValueError('V15_NO_VALIDATED_OUTPUT')
        if str(result) == job.trace_path:
            (output_dir / 'v15.application.lua').unlink(missing_ok=True)
            published.discard('application')
        if not published:
            raise ValueError('V15_NO_VALIDATED_OUTPUT')
        report.update(status='partial-complete', availableArtifacts=sorted(published))
        save()
        print(json.dumps({'ok': True, 'partial': True, 'artifacts': sorted(published)}))
    except BaseException:
        report['status'] = 'error-with-checkpoint' if published else 'failed'
        save()
        raise


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        # Never echo arbitrary source/error content into Discord diagnostics.
        tag = str(exc) if str(exc).startswith('V15_') else 'V15_CAPTURE_FAILED'
        print(tag, file=sys.stderr)
        sys.exit(2)
