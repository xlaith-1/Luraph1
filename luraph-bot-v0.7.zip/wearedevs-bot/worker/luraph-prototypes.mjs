// Static serializer reconstruction for the reviewed v14.8 sample. These are
// VM function RECORDS, not recovered Lua functions or source certification.
export function decodePrototypes(reader,header,{maxInstructions=100000,maxPrototypes=4096,maxLineEntries=100000}={}) {
  if(header.prototypeCount>maxPrototypes)throw Error('Prototype budget exceeded');
  reader.offset=header.prototypeDataOffset;
  const prototypes=[];let instructionCount=0,lineEntries=0;
  const u32=()=>reader.take(4).readUInt32LE();
  const signed=()=>{const n=reader.varint();return n>=2**52?n-2**53:n;};
  const packed=()=>{const n=signed();const tag=((n%8)+8)%8;return {tag,value:(n-tag)/8};};
  for(let id=1;id<=header.prototypeCount;id++){
    const start=reader.offset,flag=reader.varint(),count=reader.varint()-81061;
    if(count<0||(instructionCount+=count)>maxInstructions)throw Error('Instruction budget/count invalid');
    const instructions=[];
    for(let pc=1;pc<=count;pc++){
      const a=packed(),b=packed(),opcode=signed(),c=packed();
      instructions.push({pc,opcode,operands:[a,b,c]});
    }
    const captureCount=reader.varint();if(captureCount>4096)throw Error('Capture budget exceeded');
    const captures=[];
    for(let j=0;j<captureCount;j++){const n=reader.varint();captures.push({index:Math.floor(n/4),kind:n%4});}
    const runCount=u32();if(runCount>maxLineEntries)throw Error('Line-table budget exceeded');
    const lines={};let cursor=1;
    for(let j=0;j<runCount;j++){
      const n=u32();
      if(n%2){
        const first=Math.floor(n/2);cursor=u32();const value=u32();
        if(cursor<first||(lineEntries+=cursor-first+1)>maxLineEntries)throw Error('Invalid line-table run');
        for(let k=first;k<=cursor;k++)lines[k]=value;
      }else{if(++lineEntries>maxLineEntries)throw Error('Line-table budget exceeded');lines[cursor]=Math.floor(n/2);}
      cursor++;
    }
    const registers=reader.varint();if(registers>100000)throw Error('Register budget exceeded');
    prototypes.push({id,start,end:reader.offset,flag,registers,instructions,captures,lines});
  }
  const entry=reader.varint();if(entry<1||entry>prototypes.length)throw Error('Invalid entry prototype');
  let constantReferences=0,prototypeReferences=0;
  for(const p of prototypes)for(const op of p.instructions)for(const operand of op.operands){
    if(operand.tag===3){
      if(operand.value<1||operand.value>header.constants.length)throw Error('Invalid constant reference');
      constantReferences++;
    }else if(operand.tag===5){
      if(operand.value<1||operand.value>prototypes.length)throw Error('Invalid prototype reference');
      prototypeReferences++;
    }
  }
  return {entry,prototypes,instructionCount,constantReferences,prototypeReferences,
    serializedEnd:reader.offset,remainingBytes:reader.bytes.length-reader.offset,
    sourceRecovered:false,payloadExecuted:false};
}
