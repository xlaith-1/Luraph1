import crypto from 'node:crypto';

function luaQuote(value) {
  let out='"';
  for (let i=0;i<value.length;i++) {
    const b=value.charCodeAt(i);
    out += b===34?'\\"':b===92?'\\\\':b>=32&&b<127?value[i]:'\\'+String(b).padStart(3,'0');
  }
  return out+'"';
}

export function importStringDump(input) {
  const bytes=Buffer.isBuffer(input)?input:Buffer.from(input,'latin1');
  if(bytes.length>8388608) throw Error('Dump exceeds 8 MiB');
  const source=bytes.toString('latin1');
  const headers=[...source.matchAll(/^\[(\d+)\] \[string\][ \t]?/gm)];
  if(!headers.length || source.slice(0,headers[0].index).trim() || headers[0][1]!=='1') return null;
  if(headers.some((h,i)=>Number(h[1])!==i+1)) throw Error('Nonsequential or ambiguous string-dump headers');
  const records=headers.map((h,i)=>{
    const start=h.index+h[0].length, end=headers[i+1]?.index??source.length;
    const raw=source.slice(start,end), value=raw.replace(/[\r\n]+$/,'');
    let category='string';
    if(/(?:^|\n)[^\n]*:\d+(?:\s|$)/.test(value))category='stack-trace';
    else if(/https?:\/\//i.test(value))category='url-containing';
    else if(/\b(?:local\s+[A-Za-z_]\w*\s*=|function\s*\(|function\s+[A-Za-z_]\w*\s*\()/.test(value))category='code-like';
    return {id:i+1,category,byteStart:start,byteEnd:end,rawBase64:bytes.subarray(start,end).toString('base64'),value};
  });
  const unique=[...new Set(records.map(r=>r.value))];
  const categories={};for(const r of records)categories[r.category]=(categories[r.category]??0)+1;
  const report={status:'strings-only',kind:'string-inventory',sourceSha256:crypto.createHash('sha256').update(bytes).digest('hex'),records:records.length,uniqueStrings:unique.length,categories,
    note:'Captured strings only, not recovered application code. May include unrelated game/runtime strings. Trailing framing newlines normalized in value; byte spans and rawBase64 preserve original payload spans. The unescaped dump format cannot unambiguously represent a string containing its own record header. Non-ASCII bytes are preserved with a Latin-1 mapping; the original encoding is unknown.',fullRecoveryVerified:false};
  const inventory='-- STRING INVENTORY ONLY: captured text, NOT reconstructed application source.\n-- May contain unrelated game/runtime data. No payload is executed by this file.\n-- Dump framing newlines normalized; see strings.json for original byte spans.\nreturn {\n'+unique.map(v=>'  '+luaQuote(v)+',').join('\n')+'\n}\n';
  const cleaned=records.map(r=>`=== ${r.id} | ${r.category} ===\n${r.value.replace(/[^\x20-\x7e\t\r\n]/g,c=>'\\x'+c.charCodeAt(0).toString(16).padStart(2,'0'))}`).join('\n\n')+'\n';
  return {report,artifacts:{'strings.inventory.lua':inventory,'strings.cleaned.txt':cleaned,'strings.json':JSON.stringify({report,records},null,2)+'\n','report.json':JSON.stringify(report,null,2)+'\n'}};
}
