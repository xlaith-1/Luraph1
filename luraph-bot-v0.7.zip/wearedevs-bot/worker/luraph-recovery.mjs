import fs from 'node:fs';
import crypto from 'node:crypto';
import {decodePrototypes} from './luraph-prototypes.mjs';

export const luraphReview=Object.freeze(JSON.parse(fs.readFileSync(new URL('./reviews/sample-62.json',import.meta.url),'utf8')));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const fail=message=>{throw Error('Luraph recovery: '+message);};
const number=x=>{if(typeof x!=='number'||!Number.isFinite(x))fail('non-numeric symbolic operand');return x;};
const get=(table,key)=>{if(!(table instanceof Map))fail('unrecognized table access');return table.get(key);};
const set=(table,key,value)=>{if(!(table instanceof Map))fail('unrecognized table write');if(value===undefined)table.delete(key);else table.set(key,value);};
const raw=(operand,pc)=>operand.tag===0?pc+operand.value:operand.tag===7?pc-operand.value:operand.value;

export function decodeTypedConstant(c,cipher=luraphReview.stringCipher){
 if(c.kind==='number')return c.value===0?0:-c.value;
 if(c.kind==='boolean')return !c.value;
 if(c.kind!=='byte-string')fail('unsupported typed constant');
 const b=Buffer.from(c.value,'latin1');if(!b.length)fail('empty encoded string');
 if(b[0]===0)return b.subarray(1).toString('latin1');
 if(b.length<2)fail('truncated string seed');
 let state=b[1];const result=Buffer.alloc(b.length-2);
 for(let j=2;j<b.length;j++){state=(state*cipher.multiplier+cipher.increment)%256;result[j-2]=b[j]^state^cipher.xor;}
 return result.toString('latin1');
}

// This is a bounded abstract evaluation of DATA records, not eval/Lua execution.
// The one reachable bootstrap arithmetic helper is re-read from the upload.
function foldHelper(proto,args,constants,review){
 const n=new Map();let pc=1;const trace=[];
 for(let step=0;step<100;step++){
  const ins=proto.instructions[pc-1];if(!ins)fail('helper PC out of range');
  trace.push(pc);const [a,b,c]=ins.operands,[A,B,C]=ins.operands.map(v=>raw(v,pc));
  const literal=o=>{if(o.tag!==3)fail('helper constant tag');const entry=constants[o.value-1];if(entry?.kind==='int64'){const n=Number(entry.value);if(!Number.isSafeInteger(n))fail('unsafe helper integer');return n;}return entry?.value;};
  switch(ins.opcode){
   case 156:pc=A+1;continue;
   case 135:for(let j=1;j<=B;j++)set(n,j,args[j-1]);break;
   case 95:if(A!==0||literal(c)!==168)fail('unreviewed helper capture');set(n,B,{kind:'bnot'});break;
   case 152:{if(C!==1)fail('unreviewed numeric capture');const v=review.capturedNumbers[literal(a)];if(v===undefined)fail('missing reviewed numeric capture');set(n,B,v);break;}
   case 125:if(get(n,A)?.kind!=='bnot')fail('unrecognized helper call');set(n,A,(~number(get(n,A+1)))>>>0);break;
   case 9:set(n,A,number(get(n,C))-number(get(n,B)));break;
   case 51:set(n,C,number(literal(a))+number(get(n,B)));break;
   case 121:return {value:number(get(n,C)),trace};
   default:fail('unrecognized arithmetic helper opcode '+ins.opcode);
  }
  pc++;
 }
 fail('helper instruction budget');
}

function quoteLua(s){
 let out='"';for(const c of s){const n=c.charCodeAt(0);if(n>255)fail('non-byte string');out+=c==='"'?'\\"':c==='\\'?'\\\\':n<32||n>126?'\\'+String(n).padStart(3,'0'):c;}return out+'"';
}

export function liftPayload(prototype,constants,bootstrap,review=luraphReview){
 if(prototype.captures.length||prototype.flag!==0)fail('unsupported payload captures/flags');
 const T=new Map(),Y=new Map(),O=new Map(),B=new Map(),N=new Map();
 const arrays=[T,Y,O],slots=[9,8,11],lazy=new Map(),cache=new Map(),references=new Map();
 const key=(slot,pc)=>`${slot}:${pc}`;
 for(const ins of prototype.instructions){
  B.set(ins.pc,ins.opcode);
  ins.operands.forEach((operand,j)=>{
   if(operand.tag===5)fail('nested prototype reference');
   arrays[j].set(ins.pc,raw(operand,ins.pc));
   if(operand.tag===3){
    const k=key(slots[j],ins.pc);lazy.set(k,operand.value);
    if(!references.has(operand.value))references.set(operand.value,[]);
    references.get(operand.value).push({key:k,array:arrays[j],pc:ins.pc});
   }
  });
 }
 const constant=(slot,pc)=>{
  const k=key(slot,pc);if(cache.has(k))return cache.get(k);
  const index=lazy.get(k);if(!index||!constants[index-1])fail('invalid lazy constant access');
  const value=decodeTypedConstant(constants[index-1],review.stringCipher);
  // The original deferred getter fills every use and clears numeric aliases.
  for(const ref of references.get(index)){cache.set(ref.key,value);ref.array.delete(ref.pc);}
  return value;
 };
 const arithmetic=new Map([[8,{kind:'arithmetic',prototype:review.helperPrototype}]]);
 const library=new Map([[3,arithmetic]]),events=[],calls=[],helperTraces=[];
 let pc=1,Q,E,returned=false;
 for(let steps=0;steps<1000;steps++){
  const op=B.get(pc);if(op===undefined)fail('PC outside payload');events.push({pc,opcode:op});
  const A=()=>get(T,pc),D=()=>get(Y,pc),C=()=>get(O,pc);
  const ca=()=>constant(9,pc),cb=()=>constant(8,pc),cc=()=>constant(11,pc);
  switch(op){
   // Folded self-modifying opcode prefixes. Exact profile-bound handler
   // semantics were compared against the original VM, including mutations.
   case 25:B.set(pc,156);pc=number(A())+1;continue;
   case 52:B.set(pc,56);set(N,A(),T);break;
   case 109:B.set(pc,96);{const dest=A(),v=cc();set(N,dest,v);}break;
   case 123:B.set(pc,64);{const dest=A(),name=cc();if(name!=='print')fail('unsupported payload global');set(N,dest,{kind:'global',name});}break;
   case 156:pc=number(A())+1;continue;
   case 58:set(N,A(),Y);break;
   case 155:set(N,C(),B);break;
   case 56:set(N,A(),T);break;
   case 158:{const table=get(N,C()),k=ca(),v=cb();set(table,k,v);break;}
   case 26:for(let j=number(C());j<=number(D());j++)N.delete(j);break;
   case 122:set(N,C(),get(library,D()));break;
   case 82:{const dest=C(),table=get(N,D()),k=ca();set(N,dest,get(table,k));break;}
   case 96:{const dest=A(),v=cc();set(N,dest,v);break;}
   case 23:Q=N;E=A();break;
   case 140:set(Q,E,cc());break;
   case 45:{
    const start=number(D()),count=number(A())-1,fn=get(N,start);
    if(fn?.kind!=='arithmetic'||count<0||count>32)fail('unknown internal call');
    const helper=bootstrap.prototypes[fn.prototype-1];if(!helper)fail('missing bootstrap helper');
    const folded=foldHelper(helper,Array.from({length:count},(_,j)=>get(N,start+j+1)),bootstrap.constants,review);
    helperTraces.push(folded.trace);set(N,start,folded.value);break;
   }
   case 113:{const dest=C(),left=get(N,D()),right=ca();set(N,dest,number(left)+number(right));break;}
   case 48:{const value=get(N,A()),table=get(N,D()),k=cc();set(table,k,value);break;}
   case 137:for(let j=number(C());j<=number(D());j++)N.delete(j);break;
   case 133:break; // Empty handler, verified from original dispatcher.
   case 64:{const dest=A(),name=cc();if(name!=='print')fail('unsupported global');set(N,dest,{kind:'global',name});break;}
   case 19:{const start=number(A()),fn=get(N,start),arg=get(N,start+1);if(fn?.kind!=='global'||fn.name!=='print'||typeof arg!=='string')fail('unsupported external call');calls.push({name:fn.name,args:[arg]});break;}
   case 59:returned=true;break;
   default:fail('unsupported payload opcode '+op);
  }
  if(returned)break;pc++;
 }
 if(!returned)fail('payload did not terminate within static budget');
 if(calls.length!==1)fail('unreviewed call structure');
 const source=calls.map(call=>`${call.name}(${call.args.map(quoteLua).join(', ')})`).join('\n')+'\n';
 return {source,events,calls,helperTraces,reachableInstructions:new Set(events.map(e=>e.pc)).size};
}

export function recoverReviewedLuraph(bytes,bootstrap,Reader,decodeConstantPrefix,review=luraphReview){
 const {payloadOffset:start,payloadLength:length}=review;
 if(bytes.length!==start+length+3||bytes.subarray(start+length).some(x=>x!==0))fail('unexpected trailing data');
 const key=Buffer.from(review.payloadXorKey,'hex');if(key.length!==8)fail('bad reviewed cipher key');
 const payload=Buffer.from(bytes.subarray(start,start+length));
 for(let j=0;j<payload.length;j++)payload[j]^=key[j%key.length];
 if(sha(payload)!==review.decryptedPayloadSha256)fail('decrypted stage hash mismatch');
 const header=decodeConstantPrefix(payload);
 if(!header.typed||header.constants.length!==19||header.prototypeCount!==1)fail('unreviewed stage shape');
 const parsed=decodePrototypes(new Reader(payload),header);
 if(parsed.remainingBytes!==0||parsed.instructionCount!==35||parsed.entry!==1)fail('incomplete payload parse');
 const lifted=liftPayload(parsed.prototypes[0],header.constants,bootstrap,review);
 if(lifted.events.length!==34||lifted.reachableInstructions!==34||sha(Buffer.from(lifted.source,'utf8'))!==review.outputSha256)fail('source review mismatch');
 return {...lifted,parsed,header};
}
