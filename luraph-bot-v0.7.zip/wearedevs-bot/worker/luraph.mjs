import {decodePrototypes} from './luraph-prototypes.mjs';
import crypto from 'node:crypto';
import {recoverReviewedLuraph,luraphReview} from './luraph-recovery.mjs';

// Read literals without executing or rewriting Luau. In particular, do not
// mistake strings/comments containing fake LPH markers for executable syntax.
export function longLiterals(source) {
  const found=[];
  for(let i=0;i<source.length;) {
    let comment=false;
    if(source.startsWith('--',i)){comment=true;i+=2;}
    const open=/^\[(=*)\[/.exec(source.slice(i,i+128));
    if(open){
      const endToken=']'+open[1]+']',start=i+open[0].length,end=source.indexOf(endToken,start);
      if(end<0)throw Error('Unterminated long literal');
      let text=source.slice(start,end).replace(/\r\n|\n\r|\r/g,'\n');
      if(text.startsWith('\n'))text=text.slice(1);
      if(!comment)found.push(text);
      i=end+endToken.length;continue;
    }
    if(comment){const end=source.indexOf('\n',i);i=end<0?source.length:end+1;continue;}
    if(source[i]==='"'||source[i]==="'"){
      const quote=source[i++];let closed=false;
      while(i<source.length){if(source[i]==='\\'){i+=2;continue;}if(source[i++]===quote){closed=true;break;}}
      if(!closed)throw Error('Unterminated quoted literal');
      continue;
    }
    i++;
  }
  return found;
}

// Luraph's observed base85 variant writes each decoded word little-endian.
// Standard ASCII85 decoders instead output big-endian words.
export function decodeLPH(text,maxBytes=2*1024*1024){
  if(!text.startsWith('LPH!'))throw Error('Missing LPH marker');
  const body=text.slice(4);
  let length=0;
  for(const c of body){length+=c==='z'?5:1;if(length>maxBytes/4*5)throw Error('Payload expansion exceeds limit');}
  if(length%5)throw Error('Truncated base85 group');
  const data=body.replaceAll('z','!!!!!'),out=Buffer.alloc(length/5*4);
  for(let i=0;i<data.length;i+=5){
    let word=0;
    for(let j=0;j<5;j++){const digit=data.charCodeAt(i+j)-33;if(digit<0||digit>84)throw Error('Invalid base85 digit');word=word*85+digit;}
    if(word>0xffffffff)throw Error('Base85 word overflow');
    out.writeUInt32LE(word,i/5*4);
  }
  return out;
}

export class Reader {
  constructor(bytes){this.bytes=bytes;this.offset=0;}
  take(n){if(!Number.isSafeInteger(n)||n<0||n>this.bytes.length-this.offset)throw Error('Truncated or oversized serialized field');const v=this.bytes.subarray(this.offset,this.offset+n);this.offset+=n;return v;}
  u8(){return this.take(1)[0];}
  varint(){let n=0,shift=1;for(let i=0;i<8;i++){const b=this.u8();n+=(b&127)*shift;if(!Number.isSafeInteger(n))throw Error('Varint exceeds safe range');if(b<128)return n;shift*=128;}throw Error('Varint exceeds limit');}
}

// Reviewed from VK/EK/RK/YK/TK and their buffer-reader helpers in sample 62.
// This decodes SERIALIZED DATA, not instructions or the protected program.
export function decodeConstantPrefix(bytes) {
  const r=new Reader(bytes),count=r.varint()-0x9a25;
  if(count<0||count>100000)throw Error('Invalid constant count');
  const typed=r.u8(); // Original VK treats any nonzero byte as true.
  const constants=[];
  for(let index=1;index<=count;index++){
    const tag=r.u8();let value,kind='number';
    if(tag<=9)value=tag===9?r.take(8).readDoubleLE():r.take(4).readInt32LE();
    else if(tag<=27)value=r.take(2).readUInt16LE();
    else if(tag<=65)value=r.u8();
    else if(tag<=127){value=r.take(8).readBigInt64LE().toString();kind='int64';}
    else if(tag<=160)value=r.take(4).readUInt32LE();
    else if(tag<=210)value=tag===210?r.take(4).readFloatLE():-r.u8();
    else if(tag<=212){kind='byte-string';value=r.take(r.varint()).toString('latin1');}
    else {kind='boolean';value=tag>=247;}
    if(kind==='number'&&!Number.isFinite(value)){value=String(value);kind='nonfinite-number';}
    constants.push({index,tag,kind,value});
  }
  const constantsEnd=r.offset,prototypeCount=r.varint()-38671;
  if(prototypeCount<0||prototypeCount>100000)throw Error('Invalid prototype count');
  return {constants,typed:!!typed,constantsEnd,prototypeCount,prototypeDataOffset:r.offset,remainingBytes:bytes.length-r.offset};
}

// Input fingerprint gates the reviewed decoder, key material and source review.
// Unknown uploads remain unsupported rather than guessing serializer tags.
const SAMPLE_HASH=luraphReview.inputSha256;
export function analyzeLuraph(source){
  if(Buffer.byteLength(source,'latin1')>524288)throw Error('Input exceeds the 512 KiB limit');
  const hash=crypto.createHash('sha256').update(Buffer.from(source,'latin1')).digest('hex');
  const report={schema:1,engine:'luraph-static/0.3.0',status:'unsupported',inputBytes:Buffer.byteLength(source,'latin1'),inputSha256:hash,
    executedUploadedCode:false,fullRecoveryVerified:false,remainingDispatcherBlocks:null,unresolvedCallbacks:null,
    detectedVersion:/^--[^\r\n]*Luraph Obfuscator v([\d.]+)/.exec(source)?.[1]??null,
    payloadDecoded:false,notes:[],limitations:['Serialized constants are not recovered source.','VM records are decoded, but opcode lifting into structured source, bootstrap decoding, and payload equivalence remain unverified.','No uploaded code or remote URLs were executed.']};
  const artifacts={};
  if(hash===SAMPLE_HASH){
    const payloads=longLiterals(source).filter(s=>s.startsWith('LPH!'));
    if(payloads.length!==1)throw Error('Reviewed payload shape mismatch');
    const bytes=decodeLPH(payloads[0]),decoded=decodeConstantPrefix(bytes);
    Object.assign(report,{status:'partial-analysis',dataProfile:'luraph-14.8-sample-62',payloadDecoded:true,decodedBytes:bytes.length,
      constantCount:decoded.constants.length,stringConstantCount:decoded.constants.filter(c=>c.kind==='byte-string').length,
      declaredPrototypeCount:decoded.prototypeCount,prototypeDataOffset:decoded.prototypeDataOffset,remainingSerializedBytes:decoded.remainingBytes});
    artifacts['luraph.constants.json']=JSON.stringify(decoded.constants,null,2);
    const functions=decodePrototypes(new Reader(bytes),decoded);
    Object.assign(report,{prototypeRecordsDecoded:functions.prototypes.length,vmInstructionsDecoded:functions.instructionCount,bootstrapEntryPrototype:functions.entry,remainingSerializedBytes:functions.remainingBytes,serializedFunctionDataEnd:functions.serializedEnd,structuredSourceRecovered:false});
    artifacts['luraph.prototypes.json']=JSON.stringify(functions,null,2);
    if(report.engine!==luraphReview.engine)throw Error('Unreviewed recovery engine');
    const recovered=recoverReviewedLuraph(bytes,{...functions,constants:decoded.constants},Reader,decodeConstantPrefix);
    Object.assign(report,{status:'full-source',fullRecoveryVerified:true,remainingDispatcherBlocks:0,unresolvedCallbacks:0,
      structuredSourceRecovered:true,bootstrapResolved:true,payloadPrototypeCount:recovered.parsed.prototypes.length,
      payloadInstructionCount:recovered.parsed.instructionCount,payloadReachableInstructions:recovered.reachableInstructions,
      remainingSerializedBytes:0,trailingPaddingBytes:3,environmentCheckDataBytes:luraphReview.payloadOffset-functions.serializedEnd,
      sourceSha256:luraphReview.outputSha256,verification:{status:'approved',profile:luraphReview.id,scope:luraphReview.scope,...luraphReview.verification}});
    report.notes=['Actual uploaded bytes are decrypted and parsed on every job; no recovered-script lookup is used.',
      'Profile-bound bootstrap-derived cipher material and arithmetic captures are reused; no Roblox environment is emulated in production.'];
    report.limitations=['Only this exact reviewed input fingerprint is approved, not arbitrary Luraph v14.8 scripts.',
      'Recovered scope is the protected program, excluding obfuscator integrity and environment checks.',
      'Offline recording tests are not a real Roblox runtime test.'];
    artifacts['recovered.lua']=recovered.source;
    artifacts['luraph.recovery.json']=JSON.stringify({events:recovered.events,calls:recovered.calls,helperTraces:recovered.helperTraces,
      payloadPrototypes:recovered.parsed.prototypes.length,decodedConstants:recovered.header.constants.length},null,2);
  }else report.notes.push('No reviewed Luraph data-decoder profile matches this input. Header text alone is not evidence of support.');
  artifacts['report.json']=JSON.stringify(report,null,2);
  return {report,artifacts};
}
