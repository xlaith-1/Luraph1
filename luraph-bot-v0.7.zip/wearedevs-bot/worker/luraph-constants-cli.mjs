#!/usr/bin/env node
import fs from 'node:fs';import path from 'node:path';import{createHash}from'node:crypto';import{execFileSync}from'node:child_process';import{fileURLToPath}from'node:url';
import{detectInput}from'../tools/luraph/detect-input.mjs';
import{captureConstants}from'../tools/luraph/constant-capture.mjs';
import{importStringDump}from'./luraph-string-dump.mjs';
const tools=fileURLToPath(new URL('../tools/luraph/',import.meta.url));
export function quote(s){return '"'+[...s].map(c=>{const n=c.charCodeAt(0);return n>=32&&n<127&&n!==34&&n!==92?c:'\\'+String(n).padStart(3,'0');}).join('')+'"';}
export function renderDump(result){
 if(result.report?.inventoryOnly)return ['-- Luraph partial string inventory: NOT reconstructed source.', '-- Flat constant-pool candidates; prototype grouping and scalars are not recovered.', '-- No application execution or third-party upload. Completeness is not certified.', 'return {', '    strings = {', ...result.inventory.map((s,i)=>`        [${i}] = ${quote(s.value)},${s.count>1?' -- x'+s.count:''}`), '    },','}'].join('\n')+'\n';
 let lines=['-- Luraph constant dump: partial capture, not reconstructed source.','-- No application execution or third-party upload.','-- Strings are decoded candidates; numbers may include obfuscator/VM literals.','-- Prototype IDs are local to this dump, not original source function IDs.','return {','    protos = {'];
 if(result.report?.loaderScope?.skippedTopLevelStatements)lines.splice(4,0,'-- Scope: embedded Luraph loader only; preceding Roblox code was excluded, not executed.');
 for(const p of result.protos){lines.push(`        [${p.id}] = {`);if(p.parent!==undefined)lines.push(`            parent = ${p.parent},`);
  for(const kind of ['strings','numbers','booleans'])if(p[kind].length){lines.push('            '+kind+' = {');p[kind].forEach((v,i)=>lines.push(`                [${i}] = ${typeof v.value==='string'?quote(v.value):String(v.value)},${v.count>1?' -- x'+v.count:''}`));lines.push('            },');}
  if(p.closures.length){lines.push('            closures = {');p.closures.forEach((id,i)=>lines.push(`                [${i}] = { closure = ${id} },`));lines.push('            },');}lines.push('        },');
 }
 lines.push('    },','    wrapper_values = {');result.wrapper_values.forEach((p,i)=>{lines.push(`        [${i}] = {`, '            strings = {');p.strings.forEach((s,j)=>lines.push(`                [${j}] = ${quote(s.value)},${s.count>1?' -- x'+s.count:''}`));lines.push('            },','        },');});lines.push('    },','}');return lines.join('\n')+'\n';
}
const [input,out,python]=process.argv.slice(2);
if(input&&out&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 let report={engine:'luraph-constant-dumper/0.6.1',status:'starting',fullRecoveryVerified:false,applicationExecuted:false,thirdPartyUpload:false};
 const save=()=>{fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2),{mode:0o600});};
 try{
  fs.mkdirSync(out,{recursive:true});
  for(const name of ['luraph-constants.lua','constants.evidence.json','analysis-only.lua','luraph.dump.lua','readable.vm.lua','application.candidate.lua','strings.inventory.lua'])fs.rmSync(path.join(out,name),{force:true});
  if(!fs.statSync(input).isFile()||fs.statSync(input).size>8388608)throw Error('Input exceeds 8 MiB limit');
  const bytes=fs.readFileSync(input);report.inputSha256=createHash('sha256').update(bytes).digest('hex');save();
  report.stage='detecting-input';report.inputDetection=detectInput(bytes);save();
  if(['constant-table-input','unknown-or-unsupported'].includes(report.inputDetection.kind))throw Error(report.inputDetection.alreadyDumped?'Input is already a constant table; no obfuscated loader was detected':'Detection failed: unsupported input structure');
  const imported=report.inputDetection.kind==='numbered-string-inventory'?importStringDump(bytes):null;if(imported){for(const[name,text]of Object.entries(imported.artifacts))fs.writeFileSync(path.join(out,name),text,{mode:0o600});report.status='imported-string-inventory';save();process.stdout.write(JSON.stringify({ok:true,status:report.status}));process.exit(0);}
  let loaderInput=input,inputData;
  const outer=bytes.toString('latin1');
  report.claimedVersion=outer.slice(0,1024).match(/Luraph Obfuscator v([0-9.]+)/)?.[1]??null;
  if(report.inputDetection.kind==='lph-two-stream-container'){
   const metadata=execFileSync(python||'python3',[path.join(tools,'unpack_container.py'),input,out],{timeout:30000,maxBuffer:262144,stdio:['ignore','pipe','pipe']});
   report.container=JSON.parse(metadata);loaderInput=path.join(out,'container-vm.lua');inputData=fs.readFileSync(path.join(out,'container-bytecode.bin'));
  }
  const source=(loaderInput===input?bytes:fs.readFileSync(loaderInput)).toString('latin1');if(!source.includes('bit32')||!source.includes('buffer'))throw Error('Unsupported input: this route currently recognizes buffer-based Luraph VM loaders');
  report.status='detected-luraph-like-loader';report.detection='lexical container/loader match; AST and captured VM validation required';save();
  const analysis=path.join(out,'analysis-only.lua');execFileSync(python||'python3',[path.join(tools,'normalize_for_analysis.py'),loaderInput,analysis,'--preserve-compound'],{timeout:30000,maxBuffer:262144,stdio:['ignore','pipe','pipe']});
  const timeout=Math.min(1800,Math.max(1,Number(process.env.ENGINE_TIMEOUT_SECONDS)||900))*1000;
  const result=captureConstants(fs.readFileSync(analysis,'utf8'),{inputData,milliseconds:Math.max(1000,timeout-62000),onProgress:stage=>{report.stage=stage;save();}});
  for(const name of ['analysis-only.lua','container-vm.lua','container-bytecode.bin'])fs.rmSync(path.join(out,name),{force:true});
  if(!result.report.uniqueStringCount)throw Error('No useful string constants captured');
  // Validate the generated Lua with the local parser; never execute the dump.
  report.stage='checking-output';save();const output=renderDump(result);
  const {default:lp}=await import('../tools/luraph/vendor/luaparse.cjs');lp.parse(output,{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
  if(Buffer.byteLength(output)>5*1024*1024)throw Error('Constant output exceeds size limit');
  fs.writeFileSync(path.join(out,'luraph-constants.lua.tmp'),output,{mode:0o600});fs.renameSync(path.join(out,'luraph-constants.lua.tmp'),path.join(out,'luraph-constants.lua'));
  const constantCount=result.report.inventoryOnly?result.inventory.length:result.protos.reduce((n,p)=>n+p.strings.length+p.numbers.length+p.booleans.length,0);
  const prototypeCount=result.report.inventoryOnly?null:result.protos.length;
  const wrapperConstantCount=result.report.inventoryOnly?0:result.wrapper_values.reduce((n,p)=>n+p.strings.length,0);
  const countBasis=result.report.inventoryOnly?'deduplicated flat string entries':'emitted per-prototype string/number/boolean entries; wrapper entries and closure edges excluded';
  report={...report,...result.report,constantCount,prototypeCount,wrapperConstantCount,countBasis,groupingRecovered:!result.report.inventoryOnly,formatProfile:{family:'reviewed-buffer-vm',container:report.inputDetection.kind,applicationEncoding:result.report.applicationEncoding??(result.report.inventoryOnly?'periodic-masked-tagged-pool':'direct-serialized-application'),vmBoundaryValidated:true,versionVerified:false},stage:'download-ready',syntaxChecked:true,outputSha256:createHash('sha256').update(output).digest('hex')};save();
  // Evidence is auxiliary; keep it compact and below the OS per-file limit.
  const evidence=JSON.stringify(result);
  if(Buffer.byteLength(evidence)<=10*1024*1024)fs.writeFileSync(path.join(out,'constants.evidence.json'),evidence,{mode:0o600});
  else{report.evidenceOmitted='Auxiliary evidence exceeded the 10 MiB budget; validated Lua output retained';save();}
  process.stdout.write(JSON.stringify({ok:true,status:report.status,artifacts:['luraph-constants.lua'],uniqueStrings:report.uniqueStringCount,constants:report.constantCount,prototypes:report.prototypeCount}));
 }catch(err){report.status='unsupported-or-incomplete';report.error=String(err.message).slice(0,1000);if(err.details)report.diagnostics=err.details;if(fs.existsSync(out))save();process.stderr.write('LURAPH_CONSTANTS_UNSUPPORTED '+report.error+'\n');process.exitCode=2;}finally{for(const name of ['analysis-only.lua','container-vm.lua','container-bytecode.bin','luraph-constants.lua.tmp'])fs.rmSync(path.join(out,name),{force:true});}
}
