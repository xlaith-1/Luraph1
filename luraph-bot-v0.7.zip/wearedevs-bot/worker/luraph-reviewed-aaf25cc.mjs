// Reviewed exact-input research route. NOT a general Luraph decompiler.
// Cipher parameters are read from captured bootstrap instructions. The full
// original string-decoder path has NOT been executed. Never issue a certificate.
import {createHash} from 'node:crypto';
import {StaticDataEvaluator,isVmFactory} from '../tools/luraph/static-data-eval.mjs';
export const SAMPLE_SHA256='aaf25cc314cf7b09d3eafcaf821bc1798c794197897f63ca20c2b9182afedc8d';
const BLOB_SHA256='4fe6ef9eb729b023f0a0cbcabeeeec02214ecfb02965d141810bf9404a9fd521';
const digest=b=>createHash('sha256').update(b).digest('hex');
export function inferCipher(encoded,known){
 if(encoded.length!==known.length+2)throw Error('Known-plaintext length mismatch');
 const solutions=[];
 for(let multiplier=0;multiplier<256;multiplier++)for(let increment=0;increment<256;increment++){
  let state=encoded.charCodeAt(1),mask;
  for(let i=0;i<known.length;i++){
   state=(state*multiplier+increment)%256;
   const m=encoded.charCodeAt(i+2)^state^known.charCodeAt(i);
   if(i===0)mask=m;else if(m!==mask){mask=null;break;}
  }
  if(mask!==null)solutions.push({multiplier,increment,mask});
 }
 if(solutions.length!==1)throw Error('Cipher hypothesis is not unique');
 return solutions[0];
}
export function decodeString(encoded,{multiplier,increment,mask}){
 let state=encoded.charCodeAt(1),result='';
 for(let i=2;i<encoded.length;i++){state=(state*multiplier+increment)%256;result+=String.fromCharCode(encoded.charCodeAt(i)^state^mask);}
 return result;
}
class FrameComplete extends Error{}
export function recoverReviewedCandidate(input,normalized){
 if(digest(input)!==SAMPLE_SHA256)return null;
 if(digest(normalized)!=='3940fd0bb2c5b65b93bdad77e3ae6711869b86268a125811716aabf55bc3507c')throw Error('Reviewed normalized source mismatch');
 // Capture the original bootstrap without executing its VM. Read actual
 // cipher parameters, independently of any assumed application plaintext.
 const bootstrap=new StaticDataEvaluator({maxSteps:22000000,maxMilliseconds:30000,maxTables:1000});
 const boundary=bootstrap.run(normalized);
 if(boundary.status!=='vm-boundary')throw Error('Bootstrap capture failed');
 const p=bootstrap.tables[282];
 const expected=[[1794,27],[3339,27],[3942,87],[3862,6],[4505,8],[4506,141]];
 if(!p||expected.some(([pc,op])=>p.get(5).get(pc)!==op)||p.get(11).get(4506)!==256)throw Error('Bootstrap cipher instructions mismatch');
 const staticCipher={multiplier:p.get(2).get(1794),increment:p.get(2).get(3339),mask:p.get(2).get(3942)};
 if(Object.values(staticCipher).some(x=>!Number.isInteger(x)||x<0||x>255))throw Error('Invalid captured cipher parameters');
 const e=new StaticDataEvaluator({maxSteps:3000000,maxMilliseconds:10000,maxTables:1000});
 let payload,frame,prototype,cipher,constants,graph;
 const trace=[],prints=[];
 for(const [name,native]of e.root.get('buffer').values)if(name.startsWith('read')&&native.fn){
  const original=native.fn;native.fn=(b,...args)=>{
   if(b.length===57924){if(!payload){if(digest(b)!==BLOB_SHA256)throw Error('Reviewed blob mismatch');payload=Buffer.from(b.subarray(57799));}b=payload;}
   return original(b,...args);
  };
 }
 const environment=e.table();for(const [name,cell]of e.root.cells)environment.set(name,cell.value);
 e.root.get('select').fn=(index,...args)=>{if(index!=='#')throw Error('Unsupported select mode');return args.length;};
 e.root.get('getfenv').fn=()=>environment;
 e.root.get('setfenv').fn=(fn,env)=>{if(env!==environment)throw Error('Unknown environment');return fn;};
 e.root.get('getmetatable').fn=t=>t.meta??null;
 e.root.get('print').fn=(...args)=>{if(args.some(x=>typeof x!=='string'))throw Error('Unexpected print argument');prints.push(args);};
 const call=e.call.bind(e);
 e.call=(fn,args)=>{
  if(fn?.node&&isVmFactory(fn.node)&&!e.selectingFactory){
   if(frame)throw Error('Unexpected additional factory');
   prototype=args[0];
   const ops=[...prototype.get(5).values.values()];
   if(JSON.stringify(ops)!=='[129,32,101,51,129,129,35,144,70]'||prototype.get(3)!==3)throw Error('Application layout mismatch');
   const records=e.tables.filter(t=>t.get(2)==='string'&&t.get(3)===prototype).sort((a,b)=>a.get(4)-b.get(4));
   if(records.length!==2||records[0].get(4)!==3||records[0].get(5)!==8||records[1].get(4)!==4||records[1].get(5)!==2)throw Error('Constant layout mismatch');
   graph=e.snapshot({status:'application-prototype-captured'});
   cipher=staticCipher;
   constants=records.map(t=>({pc:t.get(4),slot:t.get(5),encryptedHex:Buffer.from(t.get(1),'latin1').toString('hex'),candidate:decodeString(t.get(1),cipher)}));
   // Explicitly install CANDIDATE constants, not a claimed original decoder.
   for(const c of constants)prototype.get(c.slot).set(c.pc,c.candidate);
   e.selectFrame({status:'vm-boundary',closure:fn,args});frame=e.selectedFrame;return frame;
  }
  const result=call(fn,args);
  if(fn===frame)throw new FrameComplete('Candidate application frame returned');
  return result;
 };
 const statement=e.statement.bind(e);
 e.statement=(node,scope)=>{
  if(node.type==='LocalStatement'&&node.variables.length===1&&node.variables[0].name==='E'&&node.init[0]?.type==='IndexExpression'&&node.init[0].base.name==='u'){
   const pc=scope.get('V');trace.push({pc,opcode:scope.get('u').get(pc)});if(trace.length>32)throw Error('Unexpected application path');
  }
  return statement(node,scope);
 };
 try{e.run(normalized);throw Error('Application frame did not complete');}catch(err){if(!(err instanceof FrameComplete))throw err;}
 if(JSON.stringify(trace.map(t=>t.pc))!=='[1,6,2,3,4,5,8,9]'||prints.length!==1||prints[0].length!==1||prints[0][0]!==constants[1].candidate)throw Error('Candidate control-flow mismatch');
 const quote=s=>'"'+[...s].map(c=>{let v=c.charCodeAt(0);return v>=32&&v<127&&v!==34&&v!==92?c:'\\'+String(v).padStart(3,'0');}).join('')+'"';
 return {
  source:'-- Best-effort application candidate, NOT a verified decompilation.\n-- Cipher parameters extracted from bootstrap; VM path checked.\n-- Full original bootstrap/string-decoder execution remains unverified.\nprint('+quote(prints[0][0])+')\n',
  report:{status:'application-candidate',engine:'luraph-reviewed-sample/0.1',inputSha256:SAMPLE_SHA256,fullRecoveryVerified:false,originalStringDecoderVerified:false,runtimeAttempted:false,boundedAstFrameEvaluated:true,thirdPartyUpload:false,scope:'Exact reviewed input only; not general 14.7 support',cipher:{parameterSource:'Captured bootstrap prototype 283 instructions',...cipher},cipherInstructionPCs:expected.map(([pc])=>pc),bootstrapCaptureSteps:bootstrap.steps,payloadOffset:57799,payloadBytes:payload.length,instructionCount:9,reachableInstructionCount:trace.length,constants,trace,recordedPrints:prints,steps:e.steps,notes:['Cipher parameters independently extracted from bootstrap arithmetic; byte-layout interpretation reviewed but original decoder path not fully executed.','Original VM frame returns with the candidate constants; original bootstrap/environment checks bypassed.','Source is a best-effort application candidate, not a full-recovery certificate.']},
  capture:{payloadHex:payload.toString('hex'),graph}
 };
}
