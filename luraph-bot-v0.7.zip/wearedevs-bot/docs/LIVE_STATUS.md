# Temporary supervised runtime

Restarted with reliability fixes on 2026-09-13.

- Supervisor process: `private-discord-deobfuscator-bot-2407b142`, PID9674.
- Current child PID9685 after a verified supervisor restart; child IDs can change.
- Bot application1536011667413147730; connected to two guilds.
- REST fallback enabled only for authorized test channel1520557510900191422.
- Gateway watchdog enabled; process supervisor restarts exited clients.
- Last investigated ?ironbrew input was rejected for no recognized IronBrew
  bytecode payload. It had a Syncrypt header and readable Lua, not a missing runtime.
- Tokens remain outside the saved workspace and ZIP.
- This is temporary workspace hosting, not an always-on hosting guarantee.

Two jobs after the first reliability restart delivered output attachments.
A controlled child exit verified automatic restart and reconnection with the final
watchdog fixes. Global and test-guild slash commands remain zero.

Restarted with single-user access: only1442928403601690657 can invoke any command.
Connected successfully after loading the restriction.

Latest runtime: private-luraph-and-deobfuscator--8a6e82b1, supervisor PID11503,
initial client PID11514, connected to two guilds on 2026-09-13. The previous
process was no longer present, so the updated service was started again.
Single-user access remains1442928403601690657. No permanent uptime guarantee.
