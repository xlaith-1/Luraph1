# Luraph constant dumper — tested development release

The default `?luraph` command now returns `luraph-constants.lua`, not a candidate
application, an empty runtime dump, or the original protected interpreter.
Attach one Lua/TXT input. Owner-only access, 900-second default / 1800-second
maximum and the OS-isolated worker remain in place.

## Actual pipeline

1. Reject oversized input, recognize a buffer-based Luraph-like loader.
2. Normalize Luau syntax **for the bounded AST evaluator only**.
3. Capture the bootstrap data at its structural VM-factory boundary. Do not run it.
4. Discover bootstrap XOR-constant instruction signatures and the primitive pool.
5. Search the unread buffer tail for a complete application-prototype parse using
   the original parser. Bounds: first 1024 tail bytes, at most 48 candidates.
6. Solve the 8-bit string-cipher recurrence with captured XOR masks and printable
   string constraints. Reject absent or ambiguous solutions. No reference output
   or sample hash is consulted by this route.
7. Group strings, candidate scalar literals and closure references by prototype;
   retain repetition counts. Where recognized, separate global-name operands.
8. Parse-check generated Lua, write it atomically, and prepare the attachment.

`constants.evidence.json` keeps operand locations, parameters, attempts, counts
and limitations. `report.json` is checkpointed at each stage. No application VM
is executed. No network or credentials are available inside the worker. No
third-party decompiler upload is made. Unsupported input produces a diagnostic,
not fabricated output. Numbered string inventories remain importable and are
explicitly labeled imported inventories, not fresh Luraph captures.

## Verified against the user's reference outputs

| Input | Distinct reference strings | Captured strings | Missing | Extra |
|---|---:|---:|---:|---:|
| `message (2) (2).txt` | 2 | 2 | 0 | 0 |
| `Aimbot.lua (1).txt` | 214 | 214 | 0 | 0 |

The reference files are used only by tests/comparison tooling, never by extraction.
The small sample's inferred cipher is multiplier 193, increment 213, mask 168;
the Aimbot sample's is 137, 137, 87. Both offsets are discovered, not hardcoded.
Both were tested through the new CLI; the small sample through prefix attachment
integration, and Aimbot through the actual OS-isolated worker.

## Important limitations — not a complete reference match

- The Aimbot capture has 68 prototypes versus 67 in the supplied reference. IDs,
  grouping and wrapper separation are not guaranteed to match the reference.
- Numeric literals can include obfuscator/VM data; complex scalar operands may
  be omitted. The reference's `95` in the small sample is not recovered as a
  numeric constant by this conservative operand pass.
- Scalar decoding uses the matched deferred-scalar convention; it is not a
  general proof of source-only constant classification.
- String validation is a constrained unique printable solution, supported by
  the reference comparisons above, not cryptographic proof for arbitrary inputs.
- The full original string-decoder path is not executed. `fullRecoveryVerified`
  remains false. Never describe this release as complete deobfuscation or support
  for every Luraph version.
- If the entire worker is killed before a validated capture completes, only a
  diagnostic checkpoint may exist; no placeholder constants are invented.

## Source review

All three supplied GitHub locations were inspected and pinned in the workspace
review manifest. They are not interchangeable constant dumpers:

- `timmytim12354-png/dumper-and-env-loggers`: collection of environment loggers,
  wrappers and debug adapters. Logging calls does not recover every constant in
  unopened functions or branches.
- `xlaith-1/dumpers`: mixed archive collection. For example, the inspected Speack
  script stubs `getgc` and `getconstants` with empty tables. That is not proof of
  a complete constant capture. No untrusted downloaded logger was executed.
- `xlaith-1/ok/luau-vmp-deobf-main (1).zip`: static unpacking, staged capture and
  devirtualization architecture. Its README enables a lua.expert upload post-pass
  by default. This release does not invoke that route or upload user files.

No unlicensed leaked implementation was copied into this new capture module.
The new code builds on this project's bounded AST parser/evaluator. Downloaded
review sources are archived separately, with verified hashes, not shipped as bot
code. A RAR archive and oversized files were not executed or exhaustively audited.

## Tests and deployment

- 256 Node tests passed, zero skips, with both new reference comparisons enabled.
- 70 Python tests: 62 passed, 8 dependency-based skips.
- Source/OS isolation, unsupported-input behavior and owner-only access remain tested.
- This deliverable changes the bot source. Live restart requires a current private
  Discord token; the earlier temporary credential file was unavailable at the end
  of this run. No claim is made that this release is currently connected.
