# Current validation — 2026-09-19, release 0.6

See UPDATE_0_6.md. Targeted fixture-enabled regressions: 29/29 passed, no skips.
Default Node discovery: 162 passed, 96 skipped. Python: 39 passed, 11 skipped.
No live Discord/OS-isolation deployment claim.

## Historical validation (not current release totals)

# Constant-dumper validation — 2026-09-14

256 Node tests passed with zero skips; 70 Python tests, 62 passed and 8 skipped.
Both supplied references match the captured distinct string sets exactly: 2/2
and 214/214. Numeric/prototype coverage remains partial. See docs/CONSTANT_DUMPER.md.

## Previous validation history

# Latest correction validation — 2026-09-14

- 251 Node tests passed, no skips, with the new supplied sample enabled.
- 70 Python tests: 62 passed, 8 skipped.
- Exact-sample prefix test uses the actual isolated worker and checks the candidate
  plus genuine captured-prototype attachments.
- Empty-capture regression checks no original-input or empty-dump attachment.
- Candidate is not a full-recovery certificate; original decoder remains unverified.

## Earlier validation history

# Build and verification results

Tested in this workspace on 2026-09-13. This is installation/integration testing,
not proof of universal or error-free source recovery.

- **All 6 repository engines installed; all 8 CLI entrypoints load in isolation.**
- The ZIP was extracted into a fresh directory, rebuilt using the shipped script,
  and passed all 49 Python /130 Node tests there as well.
- IronBrew2, Hercules and XHider publish successfully with .NET SDK 8.0.425.
- Node 20 engines load with their locked dependencies. Java and Lua 5.4 are installed.
- **49 Python tests pass** (no skips in this workspace).
- **130 Node tests pass** (no skips in this workspace), including legacy research
  regression tests. Private fixtures are not in the downloadable bundle; related
  tests skip on machines where those files are absent.

## Behaviors exercised

- Every named prefix command routes to the matching engine.
- `?help` fits a Discord message and lists the per-engine file types.
- No slash command tree or registration method exists.
- Remote slash cleanup uses empty global/guild payloads, mocked offline.
- LuaObfuscator transforms a small Lua fixture and returns code through the sandbox.
- Obfuscator.io transforms a small JavaScript fixture through the sandbox.
- Real reviewed legacy Luraph output still reaches the new delivery path.
- Nonzero exit, wall timeout, and log-limit termination keep any written source.
- Transformation checkpoints survive an exception after an earlier successful pass.
- Unknown/malformed input with no generated source returns no invented file.
- Symlinks, non-source artifacts, empty files and oversized outputs are rejected.
- Worker tests cannot read the bot directory or token environment, and an outbound
  network connection fails in the isolated network namespace.
- Actual Bubblewrap namespaces are used in integration tests, not mocked sandboxes.

## Not claimed

No real Discord token was available, so this build did not connect to a server or
clear the live application's remote slash-command definitions. That occurs on
startup with the configured token. Engines were not comprehensively validated
against every obfuscator/version. CLI readiness is not a full-deobfuscation claim.

## Reliability update

After diagnosing a live unsupported IronBrew upload and a gateway interruption:

- **57 Python tests and 130 Node tests pass** in the workspace.
- Added safe, specific error classification; verified the actual IronBrew rejection
  means no recognized bytecode payload, rather than a missing dependency.
- Verified long REST-delivered jobs do not block subsequent help delivery.
- Verified the supervisor restarts exited children and cleans their temporary data.
- Verified the gateway watchdog can close without awaiting/canceling its own task.
- The supervised live client reconnected to two guilds with the authorized test
  channel's REST fallback enabled. Availability still depends on the hosting VM.

- Stale heartbeat ACKs are detected even when the last latency reading looks healthy.
- Watchdog restarts wait for active jobs to finish instead of discarding their output.
- A live job after the restart delivered one source attachment, confirmed through Discord REST.

- Live supervisor restart was tested with a controlled child termination; the new
  client connected successfully with REST fallback enabled.

## Single-user restriction

60 Python tests pass. Added tests that every command silently ignores other users
without downloading files or running engines; REST scheduling and interaction
permission checks also reject other users. Authorized-user delivery tests pass.

## Luraph dump/import and static fallback update

- 62 Python and 135 Node tests pass; all eight isolated engine CLI checks READY.
- Upstream source review:337 sample-free tests pass inside a network-disabled OS sandbox.
- Seven existing development samples tested; untouched holdouts not opened.
- Three statically unpacked into VM source and bytecode. None completed the
  upstream capture/decompile pipeline on these seven inputs.
- Actual isolated bot worker returns a labeled inventory for the uploaded dump
  and labeled VM source for two within-limit development inputs.
- The uploaded dump has1226 records/unique values,94 stack-trace entries,
  two URL-containing entries and one code-like template (not recovered program).


## Latest source-recovery integration

- Node: 245 passed, zero skipped.
- Python: 64 collected; 56 passed, 8 skipped because other engine builds/runtime
  dependencies are unavailable. In particular, the .NET/IronBrew test did not run.
- 19 synthetic VM programs compared against recovered Lua on Lua5.4 and LuaJIT
  (38 differential tests), plus rejection/budget/input-dependence tests.
- Worker CLI emits a readable candidate with partial status, skips fallback on
  success, and removes stale candidates when a later input is unsupported.
- Real Bubblewrap integration and minimal read-only dependency mounts passed.
- Existing initial-image CFG now rejects aliased simultaneous stores.
- Full details: `tools/luraph/LITERAL_RECOVERY.md`. No live Discord deployment.


## Current runtime-dumper scope (supersedes source recovery as the ?luraph default)

247 Node tests passed, zero skips. Python: 69 total, 61 passed, 8 dependency skips.
New tests cover both Lua runtimes, actual isolated capture, live mutations, function
bytecode records, partial results on error/child kill, unsupported-input fallback,
and the two-attachment prefix workflow. The protected development run produced
10,182 records including 1,881 steps, and stopped at a missing debug-library
requirement with incomplete frames. This was actual isolated Lua execution, not
just a parse/compile check, and not a complete application run. See DUMPER.md.
