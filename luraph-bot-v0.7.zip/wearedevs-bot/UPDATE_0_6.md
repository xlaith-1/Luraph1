# 0.6 — validated periodic application deserialization

This release improves the reusable capture pipeline, not a sample lookup table.
Input detection still runs before extraction. Reference dumps are used only by
comparison tests, never by generation. No application execution or third-party
upload is used.

## Changes

- Optional bootstrap primitive-write tracing learns serializer tag widths,
  string boundaries, and the pool-count bias from the actual loader.
- Periodic-key inference now feeds typed-pool validation and replay through the
  existing bootstrap deserializer. Reviewed masked inputs yield application
  prototype data rather than only a flat string inventory.
- Validation checks the typed pool and inferred string-span coverage, rejects
  ambiguous starts, and checks parser consumption and the VM boundary. Up to
  16 trailing bytes are allowed and reported; this is not a completeness proof.
- String uses remain attached to their recorded prototypes. Global/method-name
  heuristics no longer incorrectly move them into a wrapper-only bucket.
- Direct scalar loads require a valid destination register and operand tables.
  Complex scalar operands still require further semantic recovery.
- Existing direct-parser candidates and bounded flat fallback remain available
  for layouts the new learned model cannot validate.
- Auxiliary evidence is compact JSON, omitted above 10 MiB without discarding
  the validated Lua output. The worker and integrity manifest are version 0.6.

## Current-code results

Counts are emitted typed entries across captured prototypes, not a claim that
all source constants or function identities have been recovered.

| Input | Reference | Matched unique strings | Missing | Extra | Emitted constants | Parsed prototypes |
|---|---|---:|---:|---:|---:|---:|
| Redz | (16) | 2,653 / 2,653 | 0 | 0 | 29,629 | 1,051 |
| Message68 | (15) | 2,146 / 2,146 | 0 | 2 | 29,872 | 1,264 |
| Aurora | (14) | 1,813 / 1,813 | 0 | 4 | 25,880 | 1,054 |
| Music | (13) | 1,482 / 1,482 | 0 | 421 | 5,868 | 356 |
| Message67 | (12) | 1,188 / 1,188 | 0 | 0 | 2,499 | 314 |
| FTAP | (10) | 3,478 / 3,478 | 0 | 1 | 34,196 | 1,213 |

Message68's twelve previously missing strings are now recovered. Its extras
are `&w=150&h=150` and `&w=48&h=48`; FTAP's extra is `</b></font>`.
Generation tests rename/comment-prefix inputs to ensure independence from names
and exact input hashes. Bundled result reports therefore hash those test copies,
not the original uploaded files. The obfuscated payload is unchanged.

## Grouping is not fully equivalent to the references

Multiset matching of per-prototype unique-string sets gives:

| Input | Matching string-set signatures | Reference entries | Captured prototypes |
|---|---:|---:|---:|
| Redz | 549 | 1,031 | 1,051 |
| Message68 | 701 | 1,231 | 1,264 |
| FTAP | 598 | 1,201 | 1,213 |
| Message67 | 311 | 311 | 314 |
| Music | 165 | 356 | 356 |
| Aurora | 1,051 | 1,054 | 1,054 |

This metric ignores prototype IDs, scalar values, occurrence counts and function
identity. It is diagnostic, not proof of equivalent programs or complete dumps.
Reference IDs can be sparse. Parsed counts must not be replaced by reference
entry counts. Message67 matches all reference string-group signatures but still
has three additional captured prototypes and unverified scalar coverage.

## Validation

- Fixture-enabled targeted Node regression: **29 passed, 0 failed, 0 skipped**,
  including six paired inputs, earlier direct/two-stream fixtures, detector and
  count gates, and five new serializer/tracing tests. Runtime: 957.4 seconds.
- Default complete Node discovery: **162 passed, 0 failed, 96 skipped**; private
  fixture/environment-dependent cases are not all enabled in this invocation.
- Python discovery after installing declared dependencies: **39 passed, 0
  failed, 11 skipped**. Two stale removed-engine tests were rewritten for the
  current constant worker/attachment workflow; routing tests use `?luraph`.
  Three OS-isolated integration tests explicitly require bubblewrap, unavailable
  in this workspace. No sandbox bypass was added to production.
- Final compact-evidence smoke: small fixture returns two strings/two constants
  in one prototype; both strings remain prototype-local.

No live Discord deployment or restart was performed. Worker regressions are not
proof of a running Discord bot or successful host isolation on a new machine.

## Remaining limitations

`fullRecoveryVerified` remains false. Scalar conventions/complex operands and
exact grouping need further work. Music has 421 extra strings; Aurora has four.
The older Fetched fixture still has a known missing CR-containing string and
extra candidates. Numeric-only/no-string applications remain unsupported by the
current nonempty-string acceptance guard. Unknown layouts may fall back to a
clearly labeled string inventory or fail without output. This is not universal
Luraph support or source reconstruction.

Grouped caption:
`Successfully dumped <number> constants across <number> prototypes. Partial capture; not reconstructed source.`

Flat captures explicitly say prototype grouping was not recovered. Owner-only
prefix routing, inclusive 8 MiB input cap, and 900-second default remain intact.
