# Luraph constants update 0.2

## Changes

- Bot default and maximum upload size, current constants worker, and numbered-dump
  importer accept 8,388,608 bytes inclusive. One byte over is rejected.
- Static, bounded two-stream LPH ASCII85/raw-LZMA unpacker. Compressed streams
  capped at 8 MiB, decompressed streams at 16 MiB each; EOF and padding validated.
- External bytecode input reaches the existing AST interpreter; the decoded
  application is never run. No third-party upload or reference lookup.
- Bootstrap XOR candidate discovery now includes guarded handlers. Cipher
  selection still requires one printable-probe solution; this is heuristic,
  not a proof that every decoded string is correct.
- Increased bounded evaluator capacity for large prototypes. Per-job Node heap
  is 1 GiB (previously 256 MiB); existing OS 4 GiB address-space, 16 MiB file,
  CPU/process/file-descriptor and isolation limits remain. Table creation is
  capped at one million entries and allocations at 200,000 tables.
- Importing the CLI renderer no longer accidentally invokes its command line.
- Command registry/help now advertises only the retained Luraph engine.

## Independently generated results

References were used only for after-the-fact comparisons, never generation.
Counts below are unique byte-string sets, not function/scalar equivalence.

| Input | Reference strings | Matched | Additional candidates | Prototypes |
|---|---:|---:|---:|---:|
| Original small sample | 2 | 2 | 0 | baseline regression |
| Original Aimbot sample | 214 | 214 | 0 | baseline regression |
| message (66).txt | 466 | 466 | 0 | 148 |
| fetched.lua (5).txt | 5,464 | 5,463 | 2,826 | 1,691 |

Both new application buffers parsed to the VM boundary with zero unconsumed
bytes. Production worker timings in this workspace were about 33 seconds and
252 seconds respectively; performance depends on the host.

**Fetched remains partial.** One reference byte-string (`w\reld`, with a carriage
return) is absent. Most extra candidates contain binary bytes; their application
meaning/correctness is not established. They are preserved rather than filtered
using the reference. Numeric/boolean data and prototype grouping are not exact
reference matches or verified source reconstruction.

## Validation and deployment

`LURAPH_CONSTANT_FIXTURES=/path/to/uploads LURAPH_LARGE_FIXTURES=/path/to/uploads
node --test tests/luraph-constants.test.mjs` (run as one command) passed **8/8**,
including both older exact string regressions, both new measured comparisons,
byte-safe output, failure behavior, and the 8 MiB boundary. The fetched test
locks in the known discrepancy; passing does not mean complete recovery.
Additional local checks covered configuration boundaries and malformed streams.

Set `MAX_INPUT_BYTES=8388608` in an existing private environment and restart.
Never share the token. Explicit smaller environment settings are respected.
Use the current constants CLI, not historical recovery CLI files which retain
separate research limits. Inputs within the cap can still fail resource limits
or be unsupported; acceptance does not guarantee successful extraction.

Bubblewrap and Discord dependencies were unavailable in the test workspace;
there was no live bot restart, Discord delivery test, or end-to-end namespace
validation. The worker was tested directly. Install the required isolation and
Python dependencies on the host; do not disable isolation to make it run.
