# Workspace cleanup performed

Cleanup was performed in the Arena workspace, not by a startup script.

- Older `luraph-research/` was archived to
  `/home/user/research-archives/luraph-legacy.tar.xz`. Every file was SHA-256 checked
  against the archive before removing the expanded directory: **30.9 MiB reclaimed**.
- Superseded lowering/smoke-test directories were similarly archived and verified
  in `superseded-luraph-analysis.tar.xz`: **6.0 MiB reclaimed**.
- Third-party Git internals, generated `bin`/`obj` trees, user-specific IDE files,
  stale generated samples and optional debug-symbol files were removed:
  **6.0 MiB of generated clutter deleted**.

Total reclaimed by these operations: approximately **43 MiB**. New engine sources,
installed dependencies and compiled runtimes consume some of that space.

Uploads, previously delivered code, current v14.7 data, source code and working
engine runtimes were preserved. Archive indexes and a detailed JSON cleanup report
are in `/home/user/research-archives/`. Restore an archive with:

```bash
tar -xJf /home/user/research-archives/luraph-legacy.tar.xz -C /home/user
```

The archives and private uploads are not included in the bot distribution.
