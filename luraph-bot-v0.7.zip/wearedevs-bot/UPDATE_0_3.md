# Dumper 0.3 — implemented improvements and current limits

## Implemented

1. **Mixed binary/text cipher detection.** When the original short-probe solver
   is ambiguous or fails, a bounded consensus fallback uses up to 24 independent
   strings, captured XOR operands, a minimum supporting fraction, and a runner-up
   margin. Binary bytes are retained, not filtered from output. This supports
   pools that previously failed because their first few strings were binary.
   Cipher detection is still heuristic, not proof of complete recovery.
2. **Cipher deadlines.** Key search observes the same capture deadline instead
   of running outside the AST interpreter's clock. Ambiguous candidate storage
   is bounded; a tie is never silently resolved by choosing the first key.
3. **Parse once per job.** Retry evaluators reuse the read-only normalized AST,
   while keeping separate evaluation state and the existing VM boundary.
4. **No stale success after failure.** Prior output is cleared before validating
   a replacement input, including oversized or missing inputs.
5. **Failure cleanup.** Temporary normalized loaders, unpacked buffers and
   unfinished output are removed on failure as well as success.
6. **Better unsupported-format reports.** Reports retain candidate-attempt
   diagnostics and distinguish a parsed bootstrap from a captured application.
   Independent-window periodic-byte detection records an encoding hypothesis,
   never treats a statistical mode as an authenticated decryption key.
7. **Byte-aware normalization.** Input is read as bytes; newline conversion is
   applied explicitly to Lua long strings rather than by Python text I/O to
   the whole source.

The 8 MiB upload cap, owner-only prefix workflow, application-execution block,
no-upload policy and OS isolation requirements remain.

## Investigation of the supplied Redz input/reference pair

Source URL: https://raw.githubusercontent.com/UCT-hub/main/refs/heads/main/redz-v2

The examined copy claims Luraph 15.0 in its header. That claim is not a structural
version certificate. Input SHA-256:
`a1a4341ab15dc931801a8704a4bbd26bbb11db3e8204943cd64cd7ecd7dd7f38`.

The attached reference contains 1,031 prototype entries and 2,653 unique string
values. It was parsed as data; it was never used to generate constants or as a
sample lookup. Reference SHA-256:
`73215946b12a72e9c8644b7d2678ac830f62d963f4bab96565e12a690b7bf098`.

The input independently reaches the bootstrap VM boundary after parsing 64,476
bytes of a 650,056-byte buffer. The remaining 585,580 bytes show a strong
8-position repeating byte pattern in disjoint windows. A research-only XOR
hypothesis exposes regular-looking records, but the application serializer and
string mapping are not verified. It is unsafe to use those observations alone
as a successful dump.

**This Redz v15 input is still unsupported for application constant capture.**
There is no claimed reference match, reconstructed source, or “all Luraph”
support. The other dumper's exact implementation cannot be recovered merely
from the input/output pair. Speculative deserialization experiments remain
outside production. The bot will report an honest failure for this input,
not return bootstrap strings as application constants.

## Tests

All 13 tests passed with the old and large fixtures enabled, including:
- Original small/Aimbot exact unique string matches: 2/2 and 214/214.
- Message66 exact unique string match: 466/466.
- Fetched retains its known partial comparison: 5,463/5,464 reference strings,
  plus 2,826 additional candidates; no completeness claim.
- Mixed binary-prefix cipher recovery, ambiguity, expired deadline, 8 MiB
  boundary, stale-file rejection, periodic diagnostics and newline rules.

Run from the project directory:

```sh
LURAPH_CONSTANT_FIXTURES=/path/to/uploads \
LURAPH_LARGE_FIXTURES=/path/to/uploads \
node --test tests/luraph-constants.test.mjs tests/luraph-v03.test.mjs
```

The new cipher fallback is tested with independently generated synthetic cipher
records, not claimed as a successful extraction of the Redz sample.

## Deployment

These changes are in the bot worker and its explicit sandbox dependency mounts.
Set `MAX_INPUT_BYTES=8388608` on an existing installation if it still overrides
that value with the old cap. Install the existing requirements and Bubblewrap
on Linux. This update was tested directly; it was **not restarted on Discord**
in this turn. No running bot process was found in the current workspace.
