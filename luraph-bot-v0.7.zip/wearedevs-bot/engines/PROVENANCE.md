# Engine provenance and patches

Primary repository: https://github.com/memcpython/lua-deobfuscators
Pinned commit: `d14f8520a8191a71f0049ea6af82da252d8a7c08`
Upstream credit: **memcpython / lsd**. MIT license is retained at `upstream/LICENSE`.
Engine names/algorithms belong to their upstream authors, not this wrapper.

Missing IronBrew2 dependency restored from:
https://github.com/Trollicus/ironbrew-2
Pinned commit: `4063f3aa6b24d24c0d3ce44da55dbd9d591c2cfd`
MIT license retained in `upstream/ironbrew-dependency/LICENSE` (DefCon42).
Bundled unluac JARs are retained from upstream unchanged.

## Local changes

- Correct IronBrew2Deobfuscator's missing ProjectReference to the vendored dependency.
- Retarget the dependency from .NET Core 3.1 to .NET 8 and remove the obsolete
  preview CodePages package reference; the .NET 8 framework supplies it.
- Remove committed `obj`, `bin`, `node_modules`, Git internals and user-specific
  build leftovers from the distribution. Dependencies rebuild from source.
- LuaObfuscator exposes a progress callback after transformation stages.
- Obfuscator.io exposes a progress callback after successful transformation passes.
- Goofyscator attempts a raw lifted-source checkpoint before optimization.
- Hercules streams unluac output to a source checkpoint (including partial error
  output) and saves source before post-processing. Its internal decompiler timeout
  follows the job budget.
- IronBrew2 attempts fallback source output before bytecode/unluac processing.
- `run-node.mjs` atomically saves checkpoints; errors do not delete existing output.

The bot uses these outputs without certifying full recovery. No fallback is
invented before source exists, and no partial bytecode/JSON dump is mislabeled as
recovered source. Upstream algorithms can still fail or produce incorrect code.

## Luraph static fallback (2026-09-13)

- https://github.com/binxgtl/luau-vmp-deobf
- Commit `5313d53165d64207e44be533358f2334c0657ee8`, MIT.
- Vendored `luauvmp/`, `tools/`, and LICENSE unchanged; wrapper in
  `engines/luraph-unpack.py` calls only static loader unpacking.
- No Lune execution or lua.expert calls in the production fallback.
- `zstandard==0.25.0` is installed with Python requirements.
- Local numbered-dump importer is independently implemented. The 2zvh runtime
  dumper was reviewed but not incorporated or executed. No license was found
  in its reviewed checkout.
