#!/usr/bin/env python3
"""Static-only best-effort checkpoint. Never executes Lua or uploads artifacts."""
import json,sys,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'upstream'/'luau-vmp-deobf'))

def main():
    source_path,out=map(Path,sys.argv[1:3]);out.mkdir(parents=True,exist_ok=True)
    if source_path.stat().st_size>524288:raise ValueError('input too large')
    from luauvmp import luraph_loader
    source=source_path.read_text(encoding='utf8',errors='surrogateescape')
    vm,bytecode=luraph_loader.unpack(source)
    if not vm or len(vm)>8*1024**2:raise ValueError('VM source size outside limits')
    header=b'-- PARTIAL RESULT: statically unpacked Luraph VM interpreter.\n-- This is NOT reconstructed application source. No Lua payload was executed.\n'
    temp=out/'unpacked.vm.lua.tmp';temp.write_bytes(header+vm);os.replace(temp,out/'unpacked.vm.lua')
    if len(bytecode)<=8*1024**2:(out/'unpacked.bytecode.bin').write_bytes(bytecode)
    (out/'unpack.report.json').write_text(json.dumps({'kind':'unpacked-vm','vmBytes':len(vm),'bytecodeBytes':len(bytecode),'luaExecuted':False,'thirdPartyUpload':False,'fullRecoveryVerified':False},indent=2))
    print('LURAPH_ARTIFACT_UNPACKED_VM',file=sys.stderr)

if __name__=='__main__':
    try:main()
    except Exception as e:
        # No raw source fragments or private paths in chat-facing diagnostics.
        print('LURAPH_STATIC_UNPACK_UNSUPPORTED: '+type(e).__name__,file=sys.stderr)
        sys.exit(2)
