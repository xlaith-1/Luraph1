"""Pinned Luraph-v15-only plugin registry for the Discord integration."""
from obfuscators.base import Obfuscator, Job
from obfuscators.luraph_v15 import LuraphV15
PLUGINS = [LuraphV15()]
def by_name(name):
    if name == "luraph_v15": return PLUGINS[0]
    raise KeyError("Only luraph_v15 is installed")
def detect(source):
    plugin=PLUGINS[0]
    return plugin, plugin.detect(source)
