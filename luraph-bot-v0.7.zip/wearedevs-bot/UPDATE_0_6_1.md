# 0.6.1 — embedded loader after Roblox prelude

The submitted 25ms_get file failed at `Unknown global workspace` before reaching
its Luraph loader. A guarded AST selector now isolates a reviewed terminal
loader when preceded by independent Roblox code. The prelude is not executed,
mocked, or included in the constant dump. Shared identifiers, environment
mutation/dynamic loading, and multiple VM-bearing regions reject isolation.
The report and Lua header explicitly declare loader-only coverage; skipped side
effects are not modeled and whole-program equivalence is not claimed.

Submitted file result: 1,525 emitted constant entries, 67 parsed prototypes,
173 unique strings. This remains a partial capture without a reference-based
completeness claim. Production bubblewrap run returned exit 0 with a validated
Lua artifact. Targeted tests: 17 passed, 0 failed, 2 unrelated private fixtures
skipped. Includes the submitted file, small/Aimbot regressions, serializer tests,
and selector rejection/output-disclosure tests.

The running bot was restarted and its Discord connection verified after patching.
