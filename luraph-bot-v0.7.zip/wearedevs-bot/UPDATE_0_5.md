# 0.5 — detection-first routing and broader periodic-payload recovery

## Pipeline

1. Enforce the inclusive 8 MiB input limit and remove stale job output.
2. Lexically classify the input **before extraction**. Comments and quoted
   strings cannot impersonate `buffer`, `bit32`, functions, or LPH containers.
3. Distinguish existing constant tables and numbered inventories from obfuscated
   input. Constant tables are rejected as already-dumped data; numbered text
   inventories use an explicitly labeled import path, not a fresh dump claim.
4. For two-stream LPH containers, validate bounded ASCII85/raw-LZMA unpacking and
   inspect the inner loader. For inline buffer loaders, inspect directly.
5. Require the reviewed VM-factory AST structure, then validate the captured
   factory boundary and dispatcher. A version banner is metadata, not proof.
6. Attempt application deserialization. If unavailable, use bounded periodic
   tagged-pool inference and independently constrained cipher validation.
7. Syntax-check the generated Lua and derive counts from its emitted entries.

No decoded application is executed, no reference lookup is used in generation,
and no source is uploaded to third parties. The sandbox does not mount the
reference uploads, sample-result directories, or research archives.

## Broader recovery

The periodic path previously searched one ambiguous low bit per key lane. It
now searches one, two, then three bits as necessary, subject to operation and
wall-clock limits. Compact-number runs constrain the remaining lanes. Repeated
interior seeds are skipped only when same-phase tag equality demonstrates the
same constraint set. This removes redundant work rather than lifting the cap.
Uniform data is rejected early instead of exhausting the inference budget.

This extension independently recovered Redz's entire reference string set and
produced a useful but incomplete Message68 string inventory. It is still a
heuristic string-pool extractor, not a universal Luraph deserializer.

## Exact pairings and results

References were parsed only for after-the-fact comparisons. Generation tests
also rename the input and prepend an unrelated comment, changing the input hash.

| Obfuscated input | Reference | Matched unique strings | Missing | Extra | Parsed application prototypes |
|---|---|---:|---:|---:|---:|
| Link 1: Redz | constants (16) | 2,653 / 2,653 | 0 | 0 | Not recovered |
| message (68) | constants (15) | 2,134 / 2,146 | 12 | 2 | Not recovered |
| Aurora | constants (14) | 1,813 / 1,813 | 0 | 4 | 1,054 |
| Link 2: YouTube Music Player | constants (13) | 1,482 / 1,482 | 0 | 421 | 356 |
| message (67) | constants (12) | 1,188 / 1,188 | 0 | 0 | Not recovered |

Detected paths:
- Redz: inline buffer VM + periodic masked pool; banner claims v15.0.
- Message68: inline buffer VM + periodic masked pool; exact version unverified.
- Aurora: inline buffer VM + direct application parse; banner claims v14.7.
- Music: two-stream ASCII85/raw-LZMA container + direct application parse.
- Message67: two-stream container + periodic masked pool; exact version unverified.

Matching unique strings does not certify scalars, prototype membership, original
names, source equivalence, or complete coverage. Extra candidates are preserved,
not removed using the reference. Equal prototype counts do not by themselves
prove identical function grouping. Message68's missing/extra values are recorded
in the result comparison JSON. No v14.9-wide or all-Luraph support is claimed.

## Success messages and count definition

For grouped captures:

> Successfully dumped 4598 constants across 356 prototypes. Partial capture; not reconstructed source.

For the current Aurora result, the corresponding counts are 24,228 and 1,054.
`constantCount` counts emitted per-prototype string/number/boolean entries, not
string occurrences. Wrapper entries and closure edges are counted separately
or excluded; `countBasis` records the definition in the report. These counts
are output-entry counts, not a completeness certificate.

For a flat result:

> Successfully dumped 2653 string constants. Flat inventory only; prototype grouping was not recovered.

Flat reports use `prototypeCount: null`, never an invented zero or a prototype
count copied from the reference. A timeout, error or unchecked report cannot
produce the successful grouped message.

## Tests and deployment

The full 24-case run exposed an operation-budget failure on Message68 after
adding stricter accounting; the other 23 cases passed. Duplicate-seed removal
fixed it. The subsequent 16-case verification run, including all five new pairs,
FTAP, detection, stale-output, cipher and deadline tests, passed **16/16 with no
skips**. The earlier eight constant regressions passed in the full run. Counts,
caption behavior and rejection of a modified installation were also checked.
Logs are retained rather than relabeling the failed run as a clean full run.

Run all tests from the project root:

```sh
LURAPH_CONSTANT_FIXTURES=/path/to/uploads \
LURAPH_LARGE_FIXTURES=/path/to/uploads \
LURAPH_148_INPUT=/path/to/FTAP.lua \
LURAPH_BATCH_FIXTURES=/path/to/batch05 \
node --test tests/luraph-constants.test.mjs tests/luraph-v03.test.mjs tests/luraph-148.test.mjs tests/luraph-routing.test.mjs
```

The bot checks `luraph-release-manifest.json` before starting a job to detect
accidental partial installs (including a newer CLI paired with an older capture
module). These are **code checksums**, not input-to-output lookup keys. This is
not a signed security boundary. After intentional development edits, regenerate
with `python scripts/build_luraph_manifest.py`; do not regenerate automatically
at startup to hide mismatched files.

The live Discord process was not restarted in this turn. Install the complete
release, retain Bubblewrap isolation, and restart on the host to deploy it.
