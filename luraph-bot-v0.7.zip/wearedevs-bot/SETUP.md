# Setup — Luraph deobfuscation bot v0.7

Follow [README.md](README.md) for the current Linux installation, private `.env` configuration, Bubblewrap checks, Discord permissions, commands (`?luraph`, `?v15`), and troubleshooting.

The former multi-engine/Docker setup instructions are obsolete. No Java/.NET or removed build script is needed. The `?v15` route uses the pinned Luau runtime in `engines/luraph-v15/runtime/`; rebuild it only with `python3 scripts/build_v15_runtime.py`.
