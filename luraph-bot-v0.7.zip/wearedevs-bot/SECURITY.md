> The original static-worker sections below describe that legacy path. See the
> current Luraph runtime-mode section for the now-default `?luraph` behavior.

# Security and privacy model

## Uploaded scripts are untrusted

The engine parses Lua into an AST. A small interpreter evaluates only constant-prefix operations explicitly implemented in `safe-prefix.mjs`: local bindings, bounded control flow, tables, byte strings, and selected math/table/string functions. It has no Lua runtime, `eval`, subprocess API, network API, or filesystem API available to uploaded code. Unknown calls such as `os.execute`, `loadstring`, and `game:HttpGet` are not executed.

Recovered output can still contain those calls. Producing an analysis file is not a safety endorsement.

## Defense in depth

- Discord CDN attachment URLs only; redirects are not followed.
- Extension, declared-size, actual-stream-size, and timeout checks.
- Generated filenames in a private temporary directory; upload names are not used as paths.
- One job per user, cooldowns, and bounded global concurrency.
- Worker invocation uses explicit arguments, not a shell.
- Worker environment omits the Discord token, `.env`, `NODE_OPTIONS`, and other parent secrets.
- Input size, evaluation-step, allocation, string-size, heap, CPU, and wall-time budgets.
- On POSIX, the worker process group is killed on timeout/cancellation.
- Generated artifacts are allowlisted; symlinks/unexpected files are rejected.
- Mention parsing is disabled; parser/source fragments are not echoed into logs or chat errors.
- Slash-command results are ephemeral. **Prefix-command results are public in the invoking channel.** Local files are cleaned up after normal completion, failure, or cancellation.

The Python launcher applies POSIX resource limits. Docker adds non-root operation, memory/CPU/PID limits, a read-only filesystem, a temporary workspace, and dropped capabilities.

## Important limitations

This is **not a proven isolation boundary against arbitrary native-code execution** in Node, Python, dependencies, or the OS. Static parser/interpreter bugs may remain. Keep dependencies and the host patched, use a dedicated container/account, restrict bot access, and monitor resource use.

The combined bot container needs network access to Discord. This deployment does **not** implement a separate network-disabled worker container or seccomp profile. The worker's uploaded-language API has no network/filesystem capabilities, but an exploited runtime could have more access than that API permits. For a hostile public service, move the worker behind a dedicated network-disabled sandbox with no bot secrets or host mounts.

The container configuration has not been Docker-built in the development workspace. Windows has fewer OS-enforced worker limits than Linux.

Temporary-file cleanup cannot be guaranteed after an abrupt host/process crash. The Docker temporary workspace disappears when the container is removed/recreated. Review your host's `/tmp` policy for bare-metal operation.

## Privacy

No source, decoded strings, usernames, attachment URLs, or tokens are deliberately logged. Logs contain generated job IDs, outcome categories, and operational connection state.

No third-party deobfuscator or AI service receives scripts. Discord still hosts attachments and result ZIPs under its own retention policies. Slash-command ephemeral visibility is not a promise of immediate deletion from Discord's infrastructure. `?deobf` input and output are public in the channel; do not use it for scripts that must remain private.

Only upload scripts you have permission to analyze. Never upload bot tokens, credentials, `.env` files, or other secrets.

## Disclosure

If you discover a bug, stop public processing, revoke any potentially exposed bot token, and fix/test the issue privately before redeploying. Do not demonstrate a vulnerability against someone else's running bot.

## Current best-effort output policy

The owner explicitly accepts incomplete source and dumps. Production prefix jobs
return already-written selected artifacts even after errors/timeouts, labeled
unverified. A Luraph dump is a Lua data file, not recovered application source.
There is no full-source-only gate on the current runtime-dump route. Older
fingerprint-gated static APIs remain separate and do not certify runtime dumps.

### Current Luraph runtime mode

`?luraph` now uses the isolated runtime dumper described in DUMPER.md. Unlike the
legacy static serializer route, **this executes instrumented uploaded/unpacked
Lua inside Bubblewrap** when supported. It has no network or credentials and uses
process/CPU/memory/file limits. The target Lua environment omits filesystem, OS,
require, FFI and debug-library capabilities. These omissions are an additional
restriction, not a replacement for OS containment. Do not expose the internal
isolation marker as an opt-out of sandboxing.

The launcher mounts only explicit trusted capture/recovery dependencies, not the
whole research workspace or bot directory. Recorder hooks are not an authenticity
or security boundary against a hostile input. Dynamic snapshots can be partial,
truncated, or affected by instrumentation/runtime compatibility. Debug-dependent
inputs stop rather than receiving unrestricted debug capabilities.

Readable input/VM Lua and a valid initial dump checkpoint are saved before runtime
execution. Flushed records survive a child timeout; a whole-worker termination may
leave only the earlier checkpoint. Selected artifacts are returned privately only
in the sense of the owner-only command gate: **the Discord channel can see replies
and attachments**, so use a private channel. Temporary job files are then deleted.
