import test from 'node:test';import assert from'node:assert/strict';import fs from'node:fs';import os from'node:os';import path from'node:path';import{spawnSync}from'node:child_process';
import{inferCipher,decodeString,recoverReviewedCandidate}from'../worker/luraph-reviewed-aaf25cc.mjs';
test('reviewed string inference is unique, explicitly hypothesis based',()=>{
 const a=Buffer.from('25cefbe2cc642b','hex').toString('latin1'),b=Buffer.from('5d2b80d46b769d61ba0e32748a673408bafd0f','hex').toString('latin1');
 const cipher=inferCipher(a,'print');assert.deepEqual(cipher,{multiplier:193,increment:213,mask:168});assert.equal(decodeString(b,cipher),'hii!! luraph 14.7');
 assert.throws(()=>inferCipher(a,'incorrect'));assert.throws(()=>inferCipher('abc','x'));
});
test('reviewed route rejects other inputs without parsing or execution',()=>{assert.equal(recoverReviewedCandidate(Buffer.from('return 42'),'untrusted invalid syntax'),null);});
test('zero capture never returns input or empty dump, including stale artifacts',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'no-capture-'));try{
 const input=path.join(dir,'input.lua'),out=path.join(dir,'result');fs.writeFileSync(input,'return 42');fs.mkdirSync(out);
 for(const name of ['luraph.dump.lua','readable.vm.lua','application.candidate.lua'])fs.writeFileSync(path.join(out,name),'stale');
 const p=spawnSync(process.execPath,['worker/luraph-dump-cli.mjs',input,out],{encoding:'utf8',timeout:10000});
 assert.equal(p.status,2,p.stderr);assert.match(p.stderr,/LURAPH_NO_CAPTURE/);assert.deepEqual(JSON.parse(p.stdout).artifacts,[]);
 for(const name of ['luraph.dump.lua','readable.vm.lua','application.candidate.lua'])assert.equal(fs.existsSync(path.join(out,name)),false);
 assert.equal(JSON.parse(fs.readFileSync(path.join(out,'report.json'))).fullRecoveryVerified,false);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('exact new sample CLI returns candidate and genuine prototype, not protected input',{skip:!process.env.LURAPH_REVIEWED_SAMPLE},()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'reviewed-sample-'));try{
 const p=spawnSync(process.execPath,['worker/luraph-dump-cli.mjs',process.env.LURAPH_REVIEWED_SAMPLE,dir,'python3'],{encoding:'utf8',timeout:20000});assert.equal(p.status,0,p.stderr);
 const source=fs.readFileSync(path.join(dir,'application.candidate.lua'),'utf8'),r=JSON.parse(fs.readFileSync(path.join(dir,'report.json')));
 assert.match(source,/print\("hii!! luraph 14\.7"\)/);assert.ok(source.length<500);assert.equal(r.fullRecoveryVerified,false);assert.equal(r.originalStringDecoderVerified,false);
 assert.deepEqual(r.trace.map(x=>x.pc),[1,6,2,3,4,5,8,9]);assert.equal(r.instructionCount,9);assert.ok(fs.statSync(path.join(dir,'luraph.dump.lua')).size>1000);assert.equal(fs.existsSync(path.join(dir,'readable.vm.lua')),false);
 assert.throws(()=>recoverReviewedCandidate(fs.readFileSync(process.env.LURAPH_REVIEWED_SAMPLE),'modified'),/normalized source mismatch/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
