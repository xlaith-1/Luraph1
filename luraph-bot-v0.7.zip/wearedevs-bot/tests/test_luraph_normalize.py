import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

TOOL=Path(__file__).resolve().parents[1]/'tools/luraph/normalize_for_analysis.py'

class LuraphNormalizerTests(unittest.TestCase):
    def normalize(self,source):
        with tempfile.TemporaryDirectory() as tmp:
            src=Path(tmp)/'input.lua';out=Path(tmp)/'analysis.lua';src.write_text(source)
            p=subprocess.run([sys.executable,str(TOOL),str(src),str(out),'--preserve-compound'],capture_output=True,text=True,timeout=10)
            return p,out.read_text() if out.exists() else None

    def test_compound_member_and_index_are_preserved(self):
        p,text=self.normalize('t.x += 1; t[f()] ^= 2;')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertEqual(text,'t.x += 1; t[f()] ^= 2;')

    def test_reserved_marker_is_rejected_as_code_not_as_string(self):
        p,_=self.normalize('__analysis_continue()')
        self.assertNotEqual(p.returncode,0)
        self.assertIn('Reserved analysis marker',p.stderr)
        p,text=self.normalize('return "__analysis_continue"')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertNotIn('__analysis_continue',text)

    def test_luau_literals_and_continue_are_normalized(self):
        p,text=self.normalize('local n=0b1_0+0Xf_f;while true do continue end')
        self.assertEqual(p.returncode,0,p.stderr)
        self.assertIn('n=2+255',text)
        self.assertIn('__analysis_continue()',text)
