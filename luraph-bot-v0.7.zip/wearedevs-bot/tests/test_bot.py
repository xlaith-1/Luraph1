import asyncio
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile
from bot.config import Settings, ROOT
from bot.jobs import Gate, JobError, archive_results, run_worker, complete_source_file
from bot.main import DeobfuscatorBot, download_attachment

class Attachment:
    def __init__(self, filename='script.lua', size=10, url='https://cdn.discordapp.com/attachments/a/b/script.lua'):
        self.filename, self.size, self.url = filename, size, url
class Content:
    def __init__(self, chunks): self.chunks = chunks
    async def iter_chunked(self, _):
        for chunk in self.chunks: yield chunk
class Response:
    def __init__(self, chunks, status=200): self.content, self.status = Content(chunks), status
    async def __aenter__(self): return self
    async def __aexit__(self, *_): pass
class Session:
    def __init__(self, chunks, status=200): self.chunks, self.status = chunks, status
    def get(self, url, **kwargs):
        assert kwargs['allow_redirects'] is False
        return Response(self.chunks, self.status)

class GateTests(unittest.TestCase):
    def test_capacity_and_per_user_limit(self):
        gate=Gate(1,30); gate.enter(1)
        with self.assertRaises(JobError): gate.enter(1)
        with self.assertRaises(JobError): gate.enter(2)
        gate.leave(1); gate.enter(2)
    def test_cooldown_survives_completion(self):
        gate=Gate(1,30); gate.enter(1); gate.leave(1)
        with self.assertRaises(JobError): gate.enter(1)
    def test_expired_user_entries_are_pruned(self):
        gate=Gate(2,30); gate.last={1:-float('inf')}; gate.enter(2)
        self.assertNotIn(1,gate.last)

class ArchiveTests(unittest.TestCase):
    def test_only_expected_files_are_zipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); result=root/'result';result.mkdir();(result/'report.md').write_text('report')
            archive_results(result,root/'result.zip',10000)
            with zipfile.ZipFile(root/'result.zip') as z: self.assertEqual(z.namelist(),['report.md'])
            (result/'unexpected.txt').write_text('no')
            with self.assertRaises(JobError):archive_results(result,root/'bad.zip',10000)
    def test_rejects_symlinks(self):
        if os.name!='posix':self.skipTest('POSIX symlinks')
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);out=root/'out';out.mkdir();(root/'private').write_text('secret');(out/'report.md').symlink_to(root/'private')
            with self.assertRaises(JobError):archive_results(out,root/'result.zip',10000)
    def test_output_upload_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);out=root/'out';out.mkdir();(out/'report.md').write_text('report')
            with self.assertRaises(JobError):archive_results(out,root/'result.zip',1)

class StrictOutputTests(unittest.TestCase):
    def test_missing_or_partial_certification_never_releases_a_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'recovered.lua').write_text('return 1')
            for report in [{}, {'status':'partial-source','fullRecoveryVerified':True},
                           {'status':'full-source','fullRecoveryVerified':False},
                           {'status':'transformed','remainingDispatcherBlocks':0,'unresolvedCallbacks':0},
                           {'status':'full-source','fullRecoveryVerified':True,'remainingDispatcherBlocks':1,'unresolvedCallbacks':0},
                           {'status':'full-source','fullRecoveryVerified':True,'remainingDispatcherBlocks':0,'unresolvedCallbacks':1}]:
                with self.assertRaises(JobError):complete_source_file(report,root,10000)
    def test_future_verified_result_selects_only_standalone_lua(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);source=root/'recovered.lua';source.write_text('return 42\n')
            (root/'report.md').write_text('Not part of code output')
            report={'status':'full-source','fullRecoveryVerified':True,'remainingDispatcherBlocks':0,'unresolvedCallbacks':0}
            result=complete_source_file(report,root,10000)
            self.assertEqual(result,source)
            self.assertEqual(result.read_text(),'return 42\n')
            with self.assertRaises(JobError):complete_source_file(report,root,1)
            source.unlink()
            with self.assertRaises(JobError):complete_source_file(report,root,10000)

class AsyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_registered_commands_and_permissions(self):
        settings=Settings('not-a-real-token',frozenset({1}),frozenset({2}),None,524288,2,30,25,False)
        bot=DeobfuscatorBot(settings)
        self.assertFalse(hasattr(bot, 'tree'))
        self.assertTrue(bot.intents.message_content)
        class I: guild_id=1;channel_id=2;user=type("User",(),{"id":1442928403601690657})()
        self.assertTrue(bot.permitted(I()))
        I.guild_id=3;self.assertFalse(bot.permitted(I()))
        I.guild_id=None;self.assertFalse(bot.permitted(I()))
        await bot.close()
    async def test_download_limits_real_stream(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'input.lua'
            with self.assertRaises(JobError):
                await download_attachment(Session([b'x'*20]),Attachment(size=1),target,10)
    async def test_rejects_extensions_and_external_hosts(self):
        with tempfile.TemporaryDirectory() as tmp:
            for attachment in [Attachment(filename='archive.zip'),Attachment(url='https://example.org/a.lua'),Attachment(size=0),Attachment(size=101)]:
                with self.assertRaises(JobError):await download_attachment(Session([b'ok']),attachment,Path(tmp)/'input.lua',100)
    async def test_download_is_saved_under_generated_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)/'input.lua'
            await download_attachment(Session([b'return 1']),Attachment(filename='../../anything.lua',size=8),target,100)
            self.assertEqual(target.read_bytes(),b'return 1')
    async def test_real_constants_worker_rejects_unobfuscated_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);input_file=root/'input.lua';input_file.write_text('return 1')
            proc=await asyncio.create_subprocess_exec('node',str(ROOT/'worker/luraph-constants-cli.mjs'),str(input_file),str(root/'out'),stderr=asyncio.subprocess.PIPE)
            await proc.communicate()
            self.assertEqual(proc.returncode,2)
            report=json.loads((root/'out/report.json').read_text())
            self.assertEqual(report['status'],'unsupported-or-incomplete')
            self.assertFalse((root/'out/luraph-constants.lua').exists())
    async def test_offline_prefix_help_replaces_slash_commands(self):
        from bot.engines import help_text
        settings=Settings('not-a-real-token',frozenset({1}),frozenset({2}),None,524288,2,30,900,False)
        bot=DeobfuscatorBot(settings)
        self.assertFalse(hasattr(bot,'tree'))
        self.assertIn('?help',help_text(900))
        self.assertIn('partial',help_text(900))
        await bot.close()
    async def test_worker_timeout_is_bounded(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'input.lua').write_text('return 1')
            with self.assertRaises(JobError) as caught:
                await run_worker(root/'input.lua',root/'out',0.001)
            self.assertIn('time limit',str(caught.exception))
    async def test_prefix_command_returns_partial_constants(self):
        settings=Settings('not-a-real-token',frozenset({1}),frozenset({2}),None,524288,2,30,25,False)
        bot=DeobfuscatorBot(settings)
        payload=b'return 1'
        bot.session=Session([payload])
        class Progress:
            returned=None; temporary_path=None; text=None
            async def edit(self, **kwargs):
                self.text=kwargs.get('content')
                if kwargs.get('attachments'):
                    upload=kwargs['attachments'][0]
                    self.temporary_path=Path(upload.fp.name).parent
                    self.returned=upload.fp.read()
        class Channel:
            id=2
            def permissions_for(self, member):
                return type('Permissions',(),{'send_messages':True,'attach_files':True})()
        class Message:
            content='?luraph';webhook_id=None
            author=type('Author',(),{'id':1442928403601690657,'bot':False})()
            guild=type('Guild',(),{'id':1,'filesize_limit':8*1024*1024,'me':object()})()
            channel=Channel()
            attachments=[Attachment(size=len(payload))]
            progress=Progress(); replies=[]
            async def reply(self, text, **kwargs):
                assert kwargs.get('mention_author') is False
                self.replies.append(text)
                return self.progress
        message=Message()
        from unittest.mock import AsyncMock
        from bot.engines import EngineResult
        with tempfile.TemporaryDirectory() as tmp:
            source=Path(tmp)/'luraph-constants.lua';source.write_text("return {protos={[0]={strings={[0]='one'},numbers={},booleans={}}}}")
            (Path(tmp)/'report.json').write_text(json.dumps({'stage':'download-ready','syntaxChecked':True,'constantCount':1,'prototypeCount':1,'groupingRecovered':True}))
            with patch('bot.main.run_engine',new=AsyncMock(return_value=EngineResult('luraph',source,0,False,.1))):
                await bot.on_message(message)
        self.assertIsNotNone(message.progress.returned)
        self.assertIn(b'one',message.progress.returned)
        self.assertIn('Successfully dumped 1 constants across 1 prototypes',message.progress.text)
        self.assertFalse(bot.gate.active)
        self.assertIn('Partial capture',message.progress.text)
        bot.session=None
        await bot.close()

    async def test_prefix_help_ping_permissions_and_ignored_messages(self):
        settings=Settings('not-a-real-token',frozenset({1}),frozenset({2}),None,524288,2,30,25,False)
        bot=DeobfuscatorBot(settings)
        class Channel:
            id=2
            attach=True
            def permissions_for(self, member):
                return type('Permissions',(),{'send_messages':True,'attach_files':self.attach})()
        class Message:
            content='?luraph';webhook_id=None
            author=type('Author',(),{'id':1442928403601690657,'bot':False})()
            guild=type('Guild',(),{'id':1,'me':object()})()
            channel=Channel();attachments=[]
            replies=[]
            async def reply(self, text, **kwargs): self.replies.append(text)
        m=Message()
        await bot.on_message(m)
        self.assertIn('same message',m.replies[-1])
        m.content='?ping'; await bot.on_message(m)
        self.assertIn('Online',m.replies[-1])
        m.content='?luraph';m.attachments=[Attachment(),Attachment()];await bot.on_message(m)
        self.assertIn('exactly one',m.replies[-1])
        m.attachments=[Attachment()];m.channel.attach=False;await bot.on_message(m)
        self.assertIn('Attach Files',m.replies[-1])
        count=len(m.replies);m.content='ordinary message';await bot.on_message(m)
        m.content='?luraph';m.author.bot=True;await bot.on_message(m)
        self.assertEqual(len(m.replies),count)
        await bot.close()

    async def test_prefix_can_be_disabled_for_maintenance(self):
        settings=Settings('not-a-real-token',frozenset(),frozenset(),None,524288,2,30,25,False,False)
        bot=DeobfuscatorBot(settings)
        self.assertFalse(bot.intents.message_content)
        self.assertFalse(bot.intents.guild_messages)
        await bot.close()

    async def test_bad_worker_input_produces_safe_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'input.lua').write_text('function malformed(')
            with self.assertRaises(JobError) as caught:await run_worker(root/'input.lua',root/'out',25)
            self.assertNotIn('malformed(',str(caught.exception))

if __name__=='__main__': unittest.main()
