-- Synthetic recorder tests only: no protected input is loaded or executed.
local Recorder=assert(loadfile(arg[1]))()
local case=arg[2]
local lines={}
local function sink(line) lines[#lines+1]=line end
local function new(options)
    options=options or {};options.sessionId='fixture';options.emit=options.emit or sink
    return Recorder.new(options)
end
if case=='status-output' then
    local r=new({maxEvents=2});local f=r:enter('main','root');r:step(f,0,1,{})
    assert(not pcall(function()r:step(f,1,2,{})end))
    local status,encoded=r:finish('budget');assert(status.events==#lines)
    io.stdout:write(encoded);return
elseif case=='basic' then
    local r=new();local proto={};r:registerPrototype(proto,'p7')
    local touched=false
    local hostile=setmetatable({},{__tostring=function()touched=true;error('called')end,__index=function()touched=true;error('called')end,__pairs=function()touched=true;error('called')end})
    local operands=setmetatable({a=1,bytes='\000\255',missing=Recorder.NIL,ref=hostile,proto=proto,flag=true,nan=0/0,posinf=math.huge,negative=-0.0},{__pairs=function()touched=true;error('called')end})
    local f=r:enter('main','p0');r:step(f,0,7,operands);operands.a=2;r:step(f,0,9,operands);r:exit(f)
    assert(not touched);assert(r:finish().valid)
elseif case=='calls' then
    local r=new()
    local returned={n=0}
    local function collect(...)returned={n=select('#',...),...}end
    collect(r:withFrame('main','root',function(a,b,c)
        assert(a==1 and b==nil and c==3)
        r:step(r:current('main'),1,11,{})
        r:withFrame('main','root',function()r:step(r:current('main'),2,12,{})end)
        r:step(r:current('main'),3,13,{})
        return nil,42,nil
    end,1,nil,3))
    assert(returned.n==3 and returned[1]==nil and returned[2]==42 and returned[3]==nil)
    assert(r:finish().incompleteFrames==0)
elseif case=='error' then
    local r=new();local problem={}
    local ok,why=pcall(function()r:withFrame('main','root',function()r:step(r:current('main'),1,8,{});error(problem)end)end)
    assert(not ok and rawequal(why,problem));assert(r:finish().valid)
elseif case=='threads' then
    local r=new();local a=r:enter('one','root');r:step(a,0,3,{})
    local b=r:enter('two','root');r:step(b,20,4,{})
    r:step(a,1,5,{});r:gap('two');r:step(b,21,6,{})
    r:exit(a);r:exit(b);assert(r:finish().valid)
elseif case=='limits' then
    local r=new({maxEvents=2});local f=r:enter('main','root');r:step(f,0,1,{})
    assert(not pcall(function()r:step(f,1,2,{})end))
    local s=r:finish('budget');assert(not s.valid and s.events==2 and s.incompleteFrames==1)
elseif case=='sink' then
    local r=new({emit=function()error('do not leak this sink exception')end})
    assert(not pcall(function()r:enter('main','root')end));assert(r:finish().error=='Event sink failed')
elseif case=='reentrant' then
    local r;r=new({emit=function()r:gap('main')end})
    assert(not pcall(function()r:enter('main','root')end));assert(not r:finish().valid)
elseif case=='operand-limit' then
    local r=new({maxStringBytes=2});local f=r:enter('main','root')
    assert(not pcall(function()r:step(f,1,2,{a='too long'})end));assert(not r:finish().valid)
elseif case=='bad-frame' then
    local r=new();local a=r:enter('main','a');local b=r:enter('main','b')
    assert(not pcall(function()r:step(a,1,2,{})end));assert(not r:finish().valid)
elseif case=='integer64' then
    assert(math.type,'integer64 scenario requires Lua5.4')
    local r=new();local f=r:enter('main','root');r:step(f,0,0,{large=9223372036854775807});r:exit(f)
elseif case=='depth' then
    local r=new({maxDepth=1});r:enter('main','root')
    assert(not pcall(function()r:enter('main','child')end));assert(not r:finish().valid)
elseif case=='vm-layouts' then
    local r=new()
    local layouts={{'opcode','amount','next',1,9,17},{3,7,11,0,100,249},{'tag','literal','destination',500,700,900}}
    for index,l in ipairs(layouts) do
        local function execute(record)
            local code={[l[4]]={[l[1]]=l[6],[l[2]]=1,[l[3]]=l[5]},[l[5]]={[l[1]]=l[6],[l[2]]=2,[l[3]]=l[5]}}
            local pc,acc,hits=l[4],0,0
            local f=record and r:enter('main','layout'..index)
            while acc<9 do
                hits=hits+1;assert(hits<10)
                local ins=code[pc]
                if record then r:step(f,pc,ins[l[1]],{amount=ins[l[2]],destination=ins[l[3]]}) end
                acc=acc+ins[l[2]]
                if pc==l[5] then ins[l[2]]=3 end
                pc=ins[l[3]]
            end
            if record then r:exit(f) end
            return acc
        end
        assert(execute(false)==execute(true))
    end
    assert(r:finish().valid)
elseif case=='late-prototype' then
    local r=new();local p={};local f=r:enter('main','root');r:step(f,0,1,{p=p})
    assert(not pcall(function()r:registerPrototype(p,'late')end));assert(not r:finish().valid)
elseif case=='prototype-change' then
    local r=new();local p={};r:registerPrototype(p,'one')
    assert(not pcall(function()r:registerPrototype(p,'two')end));assert(not r:finish().valid)
else error('Unknown test scenario') end
for i=1,#lines do io.stdout:write(lines[i])end
