import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {instrument147} from '../tools/luraph/instrument147.mjs';
const recorder=fileURLToPath(new URL('../tools/luraph/trace147-recorder.lua',import.meta.url));
const importer=fileURLToPath(new URL('../tools/luraph/trace147-cli.mjs',import.meta.url));
function fixture(seed=0,mode='plain'){
 const p='prototype'+seed,code='instructions'+seed,constant='values'+seed,pc='position'+seed,op='operation'+seed;
 const cs=seed+1,ks=seed+4;
 let first=`r=${constant}[${pc}]`,second=`r=r+${constant}[${pc}]`,result='r';
 if(mode==='mutation')first+=`; ${code}[${pc}]=11; ${constant}[${pc}]=22; ${pc}=${pc}-1`;
 if(mode==='calls')second='if callback then r=r+callback() else r=r+22 end';
 if(mode==='threads')first+='; if callback then callback(r) end';
 if(mode==='returns')result='(r),nil,"\\000\\255",...';
 return {source:`return function(${p}) local ${code},${constant}=${p}[${cs}],${p}[${ks}]; return function(...) local callback=...; local r,${pc}=0,1; while true do local ${op}=${code}[${pc}]; if ${op}==10 then ${first} elseif ${op}==11 then ${second} elseif ${op}==12 then return ${result} else error("unexpected opcode") end ${pc}=${pc}+1 end end end`,cs,ks};
}
for(const runtime of ['lua5.4','luajit']){
 const available=spawnSync(runtime,['-v']).status===0;
 for(const [seed,mode]of [[0,'plain'],[5,'plain'],[13,'plain'],[2,'mutation'],[3,'returns'],[4,'calls'],[6,'threads'],[8,'metatable'],[9,'code-metatable']]){
  test(`${runtime}: automatic capture through status-checked importer (${seed}/${mode})`,{skip:!available},()=>{
   const dir=fs.mkdtempSync(path.join(os.tmpdir(),'auto-capture-'));
   try{
    const f=fixture(seed,mode),built=instrument147(f.source);
    assert.equal(built.report.sites.length,1);assert.equal(built.report.sites[0].opcodeSlot,f.cs);
    assert.equal(built.report.sites[0].operands[0].slot,f.ks);
    fs.writeFileSync(path.join(dir,'original.lua'),f.source,'latin1');fs.writeFileSync(path.join(dir,'instrumented.lua'),built.source,'latin1');
    let run=`local codes=${mode==='mutation'?'{10,12}':'{10,11,12}'}; local p={[${f.cs}]=codes,[${f.ks}]={20,22}}; local f=make(p); assert(f()==42)`;
    if(mode==='returns')run=`local f=make({[${f.cs}]={10,11,12},[${f.ks}]={20,22}}); local function check(...) assert(select('#',...)==7);local a,b,c,d,e,g,h=...;assert(a==42 and b==nil and c=='\\000\\255' and d==nil and e==5 and g==nil and h==7) end;check(f(nil,5,nil,7))`;
    if(mode==='calls')run=`local child=make({[${f.cs}]={10,12},[${f.ks}]={22}});local parent=make({[${f.cs}]={10,11,12},[${f.ks}]={20}});assert(parent(child)==42)`;
    if(mode==='threads')run=`local f=make({[${f.cs}]={10,11,12},[${f.ks}]={20,22}});local one=coroutine.create(function() return f(coroutine.yield) end);local two=coroutine.create(function() return f(coroutine.yield) end);for _,co in ipairs({one,two})do local ok,v=coroutine.resume(co);assert(ok and v==20)end;for _,co in ipairs({two,one})do local ok,v=coroutine.resume(co);assert(ok and v==42)end`;
    if(mode==='metatable')run=`local hits=0;local values=setmetatable({}, {__index=function() hits=hits+1; return 20 end});local f=make({[${f.cs}]={10,12},[${f.ks}]=values});local ok=pcall(f);if r then assert(not ok and hits==0)else assert(ok and hits==1)end`;
    if(mode==='code-metatable')run=`local hits=0;local code=setmetatable({}, {__index=function(_,pc) hits=hits+1; return pc==1 and 10 or 12 end});local f=make({[${f.cs}]=code,[${f.ks}]={20}});local ok,v=pcall(f);if r then assert(not ok and hits==0)else assert(ok and v==20 and hits==2)end`;
    const failed=mode==='metatable'||mode==='code-metatable';
    const harness=`local r\nif arg[1]=='capture' then local Recorder=dofile(${JSON.stringify(recorder)});local output=assert(io.open('events.jsonl','w'));r=Recorder.new{sessionId='fixture',emit=function(line) assert(output:write(line)) end};local make=dofile('instrumented.lua')(r)();${run};output:close();local status,json=r:finish();local out=assert(io.open('status.json','w'));out:write(json);out:close() else local make=dofile('original.lua');${run} end`;
    fs.writeFileSync(path.join(dir,'run.lua'),harness);
    for(const kind of ['baseline','capture']){const result=spawnSync(runtime,['run.lua',kind],{cwd:dir,encoding:'utf8',timeout:10000,maxBuffer:1024*1024});assert.equal(result.status,0,result.stderr);}
    const manifest={identity:{sourceSha256:built.report.sourceSha256,symbolNamespace:'auto-synthetic',sessionId:'fixture',executionProfile:'synthetic-no-protected-code'},inputs:[{format:'events-jsonl',path:'events.jsonl'}],producerStatus:'status.json'};
    fs.writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(manifest));
    const result=spawnSync(process.execPath,[importer,'manifest.json','evidence.json'],{cwd:dir,encoding:'utf8',timeout:10000});
    assert.equal(result.status,failed?1:0,result.stderr);
    const evidence=JSON.parse(fs.readFileSync(path.join(dir,'evidence.json')));
    assert.equal(evidence.valid,!failed);assert.equal(evidence.fullRecoveryVerified,false);
    if(mode==='mutation'){assert.equal(evidence.multiVersionSites,1);assert.equal(evidence.instructionVersions,3);}
    if(mode==='calls')assert.ok(evidence.edges.some(e=>e.relation==='resume'));
    if(mode==='threads')assert.equal(new Set(evidence.edges.map(e=>e.threadId)).size,2);
    if(failed)assert.deepEqual(evidence.edges,[]);else assert.equal(evidence.incompleteFrames.length,0);
   }finally{fs.rmSync(dir,{recursive:true,force:true});}
  });
 }
}
test('planner fails closed for missing structure and rewritten array binding',()=>{
 assert.throws(()=>instrument147('return 42'),/No unambiguous/);
 const {source}=fixture();assert.throws(()=>instrument147(source.replace('local callback=...;', 'instructions0={}; local callback=...;')),/No unambiguous/);
 assert.throws(()=>instrument147('return function() continue end'));
 assert.throws(()=>instrument147('return "\u{1f600}"'),/size/);
});
test('planner does not include an operand alias that is invisible at the opcode boundary',()=>{
 const {source}=fixture();
 const changed=source.replace('r=values0[position0]','do local values0=prototype0[9]; r=values0[position0] end').replace('r=r+values0[position0]','r=r+22');
 const result=instrument147(changed);assert.deepEqual(result.report.sites[0].operands,[]);
});
