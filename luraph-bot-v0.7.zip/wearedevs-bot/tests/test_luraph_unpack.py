import lzma
import unittest
from tools.luraph.unpack_lzma import FILTER,unpack_raw

class LuraphUnpackTests(unittest.TestCase):
    def packed(self,data):
        return lzma.compress(data,format=lzma.FORMAT_RAW,filters=[FILTER])

    def test_raw_lzma_roundtrip_not_script_execution(self):
        for data in (b'',b'local vm = ...; return vm',bytes(range(256))*30):
            decoded,padding=unpack_raw(self.packed(data))
            self.assertEqual(decoded,data);self.assertEqual(padding,0)

    def test_word_alignment_padding(self):
        packed=self.packed(b'test')
        for count in range(4):self.assertEqual(unpack_raw(packed+b'\0'*count),(b'test',count))

    def test_unknown_trailer_and_second_stream_rejected(self):
        packed=self.packed(b'test')
        for tail in (b'\x01',b'\0'*4,self.packed(b'other')):
            with self.assertRaises(ValueError):unpack_raw(packed+tail)

    def test_truncation_rejected(self):
        packed=self.packed(b'hello world'*100)
        for count in (1,4,len(packed)-1):
            with self.assertRaises((ValueError,lzma.LZMAError)):unpack_raw(packed[:-count])

    def test_bounded_expansion(self):
        with self.assertRaisesRegex(ValueError,'exceeds limit'):
            unpack_raw(self.packed(b'0'*100000),limit=100)
        for limit in (0,-1,17*1024*1024):
            with self.assertRaises(ValueError):unpack_raw(self.packed(b'x'),limit=limit)
