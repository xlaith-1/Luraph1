import shutil
import asyncio
import os
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import AsyncMock,Mock,patch
from bot.config import Settings
from bot.main import DeobfuscatorBot
from bot.engines import EngineResult,safe_worker_diagnostic,run_engine,engine_unavailable_reason
from bot.supervisor import supervise

class FailureTests(unittest.TestCase):
    def test_ironbrew_rejection_is_specific_without_leaking_raw_text(self):
        raw=b'[FAIL] input.lua: No IronBrew bytecode payload candidate was found. PRIVATE_CONTENT'
        detail=safe_worker_diagnostic('ironbrew2',raw)
        text=EngineResult('ironbrew2',None,2,False,0.1,diagnostic=detail).summary()
        self.assertIn('could not find an IronBrew',text)
        self.assertNotIn('PRIVATE_CONTENT',text)
    def test_unknown_error_text_is_not_echoed(self):
        self.assertIsNone(safe_worker_diagnostic('ironbrew2',b'private source goes here'))
        self.assertIn('host setup',safe_worker_diagnostic('ironbrew2',b'bwrap: failed namespace'))

class ResilienceTests(unittest.IsolatedAsyncioTestCase):
    async def test_long_rest_job_does_not_block_help_delivery(self):
        bot=DeobfuscatorBot(Settings('fake',frozenset({1}),frozenset(),None,524288,2,30,900,False))
        channel=SimpleNamespace(guild=SimpleNamespace(id=1))
        first=SimpleNamespace(id=100,content='?ironbrew',author=SimpleNamespace(id=1442928403601690657,bot=False),webhook_id=None)
        second=SimpleNamespace(id=101,content='?help',author=SimpleNamespace(id=1442928403601690657,bot=False),webhook_id=None)
        async def history(**kwargs):
            yield first;yield second
        channel.history=history;bot.get_channel=Mock(return_value=channel);bot.poll_channels=(2,)
        bot.is_closed=Mock(side_effect=[False,True]);release=asyncio.Event();seen=[]
        async def process(message):
            if message.id==100:await release.wait()
            seen.append(message.id)
        bot.on_message=process
        with patch('bot.main.asyncio.sleep',new=AsyncMock()):await bot.poll_prefix_messages()
        await asyncio.sleep(0)
        self.assertIn(101,seen);self.assertNotIn(100,seen)
        release.set();await asyncio.gather(*tuple(bot.prefix_delivery_tasks))
    async def test_supervisor_restarts_child_and_removes_session_temporary_data(self):
        with tempfile.TemporaryDirectory() as d:
            marker=Path(d)/'starts.txt'
            script=f"import os,pathlib; p=pathlib.Path({str(marker)!r}); p.open('a').write(os.environ['TMPDIR']+'\\n'); raise SystemExit(17)"
            code=await supervise([sys.executable,'-c',script],base_delay=.01,max_restarts=1)
            directories=marker.read_text().splitlines()
            self.assertEqual(code,17);self.assertEqual(len(directories),2)
            self.assertTrue(all(not Path(p).exists() for p in directories))
    @unittest.skipIf(engine_unavailable_reason('ironbrew2') is not None, 'IronBrew runtime dependencies are not installed')
    async def test_real_ironbrew_plain_input_explains_no_payload(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'input.lua').write_text('local x=1;print(x)')
            r=await run_engine('ironbrew2',p,20,100000)
            self.assertEqual(r.returncode,2);self.assertIsNone(r.source)
            self.assertIn('IronBrew bytecode payload',r.summary())
    async def test_watchdog_can_close_without_awaiting_its_own_task(self):
        import time
        bot=DeobfuscatorBot(Settings('fake',frozenset(),frozenset(),None,524288,2,30,900,False))
        bot.health_task=asyncio.current_task()
        bot.gateway_unhealthy_since=time.monotonic()-1000
        with patch('bot.main.asyncio.sleep',new=AsyncMock()):
            await bot.connection_health()
        self.assertTrue(bot.is_closed())
    async def test_stale_ack_is_detected_even_when_last_latency_was_fast(self):
        import time
        bot=DeobfuscatorBot(Settings('fake',frozenset(),frozenset(),None,524288,2,30,900,False))
        bot.ws=SimpleNamespace(_keep_alive=SimpleNamespace(_last_ack=time.perf_counter()-200),latency=.01)
        self.assertGreater(bot.gateway_ack_age(),190)
        bot.close=AsyncMock();bot.is_closed=Mock(return_value=False)
        with patch('bot.main.asyncio.sleep',new=AsyncMock()):await bot.connection_health()
        bot.close.assert_awaited_once()
    async def test_watchdog_preserves_active_jobs(self):
        import time
        bot=DeobfuscatorBot(Settings('fake',frozenset(),frozenset(),None,524288,2,30,900,False))
        bot.ws=SimpleNamespace(_keep_alive=SimpleNamespace(_last_ack=time.perf_counter()-200),latency=.01)
        bot.gate.active.add(123);bot.close=AsyncMock();bot.is_closed=Mock(side_effect=[False,True])
        with patch('bot.main.asyncio.sleep',new=AsyncMock()):await bot.connection_health()
        self.assertTrue(bot.restart_pending);bot.close.assert_not_awaited()
    @unittest.skipUnless(shutil.which("bwrap"), "OS-isolated integration requires bubblewrap installed")
    async def test_actual_isolated_dump_import_is_labeled_as_data(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'input.lua').write_bytes(b'[1] [string] hello\n[2] [string] world\n')
            r=await run_engine('luraph',p,20,100000)
            self.assertEqual(r.source.name,'strings.inventory.lua')
            self.assertIn('not reconstructed application source',r.summary())
            self.assertIn('hello',r.source.read_text())
    def test_vm_checkpoint_is_not_claimed_to_be_application_source(self):
        r=EngineResult('luraph',Path('unpacked.vm.lua'),0,False,.5)
        self.assertIn('Unpacked VM source',r.summary())
        self.assertIn('not reconstructed application code',r.summary())
