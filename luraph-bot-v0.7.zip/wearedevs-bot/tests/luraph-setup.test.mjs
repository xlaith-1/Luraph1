import test from 'node:test';import assert from 'node:assert/strict';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {lowerFrame147} from '../tools/luraph/ir147.mjs';
import {analyzeSetup147} from '../tools/luraph/setup147.mjs';
const parse=s=>lp.parse('return function(...) '+s+' end',{luaVersion:'5.3',encodingMode:'pseudo-latin1'}).body[0].arguments[0];
const d={slotAliases:{code:1},read:{opcodeArray:'code',programCounter:'pc'},frame:{registerArray:'r'},opcodeVariable:'op',iteration:{}};
const loop='repeat local op=code[pc];pc+=1 until false';
const graph={tables:[{id:1,entries:[[1,{native:'table.create'}],[4,{native:'select'}],[7,{native:'getfenv'}],[29,{native:'pcall'}],[52,{closure:true}]]},{id:2,entries:[]}]};
const bindings={bindings:[{name:'T',resolved:true,value:{table:1}},{name:'count',resolved:true,value:3},{name:'code',resolved:true,value:{table:2}}]};
const helpers={helpers:[{table:1,key:52,node:parse('local n=T[4]("#",...);return n,{...}'),captures:bindings.bindings}]};
function run(body,options){return analyzeSetup147(graph,bindings,helpers,lowerFrame147(d,parse(body)),options);}
test('setup models allocation and argument packing before stopping at protected callback',()=>{
 const r=run(`local r=T[1](count);local n,a=T[52](...);local pc=1;local env=T[7]();local ok=T[29](function() ${loop} end)`,{args:[null,8,null]});
 assert.equal(r.stop,'protected-call-continuation-not-modeled');assert.equal(r.programCallsExecuted,false);assert.equal(r.fullRecoveryVerified,false);
 assert.ok(r.bindings.some(b=>b.value?.capacity===3&&b.value.fill===null));
 assert.ok(r.bindings.some(b=>b.value?.values?.prefix?.length===3));
 assert.ok(r.bindings.some(b=>b.value?.kind==='opaque-environment'));
 assert.equal(r.events.at(-1).callbackIsClosure,true);
});
test('a direct dispatcher remains unentered even after setup succeeds',()=>{
 const r=run(`local r=T[1](count);local pc=1;${loop}`);
 assert.equal(r.stop,'dispatcher-boundary-not-entered');
});
test('unknown allocations and unapproved setup calls stop without fabricating values',()=>{
 assert.equal(run(`local r=T[1](missing);local pc=1;${loop}`).stop,'table-create-arguments-not-modeled');
 assert.equal(run(`local r=missing();local pc=1;${loop}`).stop,'unapproved-setup-call');
});
test('unknown incoming args stay unknown rather than being treated as empty',()=>{
 const r=run(`local r=T[1](count);local n,a=T[52](...);local pc=1;${loop}`);
 assert.ok(r.bindings.some(b=>b.value?.reason==='argument-count'));
 assert.ok(r.bindings.some(b=>b.value?.values?.unknownTail));
});
test('environment arguments and operation budgets fail closed',()=>{
 assert.equal(run(`local r=T[1](count);local env=T[7](4);local pc=1;${loop}`).stop,'getfenv-arguments-not-modeled');
 assert.equal(run(`local r=T[1](count);local pc=1;${loop}`,{maxOperations:1}).stop,'setup-operation-budget');
});
test('joining different helper return arities must not invent a fixed argument count',()=>{
 const g={tables:[{id:1,entries:[...graph.tables[0].entries,[53,{closure:true}]]},graph.tables[1]]};
 const hs={helpers:[...helpers.helpers,{table:1,key:53,node:parse('if ... then return else return nil end'),captures:bindings.bindings}]};
 const frame=lowerFrame147(d,parse(`local r=T[1](count);local n,a=T[52](T[53](...));local pc=1;${loop}`));
 const r=analyzeSetup147(g,bindings,hs,frame);
 assert.equal(r.stop,'dispatcher-boundary-not-entered');
 assert.ok(r.bindings.some(b=>b.value?.reason==='argument-count'));
});

import {prepareProtected147,bindProtectedOutcome147} from '../tools/luraph/protected147.mjs';
function protectedPlan(){return prepareProtected147(run(`local r=T[1](count);local pc=1;local ok,a,b,c=T[29](function(x,...) local one,two=(...);${loop} end,9,nil,7);if ok then return a end`));}
test('protected callback parameters and nil prologue locals share exact lexical IDs',()=>{
 const p=protectedPlan();assert.equal(p.status,'callback-dispatch-boundary-not-entered');
 assert.equal(p.instructionEntryAuthorized,false);assert.equal(p.programCallsExecuted,false);
 assert.equal(p.bindings.find(b=>b.id===p.boundary.pcSymbol.id).value,1);
 assert.ok(p.bindings.some(b=>b.value===9));assert.equal(p.continuation[0].kind,'if');
});
test('hypothetical protected success prepends true and preserves nil return slots',()=>{
 const p=protectedPlan(),r=bindProtectedOutcome147(p,{kind:'return',values:{prefix:[null,8],unknownTail:false}});
 assert.deepEqual(r.bindings.map(b=>b.value),[true,null,8,null]);assert.equal(r.hypothetical,true);assert.equal(r.fullRecoveryVerified,false);
});
test('hypothetical Lua errors prepend false and pad remaining locals with nil',()=>{
 assert.deepEqual(bindProtectedOutcome147(protectedPlan(),{kind:'lua-error',value:'failure'}).bindings.map(b=>b.value),[false,'failure',null,null]);
});
test('unknown returns stay unknown and analysis blockers cannot become Lua errors',()=>{
 const p=protectedPlan(),r=bindProtectedOutcome147(p,{kind:'return',values:{prefix:[],unknownTail:true}});
 assert.equal(r.bindings[0].value,true);assert.equal(r.bindings[1].value.kind,'unknown');
 assert.throws(()=>bindProtectedOutcome147(p,{kind:'blocked'}),/cannot be converted/);
});
test('unsupported callback effects and prologue budgets remain blocked',()=>{
 const s=run(`local r=T[1](count);local pc=1;local ok=T[29](function() local x=missing();${loop} end)`);
 assert.match(prepareProtected147(s).reason,/expression-not-modeled/);
 assert.equal(prepareProtected147(run(`local r=T[1](count);local pc=1;local ok=T[29](function() local x=1;${loop} end)`),{maxOperations:1}).reason,'protected-prologue-budget');
});
test('an omitted error value is rejected, while explicit Lua nil is preserved',()=>{
 const p=protectedPlan();assert.throws(()=>bindProtectedOutcome147(p,{kind:'lua-error'}),/Explicit Lua error/);
 assert.deepEqual(bindProtectedOutcome147(p,{kind:'lua-error',value:null}).bindings.map(b=>b.value),[false,null,null,null]);
});
