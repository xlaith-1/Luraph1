import test from 'node:test';
import assert from 'node:assert/strict';
import {StaticDataEvaluator,Unsupported} from '../tools/luraph/static-data-eval.mjs';
const run=(source,data,options={})=>{const e=new StaticDataEvaluator(options);const r=e.run(source,data);return {e,r};};
const values=source=>run(source).r.values;

test('data evaluator Lua truthiness: zero is true; false and nil are false',()=>{
 assert.deepEqual(values('return not 0, not false, not nil, 0 or 8, false and 4, nil or 9'),[false,true,true,0,false,9]);
});
test('data evaluator preserves multiple returns, parentheses and missing values',()=>{
 assert.deepEqual(values('local function f() return 2,3 end; local a,b,c=f(),f(); return a,b,c'),[2,2,3]);
 assert.deepEqual(values('local function f() return 2,3 end; return (f())'),[2]);
 assert.deepEqual(values('local function f(...) return (...) end; return f(2,3)'),[2]);
 assert.deepEqual(values('local function f(...) return ... end; return f(2,nil,3)'),[2,null,3]);
 assert.deepEqual(values('local function f() end; local a,b=f(); return a,b'),[null,null]);
});
test('data evaluator lexical scopes, duplicate parameters and loop-local captures',()=>{
 assert.deepEqual(values('local x=7; local function f(x,x) return x end; do local x=9 end; return x,f(1,2)'),[7,2]);
 assert.deepEqual(values('local t={}; for i=1,3 do t[i]=function() return i end end; return t[1](),t[2](),t[3]()'),[1,2,3]);
 assert.deepEqual(values('local function f(n) if n==0 then return 1 end return n*f(n-1) end return f(5)'),[120]);
});
test('data evaluator repeat locals and bounded continue control flow',()=>{
 assert.deepEqual(values('local x=0; repeat local y=3; x=x+1; if x<3 then __analysis_continue() end until x==y; return x'),[3]);
 assert.deepEqual(values('local x=0; for i=1,4 do if i==2 then __analysis_continue() end x=x+i end return x'),[8]);
});
test('data evaluator compound targets are evaluated once',()=>{
 assert.deepEqual(values('local t={3};local n=0;local function index() n=n+1;return 1 end;t[index()] ^= 2; return t[1],n'),[9,1]);
 assert.deepEqual(values('local t={10}; local function f() t[1]=99;return 2 end; t[1] += f(); return t[1]'),[12]);
 assert.deepEqual(values('local x="a";x ..= "b";return x'),['ab']);
});
test('data evaluator simultaneous assignments preserve target addresses',()=>{
 assert.deepEqual(values('local i=1;local a={4,5};i,a[i]=2,9;return i,a[1],a[2]'),[2,9,5]);
 assert.deepEqual(values('local a,b=1,2;a,b=b,a;return a,b'),[2,1]);
});
test('data evaluator bit32 unsigned shifts, rotations and counts',()=>{
 assert.deepEqual(values('return bit32.bnot(0),bit32.lshift(1,32),bit32.lshift(8,-1),bit32.rrotate(1,1),bit32.countlz(0),bit32.countrz(0),bit32.countrz(8),bit32.band()'),[4294967295,0,4,2147483648,32,32,3,4294967295]);
});
test('data evaluator endian unpack and multi-return adjustment',()=>{
 assert.deepEqual(values('return string.unpack(">i8","\\000\\000\\000\\000\\000\\000\\000\\002")'),[2,9]);
 assert.deepEqual(values('return (string.unpack("<I4",string.pack("<I4",4294967295)))'),[4294967295]);
 assert.throws(()=>values('return string.unpack("c999999999", "a")'),Unsupported);
});
test('data evaluator buffers are bounded; external input cannot be written',()=>{
 const bytes=Buffer.from([1,2,3,4]);assert.deepEqual(run('local b=...; return buffer.readu8(b,0),buffer.readu16(b,1)',bytes).r.values,[1,770]);
 assert.throws(()=>run('local b=...; buffer.writeu32(b,0,42)',bytes),/external input/);assert.deepEqual([...bytes],[1,2,3,4]);
 assert.deepEqual(values('local b=buffer.create(4);buffer.writeu32(b,0,65537);return buffer.readu32(b,0),buffer.len(b)'),[65537,4]);
 assert.throws(()=>values('return buffer.create(999999999)'),/budget/);
});
test('data evaluator only permits observed gsub patterns and data metatables',()=>{
 assert.deepEqual(values('return string.gsub("azbzz","z","!!!!!")'),['a!!!!!b!!!!!!!!!!',3]);
 assert.deepEqual(values('local t=setmetatable({},{__index=function(t,k)t[k]="ok";return "ok" end});return string.gsub("1234567890",".....",t)'),['okok',2]);
 assert.throws(()=>values('return string.gsub("x",".*","y")'),Unsupported);
 assert.throws(()=>values('return setmetatable({},{__newindex=function()end})'),Unsupported);
});
test('data evaluator unknown calls remain blocked even through pcall',()=>{
 for(const code of ['print("no")','loadstring("return 1")','require("anything")','getfenv()','return pcall(print,"no")','return coroutine.yield()'])assert.throws(()=>values(code),Unsupported);
 assert.deepEqual(values('return pcall(function()local x=nil;return x[1]end)'),[false,'Index of non-table']);
});
test('data evaluator rejects global writes and exhausts loops/calls safely',()=>{
 assert.throws(()=>values('x=1'),/Global write/);
 assert.throws(()=>run('while true do end',undefined,{maxSteps:100}),/budget/);
 assert.throws(()=>run('local function f() return f() end return f()',undefined,{maxDepth:10}),/depth/);
 assert.throws(()=>run('local t={};for i=1,100 do t[i]={} end',undefined,{maxTables:20}),/allocation/);
});
test('structural VM boundary stops before factory or instructions can execute',()=>{
 const comparisons=Array.from({length:45},(_,i)=>`if opcode==${i} then print("blocked") end`).join(';');
 const code=`local function factory(p) local a,b,c,d,e,f=p[1],p[2],p[3],p[4],p[5],p[6];return function(...) local opcode=1; ${comparisons} end end;return factory({1,2,3,4,5,6})()`;
 const {r,e}=run(code);assert.equal(r.status,'vm-boundary');assert.equal(e.nativeCalls.has('print'),false);assert.equal(e.snapshot(r).fullRecoveryVerified,false);
});

test('data evaluator captures callee and receiver before argument side effects',()=>{
 assert.deepEqual(values('local f=function()return 1 end;local function g() f=function()return 2 end end;return f(g())'),[1]);
 assert.deepEqual(values('local t={f=function(self)return self.value end,value=7};local function g()t={value=8}end;return t:f(g())'),[7]);
});

test('factory selection returns a frame without invoking it or modifying parsed data',()=>{
 const comparisons=Array.from({length:45},(_,i)=>`if opcode==${i} then print("not executed") end`).join(';');
 const body=`local a,b,c,d,e,f=p[1],p[2],p[3],p[4],p[5],p[6];return function(...)local opcode=1;${comparisons} end`;
 const {e,r}=run(`local function factory(p) ${body} end;return factory({1,2,3,4,5,6})()`);
 assert.equal(e.selectFrame(r).type,'FunctionDeclaration');assert.equal(e.nativeCalls.has('print'),false);
 const bad=run(`local function factory(p) p[1]+=1;${body} end;return factory({1,2,3,4,5,6})()`);
 assert.throws(()=>bad.e.selectFrame(bad.r),/change parsed data/);assert.equal(bad.r.args[0].get(1),1);
});

test('unknown builtin members are not silently treated as nil',()=>{
 assert.throws(()=>values('return string.definitely_unknown'),/Unmodeled builtin member/);
 assert.throws(()=>values('return string.packsize("i4")'),/Blocked native call/);
});

test('data evaluator preserves member compound reads instead of using a same-named local',()=>{
 assert.deepEqual(values('local x=99;local t={x=2};t.x+=3;return t.x,x'),[5,99]);
});

test('selected-frame binding snapshots preserve lexical identity without calls',()=>{
 const comparisons=Array.from({length:45},(_,i)=>`if opcode==${i} then print('blocked') end`).join(';');
 const {e,r}=run(`local helper={create=table.create};local function factory(p) local a,b,c,d,e,f=p[1],p[2],p[3],p[4],p[5],p[6];local helper={create=table.create};return function(...)local opcode=1;${comparisons} end end;return factory({1,2,3,4,5,6})()`);
 assert.throws(()=>e.snapshotFrameBindings(['helper']),/No selected frame/);
 e.selectFrame(r);const steps=e.steps;
 const result=e.snapshotFrameBindings(['helper','a','missing','table','helper']);
 assert.equal(result.bindings.length,4);assert.equal(result.bindings[1].value,1);
 assert.deepEqual(result.bindings[2],{name:'missing',resolved:false});
 const graph=e.snapshot(r),table=graph.tables.find(t=>t.id===result.bindings[0].value.table);
 assert.deepEqual(table.entries,[['create',{native:'table.create'}]]);
 assert.equal(e.steps,steps);assert.equal(e.nativeCalls.has('print'),false);
 assert.equal(result.fullRecoveryVerified,false);
 assert.throws(()=>e.snapshotFrameBindings(Array(513).fill('x')),/limit/);
});
test('captured helper export preserves AST and nearest scope without invoking helpers',()=>{
 const comparisons=Array.from({length:45},(_,i)=>`if opcode==${i} then print('blocked') end`).join(';');
 const {e,r}=run(`local x=1;local helpers={};do local x=2;helpers[7]=function() print('never');return x end end;local function factory(p) local a,b,c,d,e,f=p[1],p[2],p[3],p[4],p[5],p[6];return function(...)local opcode=1;${comparisons} end end;return factory({1,2,3,4,5,6})()`);
 e.selectFrame(r);const steps=e.steps,before=e.snapshotFrameBindings(['helpers']);
 const result=e.snapshotFrameHelpers(['helpers']);assert.equal(result.helpers.length,1);
 assert.equal(result.helpers[0].key,7);assert.equal(result.helpers[0].node.type,'FunctionDeclaration');
 assert.equal(result.helpers[0].captures.find(c=>c.name==='x').value,2);
 assert.deepEqual(e.snapshotFrameBindings(['helpers']),before);
 assert.equal(e.steps,steps);assert.equal(e.nativeCalls.has('print'),false);
 assert.equal(result.programCallsExecuted,false);assert.equal(result.fullRecoveryVerified,false);
});
