import test from 'node:test';
import assert from 'node:assert/strict';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {specialize,extractHandlers} from '../tools/luraph/dispatch147.mjs';
import {StaticDataEvaluator} from '../tools/luraph/static-data-eval.mjs';
const parse=s=>lp.parse(s,{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
function compare(body,op,extra=''){
 const original=parse(`local op=${op};${extra};${body}`),fragment=parse(body),before=JSON.stringify(fragment);
 const lowered={...original,body:[...parse(`local op=${op};${extra}`).body,...specialize(fragment.body,'op',op)]};
 assert.equal(JSON.stringify(fragment),before,'specializer must not mutate its input');
 const expected=new StaticDataEvaluator().runAst(original).values;
 assert.deepEqual(new StaticDataEvaluator().runAst(lowered).values,expected);return lowered;
}
test('dispatcher specialization preserves selected branches and Lua zero truthiness',()=>{
 for(let op=0;op<8;op++)compare('if op<4 then if op==2 then return 20 else return 10 end else if 0 then return 30 else return 40 end end',op);
});
test('dispatcher specialization preserves unknown runtime branches',()=>{
 for(const flag of ['true','false'])compare('if op==2 then if flag then return 1 else return 2 end else return 3 end',2,`local flag=${flag}`);
});
test('dispatcher specialization preserves branch-local scope',()=>{
 compare('if op==2 then local x=4 end return x',2,'local x=9');
});
test('dispatcher specialization stops assuming opcode after a write',()=>{
 compare('if op==3 then op=2; if op==2 then return 10 else return 99 end end',3);
 compare('if op==3 then for op=1,4 do if op==2 then return 10 end end end',3);
});
test('dispatcher extraction follows names/slot mappings instead of sample identifiers',()=>{
 const branches=Array.from({length:45},(_,i)=>`${i===0?'if':'elseif'} renamed==${i} then registers[1]=${i}`).join(' ')+' end';
 const ast=parse(`return function(p) local code=p[7]; return function(...) local registers={};local pc=1;repeat local renamed=code[pc];${branches};pc=pc+1 until pc>9;return registers end end`);
 const factory=ast.body[0].arguments[0],result=extractHandlers(factory,45);
 assert.equal(result.opcodeVariable,'renamed');assert.equal(result.read.opcodeSlot,7);assert.equal(result.read.programCounter,'pc');
 assert.equal(result.handlers.length,46);assert.equal(result.fullRecoveryVerified,false);
});

test('dispatcher domains are derived rather than assumed to be one byte',()=>{
 const branches=Array.from({length:45},(_,i)=>`${i===0?'if':'elseif'} op==${i+256} then return ${i}`).join(' ')+' end';
 const ast=parse(`return function(p) local code=p[3];return function(...)local pc=1;repeat local op=code[pc];${branches};pc=pc+1 until false end end`);
 const r=extractHandlers(ast.body[0].arguments[0]);assert.equal(r.maxComparedOpcode,300);assert.equal(r.handlers.length,302);assert.equal(r.domainTruncated,false);
});

test('whole-iteration extraction retains opcode fetch and shared PC increment',()=>{
 const branches=Array.from({length:45},(_,i)=>`${i===0?'if':'elseif'} op==${i} then result=${i}`).join(' ')+' end';
 const factory=parse(`return function(p)local code=p[3];return function(...)local pc=1;repeat local op=code[pc];${branches};pc+=1 until false end end`).body[0].arguments[0];
 const r=extractHandlers(factory,45);assert.equal(r.iteration.type,'RepeatStatement');
 const selected=r.handlers[7].iterationBody;assert.equal(selected[0].type,'LocalStatement');assert.equal(selected.at(-1).type,'CompoundAssignmentStatement');
 const ast=parse('local code={7};local pc=1;local result=0;return result,pc');
 ast.body.splice(3,0,...selected);
 assert.deepEqual(new StaticDataEvaluator().runAst(ast).values,[7,2]);
});
