import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
const cli=new URL('../tools/luraph/inspect147.mjs',import.meta.url).pathname;
const header='-- This file was protected using Luraph Obfuscator v14.7\n';
function inspect(source){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'l147-test-'));
 try{
  const input=path.join(dir,'input.lua'),output=path.join(dir,'analysis');fs.writeFileSync(input,source);
  const result=spawnSync(process.execPath,[cli,input,output],{encoding:'utf8',timeout:20000});
  assert.equal(result.status,0,result.stderr);
  const report=JSON.parse(result.stdout);assert.equal(report.fullRecoveryVerified,false);assert.equal(report.executedUploadedCode,false);
  assert.equal(fs.existsSync(path.join(output,'recovered.lua')),false);
  return report;
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
}
test('v14.7 variable marker transport stays analysis-only',()=>{
 const r=inspect(header+'return [=[LPH>!!!!!]=]');
 assert.equal(r.layers[0].bytes,4);assert.equal(r.layers[0].marker,'LPH>');assert.equal(r.status,'analysis-only');
 assert.equal(r.layers[0].unpack.ok,false); // Zero bytes are not an LZMA stream.
});
test('v14.7 trimmed literal is refused, not silently repaired',()=>{
 const r=inspect(header+'return [=[LPH>!!!!! [trimmed]');
 assert.deepEqual(r.layers,[]);assert.match(r.errors[0],/Unterminated/);
});
test('v14.7 scanner ignores markers hidden in comments and strings',()=>{
 const r=inspect(header+'-- [=[LPH>!!!!!]=]\nreturn "[=[LPH>!!!!!]=]"');
 assert.deepEqual(r.layers,[]);assert.match(r.errors[0],/number of candidate/);
});
test('v14.7 research tool does not grant support based on another header',()=>{
 const r=inspect('-- Luraph Obfuscator v14.8\nreturn [=[LPH>!!!!!]=]');
 assert.deepEqual(r.layers,[]);assert.match(r.errors[0],/Expected v14.7/);
});
