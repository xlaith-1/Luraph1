import test from 'node:test';import assert from 'node:assert/strict';
import {StaticDataEvaluator} from '../tools/luraph/static-data-eval.mjs';
const run=s=>new StaticDataEvaluator().run(s).values;
test('bounded goto handles forward, backward and child-to-parent jumps',()=>{
 assert.deepEqual(run('local x=0;::again:: x=x+1;if x<4 then goto again end;goto done;x=99;::done:: return x'),[4]);
 assert.deepEqual(run('local x=1;do local x=9;goto done end;::done::return x'),[1]);
});
test('goto cannot cross local declarations or function boundaries',()=>{
 assert.throws(()=>run('goto done;local x=3;::done:: return x'),/local declaration|scope of local/);
 assert.throws(()=>run('local f=function()goto done end;f();::done::return 1'),/function boundary|no visible label/);
});
test('goto loops obey the same step budget',()=>{
 assert.throws(()=>new StaticDataEvaluator({maxSteps:100}).run('::again::goto again'),/step budget/);
});
