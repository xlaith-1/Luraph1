import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const cli=fileURLToPath(new URL('../worker/luraph-cli.mjs',import.meta.url));
const source=`local function vm(p) local code,constants=p[1],p[2];return function(...) local r={};local pc=1;while true do local op=code[pc];if op==1 then r[1]=constants[pc] elseif op==2 then sink(r[1]) elseif op==3 then return r[1] else error('bad') end pc=pc+1 end end end return vm({{1,2,3},{'readable result'}})(...)`;
test('production worker emits readable candidate, marks partial, and skips fallback',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'literal-worker-'));
 try{
  const input=path.join(dir,'input.lua'),out=path.join(dir,'result');fs.writeFileSync(input,source);
  const result=spawnSync(process.execPath,[cli,input,out,'/bin/false'],{encoding:'utf8',timeout:15000});
  assert.equal(result.status,0,result.stderr);assert.equal(result.stderr,'');
  const report=JSON.parse(fs.readFileSync(path.join(out,'report.json')));
  assert.equal(report.status,'partial-source');assert.equal(report.fullRecoveryVerified,false);assert.equal(report.executedUploadedCode,false);
  assert.ok(!fs.existsSync(path.join(out,'recovered.lua')));
  const candidate=fs.readFileSync(path.join(out,'standalone.candidate.lua'),'utf8');
  assert.match(candidate,/readable result/);assert.match(candidate,/sink/);assert.doesNotMatch(candidate,/while true|code\[|pc=/);
  assert.ok(JSON.parse(result.stdout).artifacts.includes('standalone.candidate.lua'));
  fs.writeFileSync(input,'return 42');
  const again=spawnSync(process.execPath,[cli,input,out],{encoding:'utf8',timeout:15000});assert.equal(again.status,0,again.stderr);
  assert.ok(!fs.existsSync(path.join(out,'standalone.candidate.lua')));assert.ok(!fs.existsSync(path.join(out,'luraph.recovery.json')));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
