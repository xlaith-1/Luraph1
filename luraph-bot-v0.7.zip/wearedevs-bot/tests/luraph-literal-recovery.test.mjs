import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {recoverLiteral147} from '../tools/luraph/recover-literal147.mjs';
function vm({seed=0,codes='{31,57,91}',constants='{20,22}',dest='{1,1,1}',inputs='{1,1,1}',targets='{}',mode='script',add,ret='r[dest[pc]],nil,...',load,extra=''}={}){
 const s=seed+1;
 return `local function machine${seed}(p) local code,constants,dest,inputs,targets=p[${s}],p[${s+2}],p[${s+4}],p[${s+6}],p[${s+8}];return function(...)local r={...};local pc=1;${extra} while true do local op=code[pc]; if op==31 then ${load??'r[dest[pc]]=constants[pc]'} elseif op==57 then ${add??'r[dest[pc]]=r[inputs[pc]]+constants[pc]'} elseif op==91 then return ${ret} elseif op==120 then if r[inputs[pc]] then pc=targets[pc] end elseif op==130 then sink(r[inputs[pc]]) elseif op==140 then code[targets[pc]]=constants[pc] else error('unknown opcode') end pc=pc+1 end end end return machine${seed}({[${s}]=${codes},[${s+2}]=${constants},[${s+4}]=${dest},[${s+6}]=${inputs},[${s+8}]=${targets}})${mode==='script'?'(...)':''}`;
}
const cases=[
 ['arithmetic',vm(), 'run(nil,5,nil,7)'],
 ['renamed-and-reindexed',vm({seed:17}), 'run(false,0,"bytes\\000\\255")'],
 ['argument-arithmetic',vm({codes:'{57,91}',constants:'{7}',dest:'{1,1}'}),'run(35,nil,8)'],
 ['float-representation',vm({constants:'{20.0,22}'}),'run()'],
 ['conditional-jump',vm({codes:'{120,31,91,31,91}',targets:'{3}',constants:'{0,20,0,22}',dest:'{1,1,1,1,1}'}),'for _,v in ipairs({false,true,0,""})do run(v)end;run(nil)'],
 ['self-modifying-opcode',vm({codes:'{140,999}',constants:'{91}',targets:'{2}',dest:'{1,1}'}),'run(42)'],
 ['simultaneous-addresses',vm({constants:'{3}',add:'r[1],r[r[1]]=2,99',ret:'r[1],r[3]'}),'run()'],
 ['call-side-effects',vm({codes:'{31,130,91}',constants:'{"hello\\000\\255"}'}),'run()'],
 ['binary-return',vm({codes:'{31,91}',constants:'{"\\000\\255123\\034\\092"}'}),'run(false,nil,7)'],
 ['reusable-closure',vm({mode:'closure',codes:'{57,91}',constants:'{7}',dest:'{1,1}'}),'local f=chunk();run=f;emit("return",run(1));emit("return",run(9))'],
 ['metamethod-argument',vm({codes:'{57,91}',constants:'{7}',dest:'{1,1}'}),'run(setmetatable({}, {__add=function(_,n)emit("add",n);return 42 end}))'],
 ['multiple-call-results',vm({load:'local callback=...;r[1],r[2],r[3]=callback()',codes:'{31,91}',ret:'r[1],r[2],r[3]'}),'run(function()emit("callback",3);return 1,nil,3 end)'],
 ['parenthesized-call-result',vm({load:'local callback=...;r[1],r[2]=(callback())',codes:'{31,91}',ret:'r[1],r[2]'}),'run(function()return 1,2 end)'],
 ['non-one-entry',vm({codes:'{999,999,31,91}',constants:'{0,0,41}',dest:'{1,1,1,1}'}).replace('local pc=1','local pc=3'),'run()'],
 ['revisited-modified-site',vm({codes:'{140,91}',constants:'{31}',targets:'{1}',dest:'{1,1}'}).replace('code[targets[pc]]=constants[pc]','code[targets[pc]]=constants[pc];pc=0'),'run()'],
 ['inline-factory',vm().replace('local function machine0(p)','return (function(p)').replace('end return machine0(','end)('),'run()'],
 ['generated-name-collision',vm({codes:'{31,91}',load:'r[1]=sink;r[2]=recovered_global_sink_1',ret:'r[2]'}),'_G.recovered_global_sink_1=37;run()'],
 ['method-lookup-order',vm({codes:'{31,91}',load:'local object,callback=...;r[1]=object:method(callback())',ret:'r[1]'}),'local object={method=function(self,n)emit("old",n);return n+2 end};run(object,function()object.method=function()error("wrong method")end;emit("argument",3);return 3 end)'],
 ['lexical-shadow',vm({add:'do local r={};r[1]=999 end;r[1]=r[1]+constants[pc]'}),'run()'],
];
for(const runtime of ['lua5.4','luajit']){
 const available=spawnSync(runtime,['-v']).status===0;
 for(const [name,source,invoke]of cases)test(`${runtime}: recovered source matches original (${name})`,{skip:!available},()=>{
  const recovered=recoverLiteral147(source);assert.ok(recovered.source,recovered.report.error);
  assert.equal(recovered.report.fullRecoveryVerified,false);assert.equal(recovered.report.programCallsExecuted,false);
  assert.doesNotMatch(recovered.source,/while true|code\[|pc\s*=|machine\d|r\[/);
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'literal-recovery-'));
  try{
   fs.writeFileSync(path.join(dir,'original.lua'),source,'latin1');fs.writeFileSync(path.join(dir,'candidate.lua'),recovered.source,'latin1');
   const harness=`local function emit(tag,...)io.write(tag,':',select('#',...),':');for i=1,select('#',...)do local v=select(i,...);io.write(type(v),'=');if type(v)=='string'then for j=1,#v do io.write(string.format('%02x',v:byte(j)))end elseif type(v)=='number'then io.write(string.format('%.17g',v));if math.type then io.write('/',math.type(v))end elseif type(v)=='boolean' or type(v)=='nil' then io.write(tostring(v))else io.write('<opaque>')end;io.write(';')end;io.write('\\n')end;_G.sink=function(...)emit('sink',...)end;local chunk=assert(loadfile(arg[1]));local function run(...)emit('return',chunk(...))end;${invoke}`;
   fs.writeFileSync(path.join(dir,'harness.lua'),harness);
   const outputs=['original.lua','candidate.lua'].map(file=>{const r=spawnSync(runtime,['harness.lua',file],{cwd:dir,encoding:'utf8',timeout:10000});assert.equal(r.status,0,r.stderr);return r.stdout;});
   assert.equal(outputs[1],outputs[0]);
  }finally{fs.rmSync(dir,{recursive:true,force:true});}
 });
}
test('recovery rejects unsupported paths instead of issuing a misleading partial function',()=>{
 const cases=[
  vm({codes:'{999}'}).replace("error('unknown opcode')","while true do end"),
  vm({codes:'{140,999}',constants:'{91}',targets:'{2}',mode:'closure'}),
  vm({mode:'closure',load:'constants[1]=99'}),
  vm({load:'r[1]={}'}),
  vm().replace('[1]={31,57,91}','[1]=getInstructions()'),
  'print("top effect");'+vm(),
  vm({load:'if r[1] then while true do end end'}),
  vm({constants:'{9007199254740993,1}'}),
  vm({constants:'{1}',add:'r[1],r[r[1]]=2,99'}),
  vm({load:'local callback=...;r={callback()}'}),
  vm({load:'r[1]=machine0'}),
  vm({extra:'local _ENV={};'}),
  vm({codes:'{31,[1]=91,91}'}),
 ];
 for(const source of cases){const r=recoverLiteral147(source);assert.equal(r.source,null);assert.equal(r.report.status,'unsupported');assert.ok(r.report.error);}
});
test('recovery budgets fail closed',()=>{
 for(const limits of [{maxInstructions:1},{maxOperations:1},{maxOutputBytes:20}])assert.equal(recoverLiteral147(vm(),limits).source,null);
 const loop=vm({codes:'{120}',targets:'{0}'});assert.equal(recoverLiteral147(loop,{maxInstructions:3}).source,null);
});
test('source output changes with input constants rather than a sample template',()=>{
 const a=recoverLiteral147(vm({constants:'{4,8}'})),b=recoverLiteral147(vm({constants:'{19,2}'}));
 assert.ok(a.source&&b.source);assert.notEqual(a.source,b.source);assert.match(a.source,/4 \+ 8/);assert.match(b.source,/19 \+ 2/);
});
export {vm};
