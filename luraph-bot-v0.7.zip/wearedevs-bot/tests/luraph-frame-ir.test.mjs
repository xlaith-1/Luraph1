import test from 'node:test';
import assert from 'node:assert/strict';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {lowerFrame147} from '../tools/luraph/ir147.mjs';
const d={slotAliases:{code:1},read:{opcodeArray:'code',programCounter:'pc',opcodeSlot:1},frame:{registerArray:'r'},opcodeVariable:'op',iteration:{}};
const loop='repeat local op=code[pc];pc+=1 until false';
function lower(body){return lowerFrame147(d,lp.parse(`return function(...) ${body} end`,{luaVersion:'5.3'}).body[0].arguments[0]);}
test('frame setup calls retain order, arguments and local bindings',()=>{
 const out=lower(`local r=allocate(4);local args,n=pack(...);local pc=1;${loop}`);
 assert.deepEqual(out.frame.body.map(x=>x.kind),['local','local','local','vm-dispatch-boundary']);
 assert.equal(out.frame.body[0].values[0].callee.symbol.name,'allocate');
 assert.equal(out.frame.body[1].values[0].args[0].kind,'varargs');
 assert.equal(out.dispatchBoundaries[0].registerSymbol.id,out.frame.body[0].targets[0].id);
 assert.equal(out.fullRecoveryVerified,false);assert.equal(out.programCallsExecuted,false);
});
test('protected callback and its continuation are preserved, not treated as executed',()=>{
 const out=lower(`local r={};local pc=1;local ok,value=protect(function() ${loop} end);if ok then return value end`);
 const call=out.frame.body[2].values[0],callback=call.args[0];
 assert.equal(call.callee.symbol.name,'protect');assert.equal(callback.kind,'closure');
 assert.equal(callback.body[0].kind,'vm-dispatch-boundary');
 assert.equal(out.frame.body[3].kind,'if');
 assert.ok(callback.captureSymbols.some(s=>s.id===out.frame.body[1].targets[0].id));
 assert.ok(!out.frame.captureSymbols.some(s=>s.name==='pc'));
});
test('closure captures use lexical identities, not later same-name locals',()=>{
 const out=lower(`local r={};local pc=1;local callback=function() ${loop} end;local pc=99;return callback`);
 assert.equal(out.dispatchBoundaries[0].pcSymbol.id,out.frame.body[1].targets[0].id);
 assert.notEqual(out.dispatchBoundaries[0].pcSymbol.id,out.frame.body[3].targets[0].id);
});
test('local initializer sees old binding and recursive local functions declare their cell',()=>{
 const out=lower(`local r={};local pc=1;local old=1;local old=old;local function f() return f end;${loop}`);
 assert.equal(out.frame.body[3].values[0].symbol.id,out.frame.body[2].targets[0].id);
 const f=out.frame.body[4];assert.equal(f.declaration,true);
 assert.ok(f.values[0].captureSymbols.some(s=>s.id===f.targets[0].symbol.id));
 assert.ok(!out.frame.captureSymbols.some(s=>s.id===f.targets[0].symbol.id));
});
test('missing or ambiguous dispatcher boundaries fail closed',()=>{
 assert.throws(()=>lower('return 1'),/one lexical/);
 assert.throws(()=>lower(`local r={};local pc=1;do ${loop} end;do ${loop} end`),/one lexical/);
});
test('a dispatcher hole cannot claim a complete captured-variable set',()=>{
 const out=lower(`local r={};local pc=1;local pure=function(x) return x end;local callback=function() ${loop} end;return callback`);
 assert.equal(out.frame.body[2].values[0].captureSymbolsComplete,true);
 assert.equal(out.frame.body[3].values[0].captureSymbolsComplete,false);
 assert.equal(out.frame.captureSymbolsComplete,false);
});
test('linked instruction and frame lowering share the actual boundary symbol IDs',()=>{
 const frame=lp.parse(`return function(...) local r={};local pc=1;repeat local op=code[pc];pc+=1 until false end`,{luaVersion:'5.3'}).body[0].arguments[0];
 const desc={...d,handlers:[{opcode:0,iterationBody:frame.body.at(-1).body}]};
 const ir=lowerFrame147(desc,frame,{includeInstructions:true});
 const counter=ir.instructionIR.instructions[0].body.find(n=>n.kind==='compound').target.symbol;
 assert.equal(counter.id,ir.dispatchBoundaries[0].pcSymbol.id);assert.equal(counter.role,'pc');
 assert.equal(ir.sharedSymbolNamespace,true);assert.equal(ir.instructionIR.entryPc,null);
 assert.equal(ir.instructionIR.unmodeledPreambleEffects,true);
});
test('linked boundary bindings are not replaced by declarations after the loop',()=>{
 const frame=lp.parse(`return function(...) local r={};local pc=1;repeat local op=code[pc];pc+=1 until false local pc=99 end`,{luaVersion:'5.3'}).body[0].arguments[0];
 const desc={...d,handlers:[{opcode:0,iterationBody:frame.body[2].body}]};
 const ir=lowerFrame147(desc,frame,{includeInstructions:true});
 assert.equal(ir.instructionIR.instructions[0].body[1].target.symbol.id,ir.frame.body[1].targets[0].id);
 assert.notEqual(ir.instructionIR.instructions[0].body[1].target.symbol.id,ir.frame.body[3].targets[0].id);
});
