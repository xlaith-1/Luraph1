import test from 'node:test';
import assert from 'node:assert/strict';
import {longLiterals,decodeLPH,decodeConstantPrefix,Reader,analyzeLuraph} from '../worker/luraph.mjs';

test('long literal scanner excludes comments and quoted marker decoys',()=>{
 const source='-- [=[LPH!comment]=]\nlocal x="[=[LPH!quoted]=]"; local y=[==[\nLPH!real]==]';
 assert.deepEqual(longLiterals(source),['LPH!real']);
 assert.throws(()=>longLiterals('return [==[unfinished'),/Unterminated/);
});
test('base85 words are little endian and z expands to a zero word',()=>{
 assert.deepEqual([...decodeLPH('LPH!!!!!"')],[1,0,0,0]);
 assert.deepEqual([...decodeLPH('LPH!z')],[0,0,0,0]);
});
test('base85 rejects truncation, invalid digits, overflow and expansion bombs',()=>{
 for(const s of ['LPH!!','LPH!~~~~~','LPH!uuuuu','other'])assert.throws(()=>decodeLPH(s));
 assert.throws(()=>decodeLPH('LPH!zzz',8),/limit/);
});
function varint(n){const a=[];do {const x=n%128;n=Math.floor(n/128);a.push(x+(n?128:0));}while(n);return a;}
test('constant decoder preserves string bytes, flags and prototype boundary',()=>{
 const b=Buffer.from([...varint(0x9a25+4),0,65,123,212,3,65,0,255,234,247,...varint(38671+2),1,2]);
 const r=decodeConstantPrefix(b);
 assert.equal(r.constants.length,4);assert.equal(r.constants[0].value,123);
 assert.equal(r.constants[1].value,'A\x00\xff');assert.equal(r.constants[2].value,false);assert.equal(r.constants[3].value,true);
 assert.equal(r.prototypeCount,2);assert.equal(r.remainingBytes,2);
});
test('constant decoder bounds-checks lengths and varints',()=>{
 assert.throws(()=>decodeConstantPrefix(Buffer.from([0,0])));
 assert.throws(()=>decodeConstantPrefix(Buffer.from([...varint(0x9a25+1),0,212,...varint(10000)])),/Truncated/);
 assert.throws(()=>new Reader(Buffer.alloc(12,255)).varint());
});
test('fake Luraph headers cannot approve a decoder or source recovery',()=>{
 for(const source of ['return 42','-- This file was protected using Luraph Obfuscator v14.8\nreturn [=[LPH!z]=]','os.execute("never executed")']){
  const {report,artifacts}=analyzeLuraph(source);
  assert.equal(report.fullRecoveryVerified,false);assert.equal(report.payloadDecoded,false);
  assert.equal(report.executedUploadedCode,false);assert.equal(report.status,'unsupported');assert.equal(artifacts['recovered.lua'],undefined);
 }
});
test('Luraph route enforces input limit before attempting extraction',()=>{
 assert.throws(()=>analyzeLuraph('x'.repeat(524289)),/limit/);
});

import {decodePrototypes} from '../worker/luraph-prototypes.mjs';
function u32(n){const b=Buffer.alloc(4);b.writeUInt32LE(n);return [...b];}
function prototypeFixture(){return Buffer.from([
 ...varint(2),...varint(81062),11,13,64,23,
 1,6,...u32(1),...u32(3),...u32(3),...u32(7),2,1,171
]);}
test('prototype records retain packed operand kinds, captures, lines and entry',()=>{
 const h={prototypeCount:1,prototypeDataOffset:0,constants:[{value:'hello'}]};
 const r=decodePrototypes(new Reader(prototypeFixture()),h);
 assert.equal(r.instructionCount,1);assert.equal(r.entry,1);assert.equal(r.remainingBytes,1);
 assert.deepEqual(r.prototypes[0].instructions[0],{pc:1,opcode:64,operands:[{tag:3,value:1},{tag:5,value:1},{tag:7,value:2}]});
 assert.deepEqual(r.prototypes[0].captures,[{index:1,kind:2}]);
 assert.deepEqual(r.prototypes[0].lines,{'1':7,'2':7,'3':7});
 assert.equal(r.sourceRecovered,false);assert.equal(r.payloadExecuted,false);
});
test('prototype parsing fails closed on invalid references and resource budgets',()=>{
 const h={prototypeCount:1,prototypeDataOffset:0,constants:[{}]};
 assert.throws(()=>decodePrototypes(new Reader(prototypeFixture()),{...h,constants:[]}),/constant reference/);
 assert.throws(()=>decodePrototypes(new Reader(prototypeFixture()),h,{maxInstructions:0}),/Instruction/);
 assert.throws(()=>decodePrototypes(new Reader(prototypeFixture()),h,{maxLineEntries:2}),/line-table/);
 assert.throws(()=>decodePrototypes(new Reader(prototypeFixture().subarray(0,5)),h),/Truncated/);
});
