import test from 'node:test';
import assert from 'node:assert/strict';
import {VersionedTrace147,typedIRObservation147} from '../tools/luraph/trace147.mjs';
const identity={sourceSha256:'a'.repeat(64),symbolNamespace:'vm-fixture',sessionId:'capture-1',executionProfile:'synthetic-fixture'};
function fixture(limits){const t=new VersionedTrace147(identity,limits);let seq=0;return {t,add:e=>t.add({sessionId:identity.sessionId,seq:seq++,...e})};}
const enter=(frameId='f',prototypeId='root',threadId='main')=>({kind:'enter',frameId,prototypeId,threadId});
const step=(pc,opcode=5,operands={a:1},frameId='f',prototypeId='root',threadId='main')=>({kind:'step',frameId,prototypeId,threadId,pc,opcode,operands});
const exit=(frameId='f',threadId='main')=>({kind:'exit',frameId,threadId});
test('three different instruction layouts: opcode and operand mutations retained',()=>{
 for(const [pc,opcode,key] of [[1,10,'a'],[0,249,'slot19'],[1000,900,'offset']]){
  const {t,add}=fixture();add(enter());add(step(pc,opcode,{[key]:1}));add(step(pc,opcode,{[key]:2}));add(step(pc,opcode+1,{[key]:2}));add(step(pc,opcode,{[key]:1}));add(exit());
  const r=t.finish();assert.equal(r.instructionVersions,3);assert.equal(r.multiVersionSites,1);assert.equal(r.sites[0].versions[0].records,2);assert.equal(r.edges.length,3);assert.equal(r.completeControlFlow,false);
 }
});
test('operand key ordering does not fabricate a version',()=>{
 const {t,add}=fixture();add(enter());add(step(1,2,{a:1,b:2}));add(step(1,2,{b:2,a:1}));assert.equal(t.finish().instructionVersions,1);
});
test('nested calls use explicit resume edges, never caller/callee step edges',()=>{
 const {t,add}=fixture();add(enter());add(step(1));add(enter('child','other'));add(step(9,5,{},'child','other'));add(exit('child'));add(step(2));
 const r=t.finish();assert.equal(r.edges.length,1);assert.equal(r.edges[0].relation,'resume');assert.equal(r.edges[0].prototypeId,'root');
});
test('recursion and repeated calls do not cross frame boundaries',()=>{
 const {t,add}=fixture();add(enter());add(step(1));add(enter('recursive'));add(step(1,5,{},'recursive'));add(exit('recursive'));add(step(3));add(exit());add(enter('new'));add(step(10,5,{},'new'));
 assert.equal(t.finish().edges.length,1);
});
test('interleaved threads have independent frame stacks',()=>{
 const {t,add}=fixture();add(enter());add(step(1));add(enter('g','root','second'));add(step(20,5,{},'g','root','second'));add(step(2));add(step(21,5,{},'g','root','second'));
 const r=t.finish();assert.equal(r.edges.length,2);assert.deepEqual(new Set(r.edges.map(e=>e.threadId)),new Set(['main','second']));
});
test('explicit trace gaps prevent invented edges',()=>{
 const {t,add}=fixture();add(enter());add(step(1));add({kind:'gap',threadId:'main'});add(step(9));assert.equal(t.finish().edges.length,0);
});
test('budget termination keeps evidence but marks unfinished frames',()=>{
 const {t,add}=fixture();add(enter());add(step(1));const r=t.finish('budget');assert.deepEqual(r.incompleteFrames,['f']);assert.equal(r.stopReason,'budget');assert.equal(r.fullRecoveryVerified,false);assert.throws(()=>add(step(2)));
});
test('observations retain variants without pretending they are execution order',()=>{
 const {t,add}=fixture();add({kind:'observation',prototypeId:'x',pc:0,opcode:2,operands:{}});add({kind:'observation',prototypeId:'x',pc:0,opcode:3,operands:{}});
 const r=t.finish();assert.equal(r.edges.length,0);assert.equal(r.executedStepRecords,0);assert.equal(r.multiVersionSites,1);
});
test('source namespace separates otherwise identical version IDs',()=>{
 function version(namespace){const t=new VersionedTrace147({...identity,symbolNamespace:namespace});t.add({kind:'observation',sessionId:identity.sessionId,seq:0,prototypeId:'x',pc:0,opcode:0,operands:{}});return t.finish().sites[0].versions[0].versionId;}
 assert.notEqual(version('A'),version('B'));
});
test('wrong session poisons evidence and suppresses derived edges',()=>{
 const {t,add}=fixture();add(enter());add(step(1));add(step(2));assert.throws(()=>add({...step(3),sessionId:'other'}));const r=t.finish('error');assert.equal(r.valid,false);assert.equal(r.edges.length,0);
});
test('missing event sequence must be declared as a gap',()=>{
 const {t,add}=fixture();add(enter());assert.throws(()=>add({...step(1),seq:7}),/gap/);assert.equal(t.finish().valid,false);
});
test('frame/prototype mismatches and reused frame IDs fail closed',()=>{
 {const {t,add}=fixture();add(enter());assert.throws(()=>add(step(1,2,{},'f','wrong')));assert.equal(t.finish().valid,false);}
 {const {add}=fixture();add(enter());add(exit());assert.throws(()=>add(enter()));}
});
test('negative zero and ordinary operand objects have distinct representations',()=>{
 const {t,add}=fixture();add(enter());add(step(1,0,{x:-0}));add(step(1,0,{x:0}));add(step(1,0,{x:{$negativeZero:true}}));assert.equal(t.finish().instructionVersions,3);
});
test('accessor operands are never evaluated',()=>{
 let invoked=false;const obj={};Object.defineProperty(obj,'x',{enumerable:true,get(){invoked=true;return 1;}});
 const {add}=fixture();add(enter());assert.throws(()=>add(step(1,2,obj)));assert.equal(invoked,false);
});
test('bounded storage stops without converting partial evidence to success',()=>{
 const {t,add}=fixture({versions:1});add(enter());add(step(1));assert.throws(()=>add(step(2)),/limit/);const r=t.finish();assert.equal(r.valid,false);assert.equal(r.instructionVersions,1);
});
test('legacy IR preserves bytes, references and opaque uncertainty',()=>{
 const e=typedIRObservation147('I\t9\t0\tS00ff\tD250\tD-0\tDinf\tP7\tB1\tT{Xcycle=Xcycle}','s',0);
 assert.equal(e.kind,'observation');assert.deepEqual(e.operands.e,{type:'bytes',hex:'00ff'});assert.equal(e.operands.p.value,'-0');assert.equal(e.operands.h.id,'7');assert.equal(e.operands.b.type,'opaque');
 assert.equal(typedIRObservation147('META\tprotos\t1','s',0),null);
});
test('malformed legacy rows and missing opcode values are rejected',()=>{
 for(const line of ['I\t0','I\t0\t1\tSff0\tD2\tN\tN\tN\tN\tN','I\t0\t1\tN\tDNaN\tN\tN\tN\tN\tN'])assert.throws(()=>typedIRObservation147(line,'s',0));
});

test('offline CLI handles explicit events and quarantines malformed imports',async()=>{
 const fs=await import('node:fs');const os=await import('node:os');const path=await import('node:path');const {spawnSync}=await import('node:child_process');
 const work=fs.mkdtempSync(path.join(os.tmpdir(),'trace147-test-'));
 try{
  const manifest=path.join(work,'manifest.json'),events=path.join(work,'events.jsonl'),output=path.join(work,'result.json');
  fs.writeFileSync(manifest,JSON.stringify({identity,inputs:[{path:'events.jsonl',format:'events-jsonl'}]}));
  fs.writeFileSync(events,[enter(),step(1),step(2),exit()].map((e,seq)=>JSON.stringify({sessionId:identity.sessionId,seq,...e})).join('\n'));
  const cli=new URL('../tools/luraph/trace147-cli.mjs',import.meta.url);
  let r=spawnSync(process.execPath,[cli.pathname,manifest,output],{encoding:'utf8',timeout:15000});
  assert.equal(r.status,0,r.stderr);let data=JSON.parse(fs.readFileSync(output));assert.equal(data.edges.length,1);assert.equal(data.valid,true);
  fs.appendFileSync(events,'\nnot valid json\n');
  r=spawnSync(process.execPath,[cli.pathname,manifest,output],{encoding:'utf8',timeout:15000});
  assert.equal(r.status,1);data=JSON.parse(fs.readFileSync(output));assert.equal(data.valid,false);assert.deepEqual(data.edges,[]);
 }finally{fs.rmSync(work,{recursive:true,force:true});}
});
