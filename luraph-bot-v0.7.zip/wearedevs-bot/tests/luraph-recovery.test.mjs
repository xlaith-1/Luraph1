import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {analyzeLuraph,decodeLPH,longLiterals,Reader,decodeConstantPrefix} from '../worker/luraph.mjs';
import {decodePrototypes} from '../worker/luraph-prototypes.mjs';
import {decodeTypedConstant,liftPayload,recoverReviewedLuraph,luraphReview} from '../worker/luraph-recovery.mjs';

function encode(s,seed=17){let state=seed;return String.fromCharCode(1,seed)+[...s].map(c=>{state=(41*state+253)%256;return String.fromCharCode(c.charCodeAt(0)^state^133);}).join('');}
test('typed constants decode independently, preserving byte strings',()=>{
 for(const s of ['print','a\x00\xff\\"','', 'not a stored script'])assert.equal(decodeTypedConstant({kind:'byte-string',value:encode(s)}),s);
 assert.equal(decodeTypedConstant({kind:'byte-string',value:'\0plain'}),'plain');
 assert.equal(decodeTypedConstant({kind:'number',value:-91}),91);
 assert.equal(decodeTypedConstant({kind:'boolean',value:false}),true);
 assert.throws(()=>decodeTypedConstant({kind:'byte-string',value:''}));
 assert.throws(()=>decodeTypedConstant({kind:'int64',value:'9007199254740993'}));
});
function simplePrototype(){
 const raw=n=>({tag:4,value:n}),constant=n=>({tag:3,value:n});
 return {flag:0,captures:[],registers:2,instructions:[
  {pc:1,opcode:64,operands:[raw(1),raw(0),constant(1)]},
  {pc:2,opcode:96,operands:[raw(2),raw(0),constant(2)]},
  {pc:3,opcode:19,operands:[raw(1),raw(0),raw(0)]},
  {pc:4,opcode:59,operands:[raw(0),raw(0),raw(0)]},
 ]};
}
const pool=text=>[{kind:'byte-string',value:encode('print')},{kind:'byte-string',value:encode(text)}];
test('lifter emits actual decoded input, not a source template',()=>{
 for(const text of ['a','b','quote" and \\', '\0\xff']){
  const result=liftPayload(simplePrototype(),pool(text),{});
  assert.deepEqual(result.calls,[{name:'print',args:[text]}]);
  assert.equal(result.events.length,4);
  assert.match(result.source,/^print\(/);
 }
 assert.notEqual(liftPayload(simplePrototype(),pool('a'),{}).source,liftPayload(simplePrototype(),pool('b'),{}).source);
});
test('lifter stops on unknown calls, captures, control flow and opcodes',()=>{
 assert.throws(()=>liftPayload(simplePrototype(),[{kind:'byte-string',value:encode('loadstring')},...pool('x').slice(1)],{}),/unsupported global/);
 const p=simplePrototype();p.captures=[{}];assert.throws(()=>liftPayload(p,pool('x'),{}),/captures/);
 const q=simplePrototype();q.instructions[0].opcode=160;assert.throws(()=>liftPayload(q,pool('x'),{}),/unsupported payload opcode/);
 const loop=simplePrototype();loop.instructions[0]={pc:1,opcode:156,operands:[{tag:4,value:0},{tag:4,value:0},{tag:4,value:0}]};
 assert.throws(()=>liftPayload(loop,pool('x'),{}),/budget/);
});

const samplePath=process.env.LURAPH_SAMPLE_PATH??'/home/user/uploads/message (62).txt';
const available=fs.existsSync(samplePath);
test('reviewed upload is decrypted, parsed and fully lifted', {skip:!available},()=>{
 const source=fs.readFileSync(samplePath).toString('latin1');const {report,artifacts}=analyzeLuraph(source);
 assert.equal(report.status,'full-source');assert.equal(report.fullRecoveryVerified,true);
 assert.equal(report.executedUploadedCode,false);assert.equal(report.remainingDispatcherBlocks,0);assert.equal(report.unresolvedCallbacks,0);
 assert.equal(report.payloadPrototypeCount,1);assert.equal(report.payloadInstructionCount,35);assert.equal(report.payloadReachableInstructions,34);
 assert.equal(artifacts['recovered.lua'],'print("hiiiii luraph 14.8")\n');
 assert.equal(report.remainingSerializedBytes,0);assert.equal(report.trailingPaddingBytes,3);
 const trace=JSON.parse(artifacts['luraph.recovery.json']);assert.equal(trace.events.at(-1).pc,35);assert.equal(trace.events.some(x=>x.pc===13),false);
});
test('mutated uploads never borrow the reviewed source certificate', {skip:!available},()=>{
 const source=fs.readFileSync(samplePath).toString('latin1');
 for(const text of [source+'\n',source.replace('14.8','14.9'),source.slice(0,-1)]){
  const r=analyzeLuraph(text);assert.equal(r.report.fullRecoveryVerified,false);assert.equal(r.artifacts['recovered.lua'],undefined);
 }
});
test('bad keys and arithmetic captures cannot certify matching-looking data', {skip:!available},()=>{
 const source=fs.readFileSync(samplePath).toString('latin1');const bytes=decodeLPH(longLiterals(source).find(s=>s.startsWith('LPH!')));
 const h=decodeConstantPrefix(bytes),boot={...decodePrototypes(new Reader(bytes),h),constants:h.constants};
 assert.throws(()=>recoverReviewedLuraph(bytes,boot,Reader,decodeConstantPrefix,{...luraphReview,payloadXorKey:'0000000000000000'}),/hash mismatch/);
 assert.throws(()=>recoverReviewedLuraph(bytes,boot,Reader,decodeConstantPrefix,{...luraphReview,capturedNumbers:{103:0,39:0}}));
 const altered=Buffer.from(bytes);altered[61010]^=1;assert.throws(()=>recoverReviewedLuraph(altered,boot,Reader,decodeConstantPrefix),/hash mismatch/);
});
test('CLI clears stale approved output when the next input is unsupported', {skip:!available},()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'luraph-cli-'));
 try {
  const cli=new URL('../worker/luraph-cli.mjs',import.meta.url);const out=path.join(dir,'result');
  let p=spawnSync(process.execPath,[cli.pathname,samplePath,out],{encoding:'utf8'});assert.equal(p.status,0,p.stderr);assert.equal(fs.existsSync(path.join(out,'recovered.lua')),true);
  const input=path.join(dir,'unknown.lua');fs.writeFileSync(input,'return 42');
  p=spawnSync(process.execPath,[cli.pathname,input,out],{encoding:'utf8'});assert.equal(p.status,0,p.stderr);
  assert.equal(fs.existsSync(path.join(out,'recovered.lua')),false);assert.equal(fs.existsSync(path.join(out,'luraph.recovery.json')),false);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
