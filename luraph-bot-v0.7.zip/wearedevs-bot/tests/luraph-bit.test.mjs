import test from 'node:test';import assert from 'node:assert/strict';
import {StaticDataEvaluator} from '../tools/luraph/static-data-eval.mjs';
const values=s=>new StaticDataEvaluator({integerBitLibrary:true}).run(s).values;
test('BitOp profile has signed results and modulo-32 shifts, unlike bit32',()=>{
 assert.deepEqual(values('return bit.tobit(4294967295),bit.rshift(-1,0),bit.rshift(-1,1),bit.lshift(1,32),bit.lshift(1,-1),bit.arshift(-2,1)'),[-1,-1,2147483647,1,-2147483648,-1]);
});
test('BitOp folds, rotations and byte swaps remain signed 32-bit operations',()=>{
 assert.deepEqual(values('return bit.band(255,15,3),bit.bor(2147483648,1),bit.bxor(1,3),bit.bnot(0),bit.rol(2147483648,1),bit.ror(1,1),bit.bswap(305419896)'),[3,-2147483647,2,-1,1,-2147483648,2018915346]);
});
test('BitOp compatibility is opt-in and refuses unmodeled coercions',()=>{
 assert.throws(()=>new StaticDataEvaluator().run('return bit.tobit(1)'),/Unknown global bit/);
 assert.throws(()=>values('return bit.tobit(1.5)'),/safe-integer/);
 assert.throws(()=>values('return bit.tobit("1")'),/safe-integer/);
 assert.throws(()=>values('return bit.band()'),/operand required/);
});
test('missing-FFI probe is explicit, conditional, and never loads any module',()=>{
 const e=new StaticDataEvaluator({integerBitLibrary:true,ffiUnavailable:true});
 const r=e.run('local ok,msg=pcall(require,"ffi");return ok,type(msg)');assert.deepEqual(r.values,[false,'string']);
 assert.throws(()=>new StaticDataEvaluator({ffiUnavailable:true}).run('return require("other")'),/remains blocked/);
 assert.throws(()=>new StaticDataEvaluator({integerBitLibrary:true}).run('return require("ffi")'),/Blocked native call require/);
});
