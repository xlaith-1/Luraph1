import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {instrument147} from '../tools/luraph/instrument147.mjs';
const tools=fileURLToPath(new URL('../tools/luraph/',import.meta.url));
const source=`local function vm(p) local code,values=p[1],p[2];return function(...) local pc=1;local r=table.create(2);while true do local op=code[pc];if op==1 then r[1]=values[pc] elseif op==2 then print(r[1]) elseif op==3 then return r[1] else error('bad')end pc=pc+1 end end end return vm({{1,2,3},{'dump me'},function()return 9 end})()`;
for(const runtime of ['lua5.4','luajit'])test(`${runtime}: dump harness captures synthetic tables, functions and live steps`,{skip:spawnSync(runtime,['-v']).status!==0},()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'runtime-dump-'));
 try{
  const input=path.join(dir,'instrumented.lua'),output=path.join(dir,'records.jsonl');
  fs.writeFileSync(input,instrument147(source).source);
  const r=spawnSync(runtime,[path.join(tools,'runtime-dump.lua'),path.join(tools,'trace147-recorder.lua'),input,output],{timeout:10000,encoding:'utf8'});
  assert.equal(r.status,0,r.stderr);
  const records=fs.readFileSync(output,'utf8').trim().split('\n').map(JSON.parse);
  assert.deepEqual(records.filter(r=>r.kind==='step').map(r=>r.opcode),[1,2,3]);
  assert.equal(records.at(-1).ok,true);
  assert.ok(records.some(r=>r.kind==='function-bytecode'&&r.available));
  assert.ok(records.some(r=>r.kind==='printed-value'&&r.value.value==='dump me'));
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
