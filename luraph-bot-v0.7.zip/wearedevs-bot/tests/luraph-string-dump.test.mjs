import test from 'node:test';
import assert from 'node:assert/strict';
import {importStringDump} from '../worker/luraph-string-dump.mjs';
test('numbered dumps preserve multiline spans and arbitrary bytes',()=>{
 const input=Buffer.from('[1] [string] line1\nline2\n[2] [string] \xff\n','latin1');
 const result=importStringDump(input);const rows=JSON.parse(result.artifacts['strings.json']).records;
 assert.equal(result.report.records,2);assert.equal(rows[0].value,'line1\nline2');
 assert.deepEqual(Buffer.from(rows[1].rawBase64,'base64'),Buffer.from('\xff\n','latin1'));
 assert.ok(result.artifacts['strings.inventory.lua'].includes('\\255'));
});
test('dump importer never mistakes normal Lua for a dump',()=>{assert.equal(importStringDump(Buffer.from('print("hello")')),null)});
test('deduplication does not drop raw records',()=>{
 const r=importStringDump(Buffer.from('[1] [string] hi\n[2] [string] hi\n'));assert.equal(r.report.uniqueStrings,1);assert.equal(r.report.records,2);
});
test('Lua injection strings stay quoted data',()=>{
 const r=importStringDump(Buffer.from('[1] [string] ");error("bad");--\n'));assert.ok(r.artifacts['strings.inventory.lua'].includes('\\"'));
});
test('malformed headers are rejected rather than silently merged',()=>{assert.throws(()=>importStringDump(Buffer.from('[1] [string] x\n[3] [string] y\n')))});
