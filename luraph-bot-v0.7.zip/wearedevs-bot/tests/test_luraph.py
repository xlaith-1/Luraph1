import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock, patch
from bot.jobs import run_worker, complete_source_file, JobError
from bot.main import DeobfuscatorBot
from bot.engines import EngineResult
from bot.config import Settings

class LuraphTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_unknown_luraph_worker_refuses_file(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);p=d/'input.lua';p.write_text('-- Luraph\nreturn 42')
            report=await run_worker(p,d/'result',25,engine='luraph')
            self.assertEqual(report['engine'],'luraph-static/0.3.0')
            self.assertFalse(report['fullRecoveryVerified'])
            with self.assertRaisesRegex(JobError,'No file was returned'):
                complete_source_file(report,d/'result',100000)

    async def test_engine_selector_is_not_a_user_controlled_path(self):
        with self.assertRaisesRegex(JobError,'Unknown'):
            await run_worker(Path('x'),Path('y'),25,engine='../../something')

    async def test_luraph_prefix_routes_and_reports_no_source_when_none_written(self):
        settings=Settings('fake',frozenset({1}),frozenset({2}),None,524288,2,30,25,False)
        bot=DeobfuscatorBot(settings)
        bot.session=object()
        class Progress:
            text='';attachments=None
            async def edit(self,**kwargs):self.text=kwargs.get('content');self.attachments=kwargs.get('attachments')
        class Channel:
            id=2
            def permissions_for(self,member):return type('Permissions',(),{'send_messages':True,'attach_files':True})()
        class Message:
            content='?luraph';webhook_id=None
            author=type('Author',(),{'id':1442928403601690657,'bot':False})()
            guild=type('Guild',(),{'id':1,'filesize_limit':8000000,'me':object()})()
            channel=Channel();attachments=[object()];progress=Progress()
            async def reply(self,text,**kwargs):return self.progress
        report={'engine':'luraph-static/0.1.0','status':'partial-analysis','fullRecoveryVerified':False,'payloadDecoded':True,'constantCount':713,'stringConstantCount':176,'declaredPrototypeCount':55}
        message=Message()
        with patch('bot.main.download_attachment',new=AsyncMock()),patch('bot.main.run_engine',new=AsyncMock(return_value=EngineResult('luraph',None,0,False,0.1))) as worker:
            await bot.on_message(message)
            self.assertEqual(worker.await_args.args[0],'luraph')
        self.assertIn('No source file was produced',message.progress.text)
        self.assertIsNone(message.progress.attachments)
        self.assertEqual(bot.gate.active,set())

    @unittest.skipUnless(Path('/home/user/uploads/message (62).txt').exists(), 'private reviewed fixture not installed')
    async def test_reviewed_worker_returns_only_full_code_through_gate(self):
        with tempfile.TemporaryDirectory() as d:
            out=Path(d)/'result'
            report=await run_worker(Path('/home/user/uploads/message (62).txt'),out,25,engine='luraph')
            source=complete_source_file(report,out,100000)
            self.assertEqual(source.read_text(),'print("hiiiii luraph 14.8")\n')
            self.assertTrue(report['fullRecoveryVerified'])
            self.assertFalse(report['executedUploadedCode'])
            source.write_text('print("tampered")\n')
            with self.assertRaisesRegex(JobError,'integrity'):
                complete_source_file(report,out,100000)

    @unittest.skipUnless(Path('/home/user/uploads/message (62).txt').exists(), 'private reviewed fixture not installed')
    @unittest.skipUnless(shutil.which("bwrap"), "OS-isolated integration requires bubblewrap installed")
    async def test_zero_capture_prefix_does_not_attach_original_input(self):
        settings=Settings('fake',frozenset({1}),frozenset({2}),None,524288,2,30,25,False)
        bot=DeobfuscatorBot(settings);bot.session=object()
        class Progress:
            text='';files=[]
            async def edit(self,**kwargs):
                self.text=kwargs.get('content','')
                self.files=[(x.filename,x.fp.read()) for x in kwargs.get('attachments',[])]
        class Channel:
            id=2
            def permissions_for(self,member):return type('Permissions',(),{'send_messages':True,'attach_files':True})()
        class Message:
            content='?luraph';webhook_id=None
            author=type('Author',(),{'id':1442928403601690657,'bot':False})()
            guild=type('Guild',(),{'id':1,'filesize_limit':8000000,'me':object()})()
            channel=Channel();attachments=[object()];progress=Progress()
            async def reply(self,text,**kwargs):return self.progress
        async def download(session,attachment,target,max_bytes,extensions=None):
            target.write_bytes(Path('/home/user/uploads/message (62).txt').read_bytes())
        message=Message()
        with patch('bot.main.download_attachment',new=download):
            await bot.on_message(message)
        self.assertEqual(message.progress.files,[])
        self.assertIn('No validated constant dump',message.progress.text)
        self.assertEqual(bot.gate.active,set())

    @unittest.skipUnless(Path('/home/user/uploads/message (2) (2).txt').exists(), 'private reviewed fixture not installed')
    @unittest.skipUnless(shutil.which("bwrap"), "OS-isolated integration requires bubblewrap installed")
    async def test_new_sample_prefix_attaches_candidate_and_captured_prototype(self):
        settings=Settings('fake',frozenset({1}),frozenset({2}),None,524288,2,30,150,False)
        bot=DeobfuscatorBot(settings);bot.session=object()
        class Progress:
            text='';files=[]
            async def edit(self,**kwargs):
                self.text=kwargs.get('content','')
                self.files=[(x.filename,x.fp.read()) for x in kwargs.get('attachments',[])]
        class Channel:
            id=2
            def permissions_for(self,member):return type('Permissions',(),{'send_messages':True,'attach_files':True})()
        class Message:
            content='?luraph';webhook_id=None
            author=type('Author',(),{'id':1442928403601690657,'bot':False})()
            guild=type('Guild',(),{'id':1,'filesize_limit':8000000,'me':object()})()
            channel=Channel();attachments=[object()];progress=Progress()
            async def reply(self,text,**kwargs):return self.progress
        async def download(session,attachment,target,max_bytes,extensions=None):
            target.write_bytes(Path('/home/user/uploads/message (2) (2).txt').read_bytes())
        message=Message()
        with patch('bot.main.download_attachment',new=download):
            await bot.on_message(message)
        self.assertEqual([name for name,_ in message.progress.files],['luraph-constants.lua'])
        self.assertIn(b'"hii!! luraph 14.7"',message.progress.files[0][1])
        self.assertIn('Successfully dumped',message.progress.text)
        self.assertIn('constants across',message.progress.text)
        self.assertEqual(bot.gate.active,set())
