import test from 'node:test';
import assert from 'node:assert/strict';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {analyzeHelper147} from '../tools/luraph/helper147.mjs';
const graph={tables:[{id:1,entries:[[4,{native:'select'}],[34,{table:2}]]},{id:2,entries:[]}]};
const helper=source=>({node:lp.parse('return function(...) '+source+' end',{luaVersion:'5.3',encodingMode:'pseudo-latin1'}).body[0].arguments[0],captures:[{name:'T',resolved:true,value:{table:1}}]});
const pack=helper('local n=T[4]("#",...);if n~=0 then else return n,T[34] end;return n,{...}');
test('empty packing retains the actual captured empty table',()=>{
 const r=analyzeHelper147(graph,pack,{args:[]});assert.equal(r.status,'abstract-outcomes');assert.deepEqual(r.outcomes[0].values.prefix,[0,{table:2}]);
});
test('packing retains argument count and nil holes without mistaking length for count',()=>{
 const r=analyzeHelper147(graph,pack,{args:[null,3,null]});const values=r.outcomes[0].values.prefix;
 assert.equal(values[0],3);assert.deepEqual(values[1].values,{prefix:[null,3,null],unknownTail:false});assert.equal(values[1].nilEntriesAbsent,true);
});
test('unknown argument count keeps both paths rather than assuming an empty invocation',()=>{
 const r=analyzeHelper147(graph,pack);assert.equal(r.outcomes.length,2);
 assert.ok(r.outcomes.some(o=>o.values.prefix[1]?.table===2));
 assert.ok(r.outcomes.some(o=>o.values.prefix[1]?.values?.unknownTail));
 assert.equal(r.fullRecoveryVerified,false);assert.equal(r.programCallsExecuted,false);
});
test('callee identities must resolve to the modeled native, never names or slots alone',()=>{
 const bad={tables:[{id:1,entries:[[4,{native:'print'}]]}]};
 assert.equal(analyzeHelper147(bad,pack,{args:[]}).reason,'unapproved-call');
 assert.equal(analyzeHelper147(graph,helper('return select("#",...)'),{args:[]}).reason,'unapproved-call');
});
test('unknown callbacks and statements fail closed',()=>{
 assert.equal(analyzeHelper147(graph,helper('return T[34]()')).reason,'unapproved-call');
 assert.match(analyzeHelper147(graph,helper('while true do end')).reason,/statement-not-modeled/);
});
test('multiple returns, parentheses and shadowing preserve Lua adjustments',()=>{
 assert.deepEqual(analyzeHelper147(graph,helper('local a,b=(...);return a,b'),{args:[7,8]}).outcomes[0].values.prefix,[7,null]);
 assert.deepEqual(analyzeHelper147(graph,helper('local a=7;if true then local a=9 end;return a'),{args:[]}).outcomes[0].values.prefix,[7]);
});
test('operation and branch budgets produce no partial success outcomes',()=>{
 assert.equal(analyzeHelper147(graph,pack,{maxOperations:1}).reason,'operation-budget');
 const r=analyzeHelper147(graph,pack,{maxPaths:1});assert.equal(r.reason,'path-budget');assert.deepEqual(r.outcomes,[]);
});
test('undecoded strings are not silently treated as Lua nil',()=>{
 const h=helper('return "x"');h.node.body[0].arguments[0].value=null;
 assert.equal(analyzeHelper147(graph,h).reason,'string-value-not-decoded');
});
