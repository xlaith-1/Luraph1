import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from bot.engines import run_engine, engine_unavailable_reason, command_for

SOURCE = """local function vm(p)
local code,constants=p[1],p[2]
return function(...)
 local registers={};local pc=1
 while true do
  local op=code[pc]
  if op==1 then registers[1]=constants[pc]
  elseif op==2 then sink(registers[1])
  elseif op==3 then return registers[1]
  else error('unsupported') end
  pc=pc+1
 end
end
end
return vm({{1,2,3},{'readable result'}})(...)
"""

@unittest.skipIf(engine_unavailable_reason('luraph') is not None, 'Luraph sandbox dependencies unavailable')
class LiteralRecoveryTests(unittest.IsolatedAsyncioTestCase):
    async def test_real_isolated_worker_selects_readable_candidate(self):
        with tempfile.TemporaryDirectory() as d:
            work=Path(d);(work/'input.lua').write_text(SOURCE)
            command,_=command_for('luraph',30)
            command=[x.replace('luraph-constants-cli.mjs','luraph-dump-cli.mjs') for x in command]
            with patch('bot.engines.command_for',return_value=(command,('luraph.dump.lua',))):
                result=await run_engine('luraph',work,30,100000)
            self.assertEqual(result.returncode,0)
            self.assertIsNotNone(result.source)
            self.assertEqual(result.source.name,'luraph.dump.lua')
            source=result.source.read_text()
            self.assertIn('readable result',source)
            self.assertIn('prototype',source)
            self.assertNotIn('while true',source)
            self.assertIn('Best-effort',result.summary())

    async def test_minimal_static_dependencies_mount_without_token_or_research_workspace(self):
        script="""const fs=require('fs');
        if(process.env.DISCORD_TOKEN||fs.existsSync('/home/user')||fs.existsSync('/opt/legacy/bot'))process.exit(9);
        for(const name of ['recover-literal147.mjs','instrument147.mjs','vendor/luaparse.cjs'])
          if(!fs.existsSync('/opt/legacy/tools/luraph/'+name))process.exit(8);
        if(fs.existsSync('/opt/legacy/tools/luraph/runner.cpp'))process.exit(7);
        fs.writeFileSync('/job/result/standalone.candidate.lua','return 1');"""
        with tempfile.TemporaryDirectory() as d:
            work=Path(d);(work/'input.lua').write_text('unused')
            with patch.dict(os.environ,{'DISCORD_TOKEN':'synthetic-do-not-forward'}),patch(
                    'bot.engines.command_for',return_value=(['node','-e',script],('standalone.candidate.lua',))):
                result=await run_engine('luraph',work,30,100000)
            self.assertEqual(result.returncode,0)
            self.assertEqual(result.source.read_text(),'return 1')
