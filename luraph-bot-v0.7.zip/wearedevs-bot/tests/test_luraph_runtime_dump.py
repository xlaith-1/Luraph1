import asyncio
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from bot.engines import run_engine,engine_unavailable_reason,command_for
from unittest.mock import patch

def legacy_command(engine,timeout):
    command,_=command_for(engine,timeout)
    command=[s.replace("luraph-constants-cli.mjs","luraph-dump-cli.mjs") for s in command]
    return command,("luraph.dump.lua","strings.inventory.lua")

BASE="""local friend=1
local function vm(p)
 local code,constants=p[1],p[2]
 return function(...)
  local pc=1;local result
  while true do
   local op=code[pc]
   if op==1 then result=constants[pc]
   elseif op==2 then print(result)
   elseif op==3 then return result
   else error('unsupported') end
   pc=pc+1
  end
 end
end
return vm({{1,2,3},{'captured hello'},function()return 7 end})()
"""

@unittest.skipIf(engine_unavailable_reason('luraph') is not None,'sandbox unavailable')
class RuntimeDumpTests(unittest.IsolatedAsyncioTestCase):
    async def job(self,source,timeout=12):
        with tempfile.TemporaryDirectory() as d:
            work=Path(d);(work/'input.lua').write_text(source)
            with patch('bot.engines.command_for',side_effect=legacy_command):
                result=await run_engine('luraph',work,timeout,8000000)
            self.assertEqual(result.returncode,0)
            self.assertEqual(result.source.name,'luraph.dump.lua')
            out=work/'result'
            report=json.loads((out/'report.json').read_text())
            records=[json.loads(line)for line in (out/'runtime.records.jsonl').read_text().splitlines()] if (out/'runtime.records.jsonl').exists() else []
            dump=result.source.read_text()
            readable=(out/'readable.vm.lua').read_text()
            return report,records,dump,readable

    async def test_capture_functions_constants_steps_and_formatted_vm(self):
        report,records,dump,readable=await self.job(BASE)
        self.assertTrue(report['runtimeStatus']['ok'])
        self.assertTrue(report['formatted'])
        self.assertEqual([r['opcode'] for r in records if r['kind']=='step'],[1,2,3])
        self.assertTrue(any(r['kind']=='function-bytecode' and r['available'] for r in records))
        self.assertTrue(any(r['kind']=='printed-value' for r in records))
        self.assertIn('captured hello',dump)
        self.assertIn('local friend=1',readable)
        self.assertFalse(report['fullRecoveryVerified'])

    async def test_runtime_failure_keeps_dump_and_exposes_no_io(self):
        report,records,dump,_=await self.job(BASE.replace('print(result)',"io.open('/etc/passwd')"))
        self.assertFalse(report['runtimeStatus']['ok'])
        self.assertTrue(any(r['kind']=='prototype' for r in records))
        self.assertIn('captured hello',dump)

    async def test_unsupported_capture_has_no_false_deliverable(self):
        with tempfile.TemporaryDirectory() as d:
            work=Path(d);(work/'input.lua').write_text('return 42')
            result=await run_engine('luraph',work,12,8000000)
            self.assertIsNone(result.source)
            self.assertNotEqual(result.returncode,0)
            report=json.loads((work/'result/report.json').read_text())
            self.assertEqual(report['status'],'unsupported-or-incomplete')
            self.assertFalse((work/'result/readable.vm.lua').exists())
            self.assertFalse((work/'result/luraph.dump.lua').exists())

    async def test_mutated_opcode_versions_are_kept_in_step_records(self):
        source=BASE.replace('result=constants[pc]','result=constants[pc];code[pc]=2;pc=pc-1').replace('{{1,2,3}', '{{1,3}')
        report,records,_,_=await self.job(source)
        steps=[r for r in records if r['kind']=='step']
        self.assertEqual([(r['pc'],r['opcode']) for r in steps],[(1,1),(1,2),(2,3)])

    async def test_child_kill_preserves_flushed_records(self):
        source=BASE.replace('print(result)', 'while true do pcall(function()while true do end end)end')
        report,records,dump,_=await self.job(source,5)
        self.assertTrue(report['runtimeAttempted'])
        self.assertTrue(any(r['kind']=='step' for r in records))
        self.assertIn('captured hello',dump)
