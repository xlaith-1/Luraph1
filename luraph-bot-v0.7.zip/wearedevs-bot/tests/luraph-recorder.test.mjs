import test from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {VersionedTrace147} from '../tools/luraph/trace147.mjs';
const modulePath=fileURLToPath(new URL('../tools/luraph/trace147-recorder.lua',import.meta.url));
const harness=fileURLToPath(new URL('./fixtures/trace147-recorder-harness.lua',import.meta.url));
const identity={sourceSha256:'b'.repeat(64),symbolNamespace:'recorder-fixture',sessionId:'fixture',executionProfile:'synthetic-no-protected-code'};
for(const runtime of ['lua5.4','luajit']){
 const available=spawnSync(runtime,['-v'],{encoding:'utf8'}).status===0;
 for(const scenario of ['basic','calls','error','threads','limits','sink','reentrant','operand-limit','bad-frame','depth','prototype-change','late-prototype','vm-layouts',...(runtime==='lua5.4'?['integer64']:[])]){
  test(`${runtime} recorder: ${scenario}`,{skip:!available},()=>{
   const result=spawnSync(runtime,[harness,modulePath,scenario],{encoding:'utf8',timeout:15000,maxBuffer:1024*1024});
   assert.equal(result.status,0,result.stderr);
   const events=result.stdout.trim()?result.stdout.trim().split('\n').map(JSON.parse):[];
   const tracker=new VersionedTrace147(identity);for(const event of events)tracker.add(event);
   const artifact=tracker.finish('synthetic-test-ended');assert.equal(artifact.valid,true);assert.equal(artifact.fullRecoveryVerified,false);
   if(scenario==='basic'){
    const steps=events.filter(e=>e.kind==='step');assert.equal(steps[0].operands.a.value,1);assert.equal(steps[1].operands.a.value,2);
    assert.equal(steps[0].operands.bytes.hex,'00ff');assert.equal(steps[0].operands.proto.id,'p7');assert.equal(steps[0].operands.missing.type,'nil');
    assert.equal(steps[0].operands.negative.value,'-0');assert.equal(steps[0].operands.nan.value,'nan');assert.equal(artifact.multiVersionSites,1);
   }
   if(scenario==='calls'){assert.equal(artifact.edges.length,1);assert.equal(artifact.edges[0].relation,'resume');assert.equal(artifact.incompleteFrames.length,0);}
   if(scenario==='error'){assert.equal(events.at(-1).status,'error');assert.equal(artifact.incompleteFrames.length,0);}
   if(scenario==='threads'){assert.equal(artifact.edges.length,1);assert.equal(artifact.edges[0].threadId,'one');}
   if(scenario==='limits'){assert.equal(events.length,2);assert.equal(artifact.incompleteFrames.length,1);}
   if(scenario==='sink'||scenario==='reentrant')assert.equal(events.length,0);
   if(scenario==='vm-layouts'){assert.equal(artifact.multiVersionSites,3);assert.equal(artifact.instructionSites,6);assert.equal(artifact.instructionVersions,9);}
   if(scenario==='integer64')assert.equal(events[1].operands.large.decimal,'9223372036854775807');
  });
 }
}

test('CLI checks producer status rather than silently accepting a failed prefix',async()=>{
 const fs=await import('node:fs');const os=await import('node:os');const path=await import('node:path');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'recorder-status-'));
 try{
  const events=[{sessionId:'fixture',seq:0,kind:'enter',threadId:'main',frameId:'f1',prototypeId:'p0'},
   {sessionId:'fixture',seq:1,kind:'step',threadId:'main',frameId:'f1',prototypeId:'p0',pc:0,opcode:8,operands:{}}];
  fs.writeFileSync(path.join(dir,'events.jsonl'),events.map(JSON.stringify).join('\n'));
  const manifest=path.join(dir,'manifest.json'),output=path.join(dir,'result.json'),status=path.join(dir,'status.json');
  fs.writeFileSync(manifest,JSON.stringify({identity,inputs:[{format:'events-jsonl',path:'events.jsonl'}],producerStatus:'status.json'}));
  const cli=fileURLToPath(new URL('../tools/luraph/trace147-cli.mjs',import.meta.url));
  for(const [producer,valid] of [[{sessionId:'fixture',events:2,valid:true,stopReason:'budget'},true],[{sessionId:'fixture',events:2,valid:false},false],[{sessionId:'wrong',events:2,valid:true},false],[{sessionId:'fixture',events:3,valid:true},false]]){
   fs.writeFileSync(status,JSON.stringify(producer));const result=spawnSync(process.execPath,[cli,manifest,output],{encoding:'utf8',timeout:15000});
   assert.equal(result.status,valid?0:1,result.stderr);const artifact=JSON.parse(fs.readFileSync(output));assert.equal(artifact.valid,valid);if(!valid)assert.deepEqual(artifact.edges,[]);
  }
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});

test('recorder produces a machine-readable failure-status sidecar',()=>{
 for(const runtime of ['lua5.4','luajit']){
  if(spawnSync(runtime,['-v']).status!==0)continue;
  const result=spawnSync(runtime,[harness,modulePath,'status-output'],{encoding:'utf8',timeout:15000});
  assert.equal(result.status,0,result.stderr);const status=JSON.parse(result.stdout);
  assert.equal(status.events,2);assert.equal(status.incompleteFrames,1);assert.equal(status.valid,false);assert.equal(status.stopReason,'budget');assert.equal(status.sessionId,'fixture');assert.equal(status.error,'Event limit');
 }
});
