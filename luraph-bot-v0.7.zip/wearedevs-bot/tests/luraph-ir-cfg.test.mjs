import test from 'node:test';
import assert from 'node:assert/strict';
import lp from '../tools/luraph/vendor/luaparse.cjs';
import {InstructionLowerer} from '../tools/luraph/ir147.mjs';
import {InitialImageCFG} from '../tools/luraph/cfg147.mjs';
function fixture(body,{preamble='',initialPc='1',prefix='',epilogue='',options={}}={}){
 const ast=lp.parse(`return function(p) local code,targets,constants=p[1],p[2],p[3];return function(...)local registers={};local pc=${initialPc};local t,a,b;${preamble};repeat ${prefix};local op=code[pc];${body};pc+=1 until false ${epilogue} end end`,{luaVersion:'5.3',encodingMode:'pseudo-latin1'});
 const factory=ast.body[0].arguments[0],frame=factory.body.at(-1).arguments[0],loop=frame.body.find(n=>n.type==='RepeatStatement');
 const d={slotAliases:{code:1,targets:2,constants:3},read:{opcodeArray:'code',programCounter:'pc',opcodeSlot:1},frame:{registerArray:'registers',registerCountSlot:4},opcodeVariable:'op',iteration:{}};
 const ir=new InstructionLowerer(d,frame).lower([{opcode:0,iterationBody:loop.body}]);
 const graph={args:[{table:1}],tables:[
  {id:1,entries:[[1,{table:2}],[2,{table:3}],[3,{table:4}],[4,2]]},
  {id:2,entries:Array.from({length:8},(_,i)=>[i+1,0])},
  {id:3,entries:[[1,3],[2,4],[3,1],[4,0],[5,0]]},
  {id:4,entries:[[1,1],[2,2],[3,3],[4,4],[5,0]]},
 ]};
 return {ir,cfg:new InitialImageCFG(graph,d,ir,options)};
}
function walk(n,fn){if(!n||typeof n!=='object')return;fn(n);for(const v of Object.values(n)){if(Array.isArray(v))v.forEach(x=>walk(x,fn));else walk(v,fn);}}
test('IR preserves mutable operand reads instead of embedding initial values',()=>{
 const {ir}=fixture('pc=targets[pc]');const reads=[];walk(ir.instructions,n=>{if(n.kind==='operand-read')reads.push(n);});
 assert.ok(reads.some(r=>r.slot===2));assert.ok(reads.every(r=>!Object.hasOwn(r,'initialValue')));assert.equal(ir.fullRecoveryVerified,false);
});
test('initial-image CFG preserves the shared jump increment',()=>{
 assert.deepEqual(fixture('pc=targets[pc]').cfg.analyzeInstruction(1).successors,[4]);
});
test('fused instructions read operands at the updated PC',()=>{
 assert.deepEqual(fixture('pc+=1;pc=targets[pc]').cfg.analyzeInstruction(1).successors,[5]);
});
test('unknown register branches retain both provisional targets',()=>{
 assert.deepEqual(fixture('if registers[1] then pc=targets[pc] end').cfg.analyzeInstruction(1).successors,[2,4]);
 assert.deepEqual(fixture('if 0 then pc=targets[pc] end').cfg.analyzeInstruction(1).successors,[4]);
});
test('lexical shadowing removes a captured operand-array role',()=>{
 const {ir}=fixture('pc=constants[pc]',{preamble:'local constants'});const reads=[];
 walk(ir.instructions,n=>{if(n.kind==='operand-read')reads.push(n.slot);});assert.equal(reads.includes(3),false);
});
test('operand-array rebinding is represented and observed inside an instruction',()=>{
 assert.deepEqual(fixture('targets=constants;pc=targets[pc]').cfg.analyzeInstruction(1).successors,[2]);
});
test('decoded-table writes through aliases are tracked but not certified',()=>{
 const r=fixture('t=targets;t[1]=4;pc=targets[1]').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[5]);assert.ok(r.unresolved.includes('decoded-table-write-requires-cross-instruction-propagation'));
});
test('simultaneous assignment addresses are evaluated before stores',()=>{
 const r=fixture('pc,targets[pc]=2,5;pc=targets[1]').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[6]);
});
test('repeat conditions use locals declared by their own body',()=>{
 assert.deepEqual(fixture('repeat local finished=true;t=targets[pc] until finished;pc=t').cfg.analyzeInstruction(1).successors,[4]);
});
test('numeric loop control is not the mutable loop-body variable',()=>{
 assert.deepEqual(fixture('for i=1,2 do pc+=1;i=100 end').cfg.analyzeInstruction(1).successors,[4]);
});
test('calls never execute and invalidate subsequent decoded-table assumptions',()=>{
 const r=fixture('print("not executed");pc=targets[pc]').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[]);assert.ok(r.unresolved.includes('call-effects-and-results-unmodeled'));
});
test('multiple unknown results are not filled with invented nils',()=>{
 const r=fixture('local first,second=unknown();pc=second').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[]);assert.ok(r.unresolved.includes('dynamic-or-out-of-range-program-counter'));
});
test('unknown and unbounded nested loops remain unresolved',()=>{
 for(const body of ['while unknown do pc+=1 end','while true do end']){
  const r=fixture(body,{options:{maxIterations:3}}).cfg.analyzeInstruction(1);assert.ok(r.unresolved.length);assert.deepEqual(r.successors,[]);
 }
});
test('initial-image analysis never claims full application recovery',()=>{
 const r=fixture('pc=targets[pc]').cfg.analyze();assert.equal(r.fullRecoveryVerified,false);assert.equal(r.status,'initial-image-cfg-only');assert.equal(r.programCallsExecuted,false);
});

test('plain local tables preserve aliases and dense lengths',()=>{
 const r=fixture('t={1,2};a=t;a[1]=4;pc=t[1]+#a').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[7]);assert.deepEqual(r.unresolved,[]);
});
test('table holes are not assigned an invented Lua length',()=>{
 const r=fixture('t={[1]=1,[3]=3};pc=#t').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[]);assert.ok(r.unresolved.includes('dynamic-or-out-of-range-program-counter'));
});
test('table references compare by identity',()=>{
 const r=fixture('t={};a=t;b={};if a==t and a~=b then pc=3 else pc=4 end').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[4]);
});
test('fresh entry tracing preserves temporary values across instructions',()=>{
 const r=fixture('if pc==1 then t=targets[pc];pc=2 else pc=t;return end').cfg.traceEntry();
 assert.equal(r.stop,'entry-return');assert.deepEqual(r.trace.map(n=>n.pc),[1,3]);assert.equal(r.fullRecoveryVerified,false);
});
test('entry tracing reads modified opcodes rather than the original snapshot',()=>{
 const {cfg}=fixture('code[2]=99');const r=cfg.traceEntry();
 assert.equal(r.stop,'unknown-or-modified-opcode');assert.equal(r.trace.length,1);assert.equal(cfg.opcodes.get(2),0);
});
test('trace loops are bounded and calls never run',()=>{
 const loop=fixture('pc=0').cfg.traceEntry({maxInstructions:3});assert.equal(loop.stop,'instruction-budget');assert.equal(loop.trace.length,3);
 const call=fixture('print("not executed")').cfg.traceEntry();assert.equal(call.stop,'call-effects-and-results-unmodeled');assert.equal(call.programCallsExecuted,false);
});

test('analysis operation budget remains explicit rather than producing a certificate',()=>{
 const r=fixture('pc=targets[pc]',{options:{maxTotalOperations:1}}).cfg.analyzeInstruction(1);
 assert.ok(r.unresolved.includes('analysis-operation-budget'));assert.deepEqual(r.successors,[]);
});
test('fresh entry comes from the actual known PC seed rather than a hardcoded one',()=>{
 const {ir,cfg}=fixture('do return end',{initialPc:'3'});assert.equal(ir.entryPc,3);
 assert.equal(cfg.traceEntry().trace[0].pc,3);
});
test('unknown initial PC blocks fresh-entry tracing',()=>{
 const {ir,cfg}=fixture('do return end',{initialPc:'incoming'});assert.equal(ir.entryPc,null);
 assert.equal(cfg.traceEntry().stop,'unknown-initial-program-counter');assert.equal(cfg.traceEntry().trace.length,0);
});
test('a prefix that changes PC before opcode fetch cannot use snapshot dispatch',()=>{
 const {ir,cfg}=fixture('do return end',{prefix:'pc+=1'});assert.equal(ir.simpleOpcodeFetch,false);
 assert.ok(cfg.analyzeInstruction(1).unresolved.includes('nontrivial-opcode-fetch-prefix'));
 assert.equal(cfg.traceEntry().stop,'nontrivial-opcode-fetch-prefix');
});
test('uninterpreted preamble assignment cannot retain stale entry seeds',()=>{
 const {ir,cfg}=fixture('pc=targets[pc]',{preamble:'pc=incoming'});
 assert.equal(ir.entryPc,null);assert.equal(cfg.traceEntry().stop,'unknown-initial-program-counter');
});
test('restoring a literal PC does not authorize unknown preamble register effects',()=>{
 const {ir,cfg}=fixture('pc=targets[pc]',{preamble:'registers[1]=true;local pc=1'});
 assert.equal(ir.entryPc,1);assert.equal(ir.unmodeledPreambleEffects,true);
 assert.equal(cfg.traceEntry().stop,'unmodeled-preamble-effects');
});
test('locals declared after the dispatcher do not retroactively shadow its operands',()=>{
 const {ir}=fixture('pc=targets[pc]',{epilogue:'local targets'});const reads=[];
 walk(ir.instructions,n=>{if(n.kind==='operand-read')reads.push(n.slot);});assert.ok(reads.includes(2));
});

test('aliased simultaneous stores cannot invent left-to-right Lua assignment semantics',()=>{
 const r=fixture('pc,pc=2,3').cfg.analyzeInstruction(1);
 assert.deepEqual(r.successors,[]);assert.ok(r.unresolved.includes('aliased-simultaneous-assignment'));
});
