# Update 0.7 — Luraph v15 devirtualization route (`?v15`)

## What changed

- New prefix command **`?v15`** wires in the supplied Luraph v15 devirtualizer.
- The engine runs the protected input **instrumented**, in the fake
  Roblox/executor environment, inside the existing networkless Bubblewrap
  sandbox (`--unshare-all`, no `/home`, no network, resource-limited).
- Inputs must pass the Luraph v15 detection and VM-structure checks
  (`restore_header_newline`, `vmmap.load_ast`, `maker_info`,
  `find_dispatchers`); otherwise they are rejected with no generic
  script-execution fallback.
- A pinned Luau runtime (luau-lang/luau 0.739 with the vector metatable left
  writable) plus `luau-ast` and `luau-compile` is installed under
  `engines/luraph-v15/runtime/` and rebuilt via
  `scripts/build_v15_runtime.py`. Nothing is downloaded at request time.
- Two artifacts are published when produced:
  `luraph-v15.application.lua` (lifted candidate) and
  `luraph-v15.trace.lua` (behaviour trace). Both are validated to be real
  Luau, not the original input, and not a VM-only listing. Every result is
  labelled **partial / not verified complete or equivalent**.
- `?luraph` (constant route) is unchanged.

## Verified

Bundled Luraph v15.0 sample (`return setmetatable({...VM...})`): detection
confidence 1.0, 2 VM makers / 8 dispatchers, devirtualized candidate
reconstructs the original stack-machine program (PUSH/MUL/SUB/ADD, final
`assert(34)`), plus a 44-statement behaviour trace. Plain (non-Luraph) Lua
is rejected with no output.

## Limitations

- Dynamic execution of instrumented input is required for this route; the
  application is not executed, but its obfuscated VM is traced in a fake
  environment. Branches never taken are absent from the trace; anti-tamper
  trap functions may be disabled by the pipeline.
- Local names are inferred from use; original identifiers are not recovered.
- No completeness/equivalence claim is made for any output.
