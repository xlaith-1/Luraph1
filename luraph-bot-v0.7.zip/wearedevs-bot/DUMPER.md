# Current Luraph route: constant dumping

See [docs/CONSTANT_DUMPER.md](docs/CONSTANT_DUMPER.md) for current behavior, tested
results and limitations. The default prefix route no longer returns readable VM
source or a hash-specific application candidate.

## Previous runtime-dumper development history

# Luraph best-effort capture and reviewed application candidates

This is the current `?luraph` behavior, replacing the previous attempt to make
original-source reconstruction the default. **A partial dump is a valid result.**

## Usage and files

Attach one `.lua` or `.txt` file to `?luraph` in the same message. The bot still
responds only to its configured authorized owner, using the existing 900-second
default and 1800-second maximum. Hosting remains temporary; the supervisor cannot survive the hosting VM stopping.

The route returns:

1. **`luraph.dump.lua`** — a readable Lua data table containing available runtime
   records and status. It is data, not reconstructed application code.
2. **`luraph.readable.lua`** — formatted unpacked/interpreter Lua where supported.
   Only attached after genuine capture and successful formatting. Zero capture
   never returns the original input or an empty dump as a successful result.

Existing numbered string dumps still use the string-inventory importer.

## What gets captured

- Runtime prototype identities and capture sites.
- Bounded prototype/table contents, with references rather than recursive copies.
- Constants and byte-safe strings, including printed values.
- Observed instruction PCs, opcodes, operands, frame entries and exits.
  Repeated PCs are retained, including changed opcode versions.
- Lua function references and, when encountered and supported, bounded binary
  function bytecode as hexadecimal. Native functions may have no dumpable
  bytecode. Bytecode is runtime-specific; upvalues are not reconstructed.

These records may include interpreter/runtime data, not just application data.
A graph/table truncation marker is explicit. Missing references or absent paths
are not filled with invented values. No CFG, equivalence, or coverage certificate
is issued.

## Execution and safety

The production route is `worker/luraph-dump-cli.mjs`, invoked by the existing
Bubblewrap worker. It first checks the exact reviewed candidate route, otherwise tries static
unpacking and writes a diagnostic report checkpoint. It instruments supported dispatcher shapes
and invokes the trusted Lua harness with independent process/resource limits.

The target environment excludes `io`, `os`, `require`, FFI, and the debug library.
No network or credentials are supplied. LuaJIT is preferred; Lua5.4 is a fallback.
There are limited `table.create`/pack/unpack, environment, and immutable byte-buffer
compatibility helpers—not a full Luau/Roblox environment. Environment changes are
restricted. Uploaded code is executed only for the runtime phase in OS isolation.

The `LURAPH_ISOLATED` environment variable is an internal launcher assertion,
**not** a sandbox by itself. Do not set it to run untrusted input directly on a host.
Without it, the CLI only prepares files and reports that runtime capture is disabled.
The Lua harness is a trusted internal component, not a safe standalone command for
arbitrary uploads.

The formatter inserts whitespace only and checks the resulting AST against the
original. Normalization that changes control flow is not used for execution.

Runtime records are flushed individually. Native instruction and recording limits
are supplemented by the parent process deadline: catching a Lua error cannot evade
the OS timeout. The parent kills a stuck runtime before the overall deadline and
renders available complete records. If the *entire worker* is killed before this
rendering, raw records and the diagnostic checkpoint remain in the job directory;
there may be no rendered Lua attachment. An empty placeholder is not returned.

Default capture limits include 8,000 graph entries, 2,048 entries per table,
20,000 recorder events, 30,000 combined records, 4 MiB raw records, and approximately
5 MiB readable records. Strings are bounded to 4,096 bytes; up to 32 function
bytecode dumps of at most 16 KiB each are included. These caps deliberately leave
room for live steps instead of spending the whole budget on the initial graph.

## Actual validation

- **251 Node tests passed, zero skips (including the supplied sample).**
- **70 Python tests: 62 passed, 8 dependency-based skips.**
- New harness tests run on Lua5.4 and LuaJIT; isolated-worker tests verify runtime
  tables/functions/constants/steps, formatting, mutation records, restricted I/O,
  unsupported-input fallback, and retaining flushed records after a child timeout.
- The prefix integration test now checks two attachments rather than recovered
  source. Existing owner-only behavior remains tested.
- A protected development input was actually run in the isolated dumper with a
  20-second outer budget. It produced **10,182 records**: 14 prototype records,
  259 table-start records, 8,000 table entries, one graph-truncation marker,
  15 frame entries, **1,881 instruction steps**, 11 exits, and one terminal status.
  Formatting succeeded. Execution stopped because the input required the omitted
  debug library; four frames remained incomplete. This is useful partial runtime
  capture, **not** a successful application run or complete dump.

No holdout corpus or live Discord deployment was used to claim broad compatibility.
Some packed formats, Luau syntax, debug-dependent inputs, environment checks, and
Roblox APIs remain unsupported. In those cases the dumper returns what it has and
rejects empty capture as no output and labels genuine partial capture honestly.

## September 14 sample correction

The exact input SHA256 `aaf25cc314cf7b09d3eafcaf821bc1798c794197897f63ca20c2b9182afedc8d`
now produces `luraph.application.candidate.lua` plus a captured-prototype dump:

```lua
print("hii!! luraph 14.7")
```

This is **best-effort, not a verified full decompilation**. The original parser
captures a 125-byte application prototype containing two encrypted strings and
nine instructions. Cipher parameters 193, 213 and 168 are independently read from
bootstrap prototype 283 instructions; no expected output string is substituted.
The original application VM frame is evaluated with the decoded candidate
constants, following PCs 1, 6, 2, 3, 4, 5, 8, 9 and returning normally. Its print
is recorded, not sent to an external application environment.

The full original bootstrap/string-decoder path and environment checks are not
executed. Byte-layout interpretation remains reviewed rather than fully proven.
`fullRecoveryVerified` and `originalStringDecoderVerified` remain false.
This path is hash-gated to the reviewed input and normalized source, not advertised
as general Luraph 14.7 support. The normalizer is used only with the bounded AST
evaluator; normalized source is never executed by a native Lua interpreter.

The prefix integration test exercises the actual isolated worker and attachment
selection for this sample. Unknown zero-capture inputs produce a diagnostic,
not the protected source relabeled as readable code. Existing owner-only silence,
900-second default and 1800-second maximum are unchanged.
